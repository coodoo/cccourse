# Orders API classroom starter

Run commands from this directory with Node 24 or newer and npm. This is a local fake commerce service; no payment provider is contacted.

```sh
npm ci
npm test
npm run seed
npm start
```

The server binds to `127.0.0.1:3000`. In a second terminal:

```sh
curl http://127.0.0.1:3000/health
curl http://127.0.0.1:3000/api/products
curl -X POST http://127.0.0.1:3000/api/orders -H 'Content-Type: application/json' -d '{"items":[{"sku":"mug","quantity":2}]}'
curl http://127.0.0.1:3000/api/orders/1
curl -X POST http://127.0.0.1:3000/api/orders/1/pay -H 'Content-Type: application/json' -d '{"idempotencyKey":"demo-payment"}'
curl http://127.0.0.1:3000/api/reports/sales
```

These examples assume a fresh seed. The two-mug order totals 4500 cents. Keep the returned order ID when using an existing database.

`npm run seed` creates `data/demo.sqlite` and refuses to overwrite it. To start another exercise, choose a new path rather than deleting your work:

```sh
npm run seed -- data/another-demo.sqlite
DB_PATH=data/another-demo.sqlite PORT=3001 npm start
```

Other routes are `POST /api/orders/:id/cancel` with `{}` and `POST /api/orders/:id/refund` with `{"sku":"mug","quantity":1}`. Requests and responses use JSON. Invalid input returns 400, missing resources 404, and stock or lifecycle conflicts 409, with an `error` string.

Money uses integer cents. Catalog prices are tea 1250 and mug 2000; each starts with stock 20. Shipping is 500 cents below a merchandise subtotal of 5000, otherwise free. Orders snapshot prices. Duplicate SKU lines are rejected; combine quantities in the request.

`src/app.js` exports `createApp({db})`; `src/db.js` exports `openDatabase(path)` and `seedDatabase(db)`. Opening a database creates schema without inserting fixtures. Tests use fresh in-memory databases and actual loopback HTTP listeners.

## Your assignment

Implement [DISC-1](docs/requests/DISC-1.md). First run the existing tests and record what they prove. Investigate the source and the affected lifecycle before changing it, then add focused characterization coverage.

This README is an orientation, not a complete business specification. Payment retries, cancellation details, refund allocation and reporting need investigation in source and tests. Separate observed behavior from assumptions and ask the product owner about unresolved decisions.
