# DISC-0: discount codes

Add one optional `discountCode` to `POST /api/orders`. Preserve existing no-code behavior, inventory, payment retries, lifecycle and reporting. Use the existing seeded `discount_codes` table; do not introduce external services.

## Feature requirements

Normalize string codes by trimming whitespace and converting to uppercase. Empty or non-string codes, unknown codes, inactive or expired codes and orders below a campaign minimum return 400. Exhausted campaigns return 409. Reject unknown request fields as before.

Discount merchandise only. For a percentage, floor the subtotal percentage once to integer cents. A fixed discount cannot exceed merchandise subtotal. Return and persist `discountCents` alongside the other order totals. Snapshot the selected discount and totals so later campaign changes cannot reprice an order.

Reserve one campaign use atomically when creating an order. A failed order must consume neither stock nor a campaign use. Release usage once when cancelling a pending order. Payment and refunds retain usage. Keep the existing restriction that only pending orders can be cancelled.

Preserve existing refund eligibility, quantities, shipping and money-allocation behavior. Determine the discount impact by tracing the current code and add targeted characterization before changing it. Refunds do not release campaign usage or restock items.

Fake payment remains local and supports a zero total. Replaying the same payment key on the same order succeeds without another capture. Reusing it on another order or paying an already paid order with a different key returns 409.


## Seed campaigns

- `SAVE10`: 10 percent off, minimum merchandise subtotal 2000, maximum 3 uses.

- `LESS500`: 500 cents off, no minimum, maximum 3 uses.

- `BIG`: 99999 cents off, capped at merchandise subtotal, maximum 3 uses.

- `EXPIRED`: expired on 2000-01-01; unavailable.

- `OFF`: inactive; unavailable.

Other campaigns expire on 2099-01-01. All begin with zero uses. 

