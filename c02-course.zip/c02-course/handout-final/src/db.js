const { DatabaseSync } = require('node:sqlite');

function openDatabase(path = ':memory:') {
  const db = new DatabaseSync(path);
  db.exec(`PRAGMA foreign_keys = ON;
    CREATE TABLE IF NOT EXISTS products (sku TEXT PRIMARY KEY, price_cents INTEGER NOT NULL, stock INTEGER NOT NULL CHECK(stock >= 0));
    CREATE TABLE IF NOT EXISTS discount_codes (code TEXT PRIMARY KEY, kind TEXT NOT NULL, value INTEGER NOT NULL, min_subtotal_cents INTEGER NOT NULL, max_uses INTEGER NOT NULL, used_count INTEGER NOT NULL DEFAULT 0, expires_at TEXT NOT NULL, active INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY, status TEXT NOT NULL, subtotal_cents INTEGER NOT NULL, shipping_cents INTEGER NOT NULL, discount_cents INTEGER NOT NULL DEFAULT 0, discount_code TEXT, total_cents INTEGER NOT NULL, paid_cents INTEGER NOT NULL DEFAULT 0, refunded_cents INTEGER NOT NULL DEFAULT 0);
    CREATE TABLE IF NOT EXISTS order_items (order_id INTEGER NOT NULL REFERENCES orders(id), sku TEXT NOT NULL, quantity INTEGER NOT NULL, unit_price_cents INTEGER NOT NULL, refunded_quantity INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(order_id, sku));
    CREATE TABLE IF NOT EXISTS captures (idempotency_key TEXT PRIMARY KEY, order_id INTEGER NOT NULL UNIQUE REFERENCES orders(id), amount_cents INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS refunds (id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL REFERENCES orders(id), sku TEXT NOT NULL, quantity INTEGER NOT NULL, amount_cents INTEGER NOT NULL);`);
  return db;
}

function seedDatabase(db) {
  transaction(db, () => {
    const product = db.prepare('INSERT INTO products VALUES (?, ?, ?)');
    product.run('tea', 1250, 20);
    product.run('mug', 2000, 20);
    const campaign = db.prepare('INSERT INTO discount_codes VALUES (?, ?, ?, ?, ?, 0, ?, ?)');
    campaign.run('SAVE10', 'percent', 10, 2000, 3, '2099-01-01', 1);
    campaign.run('LESS500', 'fixed', 500, 0, 3, '2099-01-01', 1);
    campaign.run('BIG', 'fixed', 99999, 0, 3, '2099-01-01', 1);
    campaign.run('EXPIRED', 'percent', 10, 0, 3, '2000-01-01', 1);
    campaign.run('OFF', 'percent', 10, 0, 3, '2099-01-01', 0);
  });
}

function transaction(db, work) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = work();
    db.exec('COMMIT');
    return result;
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
}
module.exports = { openDatabase, seedDatabase, transaction };
