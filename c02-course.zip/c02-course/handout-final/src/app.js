const express = require('express');
const { openDatabase } = require('./db');
const { orderId } = require('./validation');
const { createOrder, getOrder, cancelOrder } = require('./orders');
const { payOrder, refundOrder } = require('./payments');
const { salesReport } = require('./reports');

function createApp({ db = openDatabase() } = {}) {
  const app = express();
  app.locals.db = db;
  app.disable('x-powered-by');
  app.use(express.json({ limit: '32kb' }));
  app.get('/health', (req, res) => res.json({ ok: true }));
  app.get('/api/products', (req, res) => res.json(db.prepare('SELECT sku, price_cents AS priceCents, stock FROM products ORDER BY sku').all()));
  app.post('/api/orders', (req, res) => res.status(201).json(createOrder(db, req.body)));
  app.get('/api/orders/:id', (req, res) => res.json(getOrder(db, orderId(req.params.id))));
  app.post('/api/orders/:id/pay', (req, res) => res.json(payOrder(db, orderId(req.params.id), req.body)));
  app.post('/api/orders/:id/cancel', (req, res) => res.json(cancelOrder(db, orderId(req.params.id), req.body)));
  app.post('/api/orders/:id/refund', (req, res) => res.json(refundOrder(db, orderId(req.params.id), req.body)));
  app.get('/api/reports/sales', (req, res) => res.json(salesReport(db)));
  app.use((req, res) => res.status(404).json({ error: 'Route not found' }));
  app.use((error, req, res, next) => {
    const status = error.status >= 400 && error.status < 500 ? error.status : 500;
    res.status(status).json({ error: status === 500 ? 'Internal error' : error.message });
  });
  return app;
}
module.exports = { createApp };
