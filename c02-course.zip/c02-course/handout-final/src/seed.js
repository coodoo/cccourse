const fs = require('node:fs');
const path = require('node:path');
const { openDatabase, seedDatabase } = require('./db');
const destination = process.argv[2] || 'data/demo.sqlite';
fs.mkdirSync(path.dirname(destination), { recursive: true });
// Exclusive creation also rejects races; never overwrite learner data.
const fd = fs.openSync(destination, 'wx');
fs.closeSync(fd);
const db = openDatabase(destination);
try { seedDatabase(db); console.log(`Seeded ${destination}`); } finally { db.close(); }
