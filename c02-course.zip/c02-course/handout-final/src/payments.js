const { transaction } = require('./db');
const { fail, object, quantity } = require('./validation');
const { getOrder } = require('./orders');

function payOrder(db, id, body) {
  object(body, ['idempotencyKey']);
  if (typeof body.idempotencyKey !== 'string' || !/^[A-Za-z0-9_-]{1,80}$/.test(body.idempotencyKey)) fail(400, 'Invalid idempotency key');
  return transaction(db, () => {
    const order = getOrder(db, id);
    const existing = db.prepare('SELECT * FROM captures WHERE idempotency_key = ?').get(body.idempotencyKey);
    if (existing) {
      if (existing.order_id !== id) fail(409, 'Payment key already belongs to another order');
      return order;
    }
    if (order.status !== 'pending') fail(409, 'Order cannot be paid');
    db.prepare('INSERT INTO captures VALUES (?, ?, ?)').run(body.idempotencyKey, id, order.totalCents);
    db.prepare("UPDATE orders SET status = 'paid', paid_cents = total_cents WHERE id = ?").run(id);
    return getOrder(db, id);
  });
}

function refundOrder(db, id, body) {
  object(body, ['sku', 'quantity']);
  quantity(body.quantity);
  if (typeof body.sku !== 'string' || body.sku.length > 64) fail(400, 'Invalid SKU');
  return transaction(db, () => {
    const order = getOrder(db, id);
    if (order.status !== 'paid') fail(409, 'Only paid orders can be refunded');
    const item = db.prepare('SELECT * FROM order_items WHERE order_id = ? AND sku = ?').get(id, body.sku);
    if (!item) fail(400, 'Unknown order item');
    if (item.refunded_quantity + body.quantity > item.quantity) fail(409, 'Refund exceeds purchased quantity');
    const previous = db.prepare('SELECT COALESCE(SUM(refunded_quantity * unit_price_cents), 0) AS value FROM order_items WHERE order_id = ?').get(id).value;
    const cumulativeList = previous + body.quantity * item.unit_price_cents;
    // Cumulative allocation prevents per-unit rounding from leaking cents.
    const cumulativeRefund = Number(BigInt(order.paidCents - order.shippingCents) * BigInt(cumulativeList) / BigInt(order.subtotalCents));
    const amount = cumulativeRefund - order.refundedCents;
    db.prepare('UPDATE order_items SET refunded_quantity = refunded_quantity + ? WHERE order_id = ? AND sku = ?').run(body.quantity, id, body.sku);
    db.prepare('INSERT INTO refunds (order_id, sku, quantity, amount_cents) VALUES (?, ?, ?, ?)').run(id, body.sku, body.quantity, amount);
    db.prepare('UPDATE orders SET refunded_cents = refunded_cents + ? WHERE id = ?').run(amount, id);
    return getOrder(db, id);
  });
}
module.exports = { payOrder, refundOrder };
