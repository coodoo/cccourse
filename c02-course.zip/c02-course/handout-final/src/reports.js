function salesReport(db) {
  const paidCents = db.prepare('SELECT COALESCE(SUM(amount_cents), 0) AS total FROM captures').get().total;
  const refundedCents = db.prepare('SELECT COALESCE(SUM(amount_cents), 0) AS total FROM refunds').get().total;
  return { paidCents, refundedCents, netCents: paidCents - refundedCents };
}
module.exports = { salesReport };
