const { transaction } = require('./db');
const { fail, object, quantity } = require('./validation');
const { priceItems, shipping } = require('./pricing');

function getOrder(db, id) {
  const row = db.prepare('SELECT * FROM orders WHERE id = ?').get(id);
  if (!row) fail(404, 'Order not found');
  const items = db.prepare('SELECT sku, quantity, unit_price_cents AS unitPriceCents FROM order_items WHERE order_id = ? ORDER BY sku').all(id);
  return { id: row.id, status: row.status, subtotalCents: row.subtotal_cents, shippingCents: row.shipping_cents,  totalCents: row.total_cents, paidCents: row.paid_cents, refundedCents: row.refunded_cents, items };
}

function createOrder(db, body) {
  object(body, ['items']);
  if (!Array.isArray(body.items) || !body.items.length || body.items.length > 100) fail(400, 'Items are required');
  const seen = new Set();
  for (const item of body.items) {
    object(item, ['sku', 'quantity']);
    if (typeof item.sku !== 'string' || !/^[a-z0-9-]{1,64}$/.test(item.sku) || seen.has(item.sku)) fail(400, 'Invalid or duplicate SKU');
    quantity(item.quantity);
    seen.add(item.sku);
  }
  return transaction(db, () => {
    const { subtotal, snapshots } = priceItems(db, body.items);
    const discount = 0;
    const code = null;
    const shippingCents = shipping(subtotal);
    const result = db.prepare("INSERT INTO orders (status, subtotal_cents, shipping_cents, discount_cents, discount_code, total_cents) VALUES ('pending', ?, ?, ?, ?, ?)").run(subtotal, shippingCents, discount, code, subtotal - discount + shippingCents);
    const id = Number(result.lastInsertRowid);
    for (const item of snapshots) {
      db.prepare('UPDATE products SET stock = stock - ? WHERE sku = ?').run(item.quantity, item.sku);
      db.prepare('INSERT INTO order_items (order_id, sku, quantity, unit_price_cents) VALUES (?, ?, ?, ?)').run(id, item.sku, item.quantity, item.unitPriceCents);
    }
    return getOrder(db, id);
  });
}

function cancelOrder(db, id, body) {
  object(body, []);
  return transaction(db, () => {
    const order = getOrder(db, id);
    if (order.status !== 'pending') fail(409, 'Only pending orders can be cancelled');
    for (const item of order.items) db.prepare('UPDATE products SET stock = stock + ? WHERE sku = ?').run(item.quantity, item.sku);
    
    db.prepare("UPDATE orders SET status = 'cancelled' WHERE id = ?").run(id);
    return getOrder(db, id);
  });
}
module.exports = { getOrder, createOrder, cancelOrder };
