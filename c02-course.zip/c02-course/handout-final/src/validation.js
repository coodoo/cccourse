function fail(status, message) {
  throw Object.assign(new Error(message), { status });
}
function object(value, allowed) {
  if (!value || typeof value !== 'object' || Array.isArray(value) || Object.keys(value).some(key => !allowed.includes(key))) fail(400, 'Invalid request fields');
}
function quantity(value) {
  if (!Number.isSafeInteger(value) || value < 1 || value > 1000000) fail(400, 'Invalid quantity');
}
function orderId(value) {
  if (!/^[1-9][0-9]*$/.test(value) || !Number.isSafeInteger(Number(value))) fail(400, 'Invalid order id');
  return Number(value);
}
module.exports = { fail, object, quantity, orderId };
