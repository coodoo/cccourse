const { fail } = require('./validation');

function priceItems(db, items) {
  let subtotal = 0;
  const snapshots = items.map(item => {
    const product = db.prepare('SELECT * FROM products WHERE sku = ?').get(item.sku);
    if (!product) fail(400, 'Unknown SKU');
    if (product.stock < item.quantity) fail(409, 'Insufficient stock');
    subtotal += product.price_cents * item.quantity;
    if (!Number.isSafeInteger(subtotal)) fail(400, 'Order amount too large');
    return { sku: item.sku, quantity: item.quantity, unitPriceCents: product.price_cents };
  });
  return { subtotal, snapshots };
}

function shipping(subtotal) {
  return subtotal >= 5000 ? 0 : 500;
}
module.exports = { priceItems, shipping };
