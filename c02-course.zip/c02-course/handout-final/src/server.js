const { createApp } = require('./app');
const { openDatabase } = require('./db');
const db = openDatabase(process.env.DB_PATH || 'data/demo.sqlite');
const port = Number(process.env.PORT || 3000);
const server = createApp({ db }).listen(port, '127.0.0.1', () => console.log(`Orders API listening on http://127.0.0.1:${server.address().port}`));
function stop() { server.close(() => { db.close(); process.exit(0); }); }
process.on('SIGINT', stop);
process.on('SIGTERM', stop);
