const test = require('node:test');
const assert = require('node:assert/strict');
const { fixture } = require('./helpers');

test('health and seeded catalog are available', async t => {
  const { request } = await fixture(t);
  assert.deepEqual((await request('/health')).body, { ok: true });
  assert.equal((await request('/api/products')).body.length, 2);
});
test('a small order pays shipping and persists', async t => {
  const { request, order } = await fixture(t);
  const created = await order();
  assert.equal(created.status, 201);
  assert.equal(created.body.totalCents, 4500);
  assert.deepEqual((await request(`/api/orders/${created.body.id}`)).body, created.body);
});
test('large orders ship free', async t => {
  const { order } = await fixture(t);
  assert.equal((await order([{ sku: 'tea', quantity: 4 }])).body.totalCents, 5000);
});
test('payment captures the total', async t => {
  const { request, order } = await fixture(t);
  const { body } = await order();
  const paid = await request(`/api/orders/${body.id}/pay`, { idempotencyKey: 'first' });
  assert.equal(paid.body.status, 'paid');
  assert.equal(paid.body.paidCents, 4500);
});
test('pending cancellation restores stock', async t => {
  const { request, order } = await fixture(t);
  const { body } = await order();
  assert.equal((await request(`/api/orders/${body.id}/cancel`, {})).body.status, 'cancelled');
  assert.equal((await request('/api/products')).body.find(p => p.sku === 'mug').stock, 20);
});
test('missing orders return a JSON error', async t => {
  const { request } = await fixture(t);
  const result = await request('/api/orders/123');
  assert.equal(result.status, 404);
  assert.equal(typeof result.body.error, 'string');
});
