const { once } = require('node:events');
const { openDatabase, seedDatabase } = require('../src/db');
const { createApp } = require('../src/app');
async function fixture(t, supplied) {
  const db = supplied || openDatabase();
  if (!supplied) seedDatabase(db);
  const server = createApp({ db }).listen(0, '127.0.0.1');
  await once(server, 'listening');
  t.after(async () => { await new Promise(resolve => server.close(resolve)); db.close(); });
  const request = async (path, body, method = body === undefined ? 'GET' : 'POST') => {
    const response = await fetch(`http://127.0.0.1:${server.address().port}${path}`, { method, headers: { 'content-type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) });
    return { status: response.status, body: await response.json() };
  };
  const order = async (items = [{ sku: 'mug', quantity: 2 }], extra = {}) => request('/api/orders', { items, ...extra });
  return { db, request, order };
}
module.exports = { fixture };
