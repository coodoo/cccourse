const page=(title,body)=>`<!doctype html><html><head><meta charset='utf-8'><style>body{font:16px system-ui;max-width:800px;margin:45px auto;color:#24334b}input,button{padding:10px;margin:6px}button{background:#2673b8;color:white;border:0}</style></head><body><h1>${title}</h1><p><a href='/'>New order</a> · <a href='/audit'>DB audit</a></p>${body}</body></html>`
module.exports={page}
