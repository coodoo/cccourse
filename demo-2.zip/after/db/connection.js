const {DatabaseSync}=require('node:sqlite')
const fs=require('node:fs')
const path=require('node:path')
const open_db=()=>{const db=new DatabaseSync(':memory:');db.exec(fs.readFileSync(path.join(__dirname,'schema.sql'),'utf8'));return db}
module.exports={open_db}
