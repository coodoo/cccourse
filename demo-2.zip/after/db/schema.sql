CREATE TABLE customers(id INTEGER PRIMARY KEY,tier TEXT); INSERT INTO customers VALUES(1,'VIP'),(2,'REGULAR');
CREATE TABLE products(id INTEGER PRIMARY KEY,price INTEGER,discounted INTEGER); INSERT INTO products VALUES(1,1000,1),(2,300,0),(3,200,1);
CREATE TABLE orders(id INTEGER PRIMARY KEY,customer_id INTEGER,subtotal INTEGER,discount INTEGER,shipping INTEGER,status TEXT);
CREATE TABLE audit(event TEXT,order_id INTEGER);
CREATE TRIGGER audit_submit AFTER UPDATE OF status ON orders WHEN NEW.status='submitted' BEGIN INSERT INTO audit VALUES('submitted',NEW.id); END;
CREATE VIEW order_summary AS SELECT orders.*,customers.tier FROM orders JOIN customers ON customers.id=orders.customer_id;
