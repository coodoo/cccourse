const customer=(db,id)=>db.prepare('SELECT * FROM customers WHERE id=?').get(id)
const product=(db,id)=>db.prepare('SELECT * FROM products WHERE id=?').get(id)
const audit=db=>db.prepare('SELECT * FROM audit').all()
const save=(db,c,subtotal,discount,shipping)=>{db.prepare("INSERT INTO orders VALUES(1,?,?,?,?, 'draft')").run(c,subtotal,discount,shipping);db.prepare("UPDATE orders SET status='submitted' WHERE id=1").run()}
module.exports={customer,product,audit,save}
