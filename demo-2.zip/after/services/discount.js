const discount=(subtotal,tier)=>(tier==='VIP'?Math.floor(subtotal*.1):0)+(subtotal>=2000?100:0)
module.exports={discount}
