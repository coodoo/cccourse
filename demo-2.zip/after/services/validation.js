const validate=qty=>{if(qty>5)throw Error('Discounted items limited to five')}
module.exports={validate}
