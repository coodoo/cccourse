const shipping=(subtotal,tier)=>tier==='VIP'||subtotal>=1500?0:120
module.exports={shipping}
