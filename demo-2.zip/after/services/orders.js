const {open_db}=require('../db/connection')
const repo=require('../db/repository')
const {discount}=require('./discount')
const {shipping}=require('./shipping')
const {validate}=require('./validation')
const place_order=input=>{const db=open_db();try{const c=repo.customer(db,input.customer_id);if(!c)throw Error('Unknown customer');if(!input.items.length)throw Error('Empty order');let subtotal=0,discounted_qty=0;for(const item of input.items){const p=repo.product(db,item.product_id);if(!p||!Number.isInteger(item.qty)||item.qty<1)throw Error('Invalid item');subtotal+=p.price*item.qty;if(p.discounted)discounted_qty+=item.qty}
validate(discounted_qty)
const d=discount(subtotal,c.tier),s=shipping(subtotal,c.tier)
repo.save(db,input.customer_id,subtotal,d,s);return {subtotal,discount:d,shipping:s,total:subtotal-d+s,discounted_qty,audit:repo.audit(db)}}finally{db.close()}}
module.exports={place_order}
