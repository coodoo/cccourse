const {place_order}=require('./orders')
const audit_sample=()=>place_order({customer_id:1,items:[{product_id:1,qty:1}]}).audit
module.exports={audit_sample}
