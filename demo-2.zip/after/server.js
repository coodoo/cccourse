const http=require('node:http')
const {handle}=require('./web/routes')
const port=Number(process.env.PORT||3000)
http.createServer(handle).listen(port,()=>console.log('http://localhost:'+port))
