# status.md
stage: verify
state: green
