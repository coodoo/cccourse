# compatibility.md
SQLite trigger retained, shipping SQL CASE replaced by JS
