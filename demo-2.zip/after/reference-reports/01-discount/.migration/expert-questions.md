# expert-questions.md
Q1: Is discount stacking intended? Q2: Is shipping based on pre-discount subtotal?
