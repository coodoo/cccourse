# safety-net.md
Run npm test; check output, shipping, discount, DB audit
