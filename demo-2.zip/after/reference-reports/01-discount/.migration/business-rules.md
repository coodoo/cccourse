# business-rules.md
VIP 10% discount, bulk >=2000 minus 100, free shipping for VIP or subtotal >=1500
