# system-map.md
HTTP → route → order service → repository → SQLite trigger; discount, shipping, validation workflows
