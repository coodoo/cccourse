# charter.md
Scope discount parity
