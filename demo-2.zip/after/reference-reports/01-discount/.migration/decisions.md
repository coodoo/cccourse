# decisions.md
Choose bounded slice; preserve parity except approved new rule
