# behavior-deltas.md
Exercise 3 intentionally rejects more than five discounted units
