# slices/first/plan.md
Extract bounded service; tests before code; rollback to legacy
