# slices/first/rollout.md
Lab-only, no production deployment
