# slices/first/verification.md
Run tests and compare before/after; six discounted items are intentional difference
