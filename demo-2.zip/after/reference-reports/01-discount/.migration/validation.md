# validation.md
Synthetic classroom assumption: both answers yes. Not an actual interview.
