# inventory.md
HTTP, services, repository, SQLite, trigger and view
