# devlog.md
Synthetic reference sequence, not actual Codex logs
