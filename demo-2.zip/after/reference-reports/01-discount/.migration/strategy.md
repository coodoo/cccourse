# strategy.md
Extract one business rule at a time, preserve behavior and rollback path
