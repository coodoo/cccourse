# charter.md
Scope shipping parity
