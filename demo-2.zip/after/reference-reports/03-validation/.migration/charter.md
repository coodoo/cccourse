# charter.md
Scope validation plus new quantity limit
