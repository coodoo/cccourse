# Synthetic legacy migration lab
Node.js built-in HTTP + SQLite, no Express or npm dependencies. Node 22.16+ (Node 24 recommended).

Run `cd before && npm start` then visit http://localhost:3000. Run `cd after && PORT=3001 npm start` to compare. `npm test` in each directory.

Three exercises: instructor discount migration (parity), student shipping migration (parity), student validation migration plus new maximum five discounted items per order.

The `after/reference-reports/` folders contain **synthetic teaching examples** of the ten-skill intermediate documents, not actual Codex runs. Database is reset per request (in-memory) to keep demos deterministic.
