# Using the original migration suite

Use the skills as a decision loop supported by persistent evidence. Run the initial discovery sequence once for the engagement, then repeat the relevant discovery and protection for each domain and slice. A failed gate sends you back to the earliest prerequisite that the evidence invalidates.

Start with the [worked project](project/README.md) and its saved [.migration records](project/.migration/status.md) if you want to teach the outputs without installing anything. The project is synthetic and its executable baseline is Java. Oracle source analysis, planned modern frameworks and production operations are explicitly separate from observed results.

## Install all eleven skills

The source bundle contains one orchestrator named `ai-migration` and ten stage skills. [Original SKILL.md, line 2](../ai-migration-skill/SKILL.md#2) supplies the orchestrator name; [USAGE.md, line 9](../ai-migration-skill/references/USAGE.md#9) installs only the stages.

The current official guide documents user skills under `~/.agents/skills` and repository skills under `.agents/skills`, with explicit `$skill-name` invocation. These locations and syntax are Codex guidance; do not assume another agent host uses identical discovery. [Official skill documentation](https://learn.chatgpt.com/docs/build-skills).

The following is an installation recipe for the owner to run from this training repository's root. It has not been executed as part of this worked run. It refuses existing destinations and copies only this suite into the user directory that the original orchestrator already searches. Review the source before installing it for use on real repositories.

```sh
python3 - <<'PYINSTALL'
from pathlib import Path
import shutil
src = Path('c03-migration-v1-首次寫好 skills/ai-migration-skill')
dst = Path.home() / '.agents' / 'skills'
stages = sorted(p for p in (src / 'skills').iterdir() if p.is_dir() and (p / 'SKILL.md').is_file())
assert len(stages) == 10
assert all((p / 'SKILL.md').is_file() for p in stages)
assert not any((dst / name).exists() for name in ['ai-migration'] + [p.name for p in stages])
dst.mkdir(parents=True, exist_ok=True)
orch = dst / 'ai-migration'
orch.mkdir()
shutil.copy2(src / 'SKILL.md', orch / 'SKILL.md')
shutil.copytree(src / 'references', orch / 'references')
for stage in stages:
    shutil.copytree(stage, dst / stage.name)
print('Copied orchestrator and 10 stages; verify discovery in Codex.')
PYINSTALL
```

Open Codex in the legacy repository, use `/skills` or the `$` selector and confirm `ai-migration` plus all ten `migration-*` stages appear. Restart Codex if discovery does not refresh. Do not proceed on the assumption that copied files were loaded. If a name is absent, inspect the copied folder and manifest rather than asking the model to guess its instructions. [Official discovery and invocation guidance](https://learn.chatgpt.com/docs/build-skills).

The ten stage metadata files set explicit invocation policy; for example [migration-intake/agents/openai.yaml, line 2](../ai-migration-skill/skills/migration-intake/agents/openai.yaml#2). Use an explicit stage mention or tell the orchestrator to read and apply the exact stage file. The host catalog is the practical discovery check; listing files alone does not test invocation.

For repository-only installation, keep the same eleven sibling folders under `<legacy-repo>/.agents/skills`. The older orchestrator's [lookup list, line 86](../ai-migration-skill/SKILL.md#86) names user roots, so supply the actual repository stage path if its lookup fails. This run avoids discovery assumptions by reading the exact original files directly; that proves stage application, not UI discovery or a global installation.

## Choose how to drive the suite: four orchestrator modes

You do **not** have to invoke every `$migration-*` skill manually. There are two supported ways to drive the same process: ask `$ai-migration` to select and execute the next stage, or invoke a stage yourself when you already know which prerequisite needs work. The stage-by-stage prompts below demonstrate the second route; they are separate invocations, not one batch to paste and run without checkpoints.

Modes are inferred from your wording; the suite defines no `--mode` flag, persisted mode setting or default that automatically runs all stages. State the action explicitly. A bare `$ai-migration` is not an instruction to complete the entire migration. See [ai-migration/SKILL.md, line 58](../ai-migration-skill/SKILL.md#58).

- **Coach — explain the next action.** The agent checks project state, explains the current stage, what you need to prepare and review, and supplies the exact next prompt. It does not perform a large stage unless you ask it to run. See [ai-migration/SKILL.md, line 60](../ai-migration-skill/SKILL.md#60).

- **Continue — execute the next selected stage.** The agent checks evidence, selects the earliest materially unmet prerequisite, reads the complete corresponding stage skill and performs it. This can revisit an earlier stage; it is not simply the next name in the sequence. See [ai-migration/SKILL.md, line 74](../ai-migration-skill/SKILL.md#74) and [routing, line 204](../ai-migration-skill/SKILL.md#204).

- **Status — assess readiness.** The agent reads `.migration/` and supporting evidence, then reports the current stage and missing prerequisites. Ask explicitly for no implementation when you only want an assessment. See [ai-migration/SKILL.md, line 94](../ai-migration-skill/SKILL.md#94).

- **Review/monitor — inspect process health.** The agent loads `migration-monitor` to inspect drift, stagnation, missed coverage, unsupported claims and verification debt. This health check does not replace slice verification. Use a separate context for independent review; the mode itself does not create one. See [ai-migration/SKILL.md, line 105](../ai-migration-skill/SKILL.md#105).

Each block below is a separate prompt, not a command-line option:

**Coach prompt**

```text
$ai-migration
Coach me: inspect the current migration state and explain the next safe stage.
Give the exact next prompt and checkpoint. Do not execute the stage yet.
```

**Continue prompt**

```text
$ai-migration
Continue: select the earliest unmet prerequisite and execute that one stage.
Locate, read in full and apply its migration-* SKILL.md; do not substitute a summary.
Follow the charter's authorized scope. Stop at its checkpoint and report evidence or blockers.
No production operations. Do not advance into another stage in this invocation.
```

**Status prompt**

```text
$ai-migration
Report migration status: current stage, current slice, missing evidence and next safe action.
Check actual evidence against exit criteria. Do not implement or execute a migration stage.
```

**Review/monitor prompt**

```text
$ai-migration
Review migration process health using migration-monitor.
Report GREEN/YELLOW/RED with evidence and the smallest corrective action. Do not implement.
Return findings to the migration record owner for integration; do not edit shared records concurrently.
```

For a first engagement, use Coach if you need help preparing inputs, then Continue with the goals and constraints from the intake example below. With no `.migration/`, the orchestrator normally selects intake. Review the outputs, then request Continue again when the checkpoint permits progress. After recon, choose a candidate workflow using the [scope handoff](#when-to-choose-the-first-function) before continuing into business-logic recovery. Repeat this interaction through discovery and the first slice; use Status after interruption and Review/monitor when progress looks unhealthy.

The source describes selecting and executing the next stage, but does not specify a complete unattended multi-stage loop or its stopping policy. The one-stage stop in the example makes your requested boundary explicit. It does not guarantee that a very large recon stage fits in one context: save partial coverage and resume it until its exit criteria are satisfied. Human approval, access and unresolved high-risk prerequisites still control progress.

If you prefer direct control, invoke `$migration-recon`, `$migration-bizlogic` or another stage yourself with the same scope and checkpoints. Even in Continue mode, the orchestrator must read the actual stage file. All ten stages use explicit-invocation metadata; do not rely on automatic semantic triggering. If a stage cannot be located or read, provide its actual installed path or repair installation; do not ask the agent to invent the instructions. See [ai-migration/SKILL.md, line 92](../ai-migration-skill/SKILL.md#92) and [migration-recon/agents/openai.yaml, line 2](../ai-migration-skill/skills/migration-recon/agents/openai.yaml#2).

## Prepare the first session

Make source, build/run instructions, database schema and stored-code exports, configuration, test data and existing migration documents available through authorized access. Record what is missing. A source export cannot prove runtime calls, external dependencies or transaction behavior by itself.

A fixed Spring Boot/Vue/PostgreSQL/queue destination is a constraint to record, not permission to change every subsystem. Business-rule changes and migration parity need separate acceptance. If the original experts are gone, use no-expert validation and keep unresolved intent visible.

The intake instruction is [migration-intake/SKILL.md, line 16](../ai-migration-skill/skills/migration-intake/SKILL.md#16). A compact first prompt is:

```text
$migration-intake
Initialize .migration for this Java/Oracle monolith. Preserve current behavior.
Target constraints: Spring Boot API, Vue UI; PostgreSQL and queue changes require separate proven slices.
Use source and safe nonproduction evidence. Record unavailable environments and unknown intent.
Allow local analysis, tests and scoped code only; no production writes/cutover or destructive operations.
Do not implement yet. Save charter, status, decisions and progress.md; identify missing discovery inputs.
```

The charter should let a fresh agent determine the goal, fixed decisions, permitted work, prohibited actions and observable success. Review it before moving on. An agent's GREEN assessment does not supply missing access or business authority.

## When to choose the first function

**Intake and broad recon are engagement-wide. Choose the first candidate workflow after recon and before focused business-logic recovery (`migration-bizlogic`).** You can enter intake without knowing which function to rewrite first. You do need goals, constraints and authorized access. If the business already has a priority, record it as a candidate during intake and use recon to check its dependencies and feasibility.

Here, “repo-wide” means all authorized source roots and related database, job and integration surfaces in the engagement. It means inventory and a useful high-level map, not recovering every business rule or reading every source line before choosing a function. Recon may investigate selected flows to make that map useful.

There are two different choices: a **candidate workflow** is the business operation worth investigating first, such as “calculate an order quote”; an **execution slice** is the exact small change later protected, designed and planned for implementation. Choosing the candidate does not authorize rewriting it or freeze its final boundary.

```text
Intake → broad recon                         engagement-wide
             ↓
Human chooses a candidate workflow           first scope decision
             ↓
Business logic → validation                  candidate + relevant dependencies
             ↓
Safety net → transition design               protect behavior; define a safe seam
             ↓
Slice plan                                   finalize the small implementation boundary
             ↓
Execute → verify                             implement and prove that slice
```

The source supports this distinction: [migration-recon/SKILL.md, line 83](../ai-migration-skill/skills/migration-recon/SKILL.md#83) ends recon when the topology is useful enough to identify candidate boundaries; [migration-bizlogic/SKILL.md, line 45](../ai-migration-skill/skills/migration-bizlogic/SKILL.md#45) already expects a current domain or candidate area. Later, [migration-slice/SKILL.md, line 16](../ai-migration-skill/skills/migration-slice/SKILL.md#16) selects and prepares the actual vertical slice.

**The updated skills enforce this handoff:** recon presents candidate workflows; the orchestrator and direct bizlogic entry reuse a clear applicable owner choice or ask with concrete candidates before target-dependent work. A recommendation alone is not a choice. Missing or ambiguous selection pauses dependent tracing and downstream work, while summaries and already-authorized bounded selection support may continue. Recon can be complete while selection is pending; no extra stage is required.

At the end of recon, ask the agent to recommend a short list of candidate workflows from `system-map.md`, `coverage.md` and `unknowns.md`. For each candidate, explain the business value, visible entry point, dependencies, risks, available baseline/test environment and unresolved facts that could block migration. Prefer a useful, observable, bounded and reversible pilot; the smallest source file alone is not a good selection criterion.

The human then chooses one candidate or requests a bounded investigation if the evidence cannot support a choice. Save the choice and its reason in `.migration/decisions.md`; put the selected workflow, remaining blockers and next action in `.migration/status.md`. Existing authorization for that same candidate suffices. Do not keep scanning the whole repo just because no candidate has been chosen.

For example, after recon you can use this constructed Coach prompt:

```text
$ai-migration
Coach only. From recon evidence, recommend a short list of first candidate workflows.
Explain value, entry points, dependencies, risks, available baseline/test environment and blocking unknowns.
Recommend one and ask me to choose. If evidence is insufficient, identify the smallest useful investigation.
Do not execute another migration stage or implement code.
```

After choosing, make the scope explicit in the next Continue request:

```text
$ai-migration
I choose <candidate workflow> for focused investigation; record this choice and reason: <reason>.
Continue with the earliest unmet prerequisite for this candidate and its relevant dependencies.
If recon is sufficient, load migration-bizlogic and trace this workflow end to end.
Stop at the selected stage checkpoint. Do not implement or authorize production operations.
```

If you invoke stages directly, give the same selected workflow to `$migration-bizlogic`; replace `<candidate workflow>` in the later examples with that choice. In this worked example, choose **calculate an order quote** first: S-01 replaces `LegacyQuote.quote` through `Bridge.quote → Target.quote`, preserving decimal multiplication, two-decimal `HALF_UP`, quantity errors and the optional reason. It changes no order state; `quote_price` is inspected-only Oracle source. Order submission with credit/audit effects is the later S-02 workflow. Follow [the instructor demo and two student labs](exercises.md): distribute the ready-to-use `project/legacy/` directory, demonstrate its S-01 folder, then have students independently migrate accepted/idempotent orders (E-01) and rejection/failure recovery (E-02). This is the fixture’s teaching order, not a universal repository recommendation.

From business-logic recovery onward, focus on the candidate and everything needed to explain and protect its behavior. Shared packages, triggers, jobs or integrations can lead outside its module. Expand investigation when evidence requires it; revisit or shrink the candidate if the boundary becomes unsafe. Before safety-net capture, identify the candidate behavior and effects to protect; at `migration-slice`, finalize exact entry points, files, invariants, checks and rollback limits. Do not wait until slice planning to decide what workflow the preceding stages were studying.

## Why `.migration/progress.md` exists

This file is deliberately created by the migration suite. [migration-intake/SKILL.md, line 30](../ai-migration-skill/skills/migration-intake/SKILL.md#30) requires intake to create missing `status.md`, `progress.md` and `decisions.md`; all ten stage skills include an instruction to update migration status and progress log before finishing, for example [migration-recon/SKILL.md, line 12](../ai-migration-skill/skills/migration-recon/SKILL.md#12). The agent writes these files while applying the instructions; there is no bundled background logger or hook producing them.

The suite calls `.migration/` persistent project memory ([migration-recon/SKILL.md, line 6](../ai-migration-skill/skills/migration-recon/SKILL.md#6)), but does not separately define the progress log's format or full purpose. Following its monitor usage and the worked example, this manual uses the progress log to retain the sequence of migration work across stages, slices and fresh conversations: what was attempted, what changed the understanding, why work stopped or returned to an earlier stage, and where the supporting evidence lives. This helps the next agent and a human reviewer explain how the current state was reached. The monitor explicitly inspects it ([migration-monitor/SKILL.md, line 24](../ai-migration-skill/skills/migration-monitor/SKILL.md#24)) and writes a concise monitor entry ([line 46](../ai-migration-skill/skills/migration-monitor/SKILL.md#46)).

Use the following division of responsibility as operating guidance for reading and maintaining the records:

- **`status.md`: Where are we now?** Current stage/slice, readiness, blockers and next safe action. A current summary can change as work advances.

- **`progress.md`: How did we get here?** A concise chronological history of meaningful work, failures, discoveries and revisits, with evidence links. It should not duplicate every command output or whole stage report.

- **`decisions.md`: What did we choose, and why?** Migration decisions, rationale, constraints and approval boundaries; link the relevant decisions from work history rather than copying them.

- **Stage and slice records: What supports the claim?** Coverage, rules, tests, implementation and verification retain detailed scope and evidence. A progress log entry saying a check passed cannot replace that proof.

The original suite does not define a strict progress log schema, timestamp format or append-only contract. The concise chronological use above is operating guidance; the [worked progress log](project/.migration/progress.md) illustrates it with numbered entries. Its S-02 entries show an initial parity failure, a return to business-rule recovery/validation/safety-net, then a correction and independent verification. [Current status](project/.migration/status.md) summarizes the resulting local success and production HOLD without repeating that whole sequence.

The filename `progress.md` distinguishes this migration history from aglite’s `*.devlog.md` notebooks. This migration progress log is independent of an aglite/Agentflow notebook such as this training repository's `.agentflow/courses.devlog.md`. The migration suite can run without aglite: it owns a domain-specific migration history, while aglite records the owner's requests, replies and overall development workflow. Installing both does not automatically synchronize them or give either file precedence over the other's rules.

When using both, keep detailed migration history/evidence under `.migration/` and link it from the workflow notebook; retain the workflow's required owner input, replies and recovery state there. Have one record owner integrate stage and monitor findings. This linking convention avoids copying full reports into two logs; it is manual operating guidance, not an implemented integration or permission to stop updating either required record.

## First pass: inventory to a candidate slice

1. **Recon — engagement-wide.** Apply [migration-recon/SKILL.md, line 18](../ai-migration-skill/skills/migration-recon/SKILL.md#18). Enumerate modules, deployables, Java entry points, Oracle executable objects, jobs and integrations before deep reading. Require each discovered area in coverage, with exclusions explained. Inspect an independent sample of excluded and low-risk areas. Before step 2, use the [candidate-selection handoff](#when-to-choose-the-first-function): review recommendations, choose a workflow and record the choice.

2. **Business logic.** Apply [migration-bizlogic/SKILL.md, line 16](../ai-migration-skill/skills/migration-bizlogic/SKILL.md#16) to the candidate domain. Trace entry → Java → SQL/package → triggers/jobs/tables → downstream effects. A package list without callers, effects and example behavior is insufficient.

3. **Validation.** Apply [migration-validate/SKILL.md, line 16](../ai-migration-skill/skills/migration-validate/SKILL.md#16). Ask only material questions not cheaply answerable from evidence. With no experts, triangulate behavior and preserve unknown intent. Do not turn a role-played answer into approval.

4. **Safety net.** Apply [migration-safety-net/SKILL.md, line 16](../ai-migration-skill/skills/migration-safety-net/SKILL.md#16). Capture representative old-system outputs and effects before target replacement. Preserve provenance and hashes. Include failures, boundaries, retries and relevant state, then demonstrate that an intentionally bad target is caught.

5. **Transition design.** Apply [migration-design/SKILL.md, line 16](../ai-migration-skill/skills/migration-design/SKILL.md#16). Decide the seam, ownership, coexistence, target compatibility and recovery. A smaller reversible change may retain Oracle while a new application path is proven.

6. **Slice plan.** Apply [migration-slice/SKILL.md, line 16](../ai-migration-skill/skills/migration-slice/SKILL.md#16). Name exact entry points, dependencies, files, invariants, tests, deltas, stop conditions and rollback limits. The candidate workflow was chosen after recon, before step 2; this stage selects and finalizes its execution-ready slice boundary. Revisit protection or design if that boundary changes.

7. **Execute.** Apply [migration-execute/SKILL.md, line 18](../ai-migration-skill/skills/migration-execute/SKILL.md#18). Recheck plan and protection, make small changes, build/test, compare and inspect scope. Stop if new facts invalidate the boundary; record what must be revisited.

8. **Verify.** Apply [migration-verify/SKILL.md, line 16](../ai-migration-skill/skills/migration-verify/SKILL.md#16) from a fresh reviewer context when possible. Compare responses and side effects, classify differences and record exact evidence. A missing required environment keeps the corresponding claim unproved.

Use these prompts as constructed examples, adapted to the real repository. They are not a transcript of commands typed into a separate Codex UI during this demonstration.

```text
$migration-recon
Inventory Java, Oracle, jobs and integrations deterministically; map breadth before depth.
Save counts, source identities, coverage, system-map, evidence and unknowns. No implementation.

$migration-bizlogic
Trace <candidate workflow> across application, PL/SQL, triggers, jobs and downstream effects.
Record rules with source/line evidence, executable examples, confidence and unknown intent.

$migration-validate
Use current evidence to resolve material assumptions for <candidate workflow>.
No original experts are available. Triangulate behavior; preserve unresolved intent and contradictions.

$migration-safety-net
Capture <candidate workflow> legacy behavior and all relevant side effects in nonproduction.
Freeze baseline/provenance before replacement; test edge/error cases and a faulty target.

$migration-design
Design the smallest transition for <candidate workflow> using charter constraints.
Specify seam, coexistence, writer/data ownership, transaction effects, checks and rollback limits.

$migration-slice
Plan <slice-id> from current evidence. Name exact scope, files, invariants, scenarios, deltas and stop conditions.
Verify current safety-net coverage. Do not implement yet.

$migration-execute
Implement prepared <slice-id> only. Build/test, compare legacy behavior and side effects after each meaningful change.
Stop on unexplained material differences or invalidated dependencies; save discoveries and implementation notes.

$migration-verify
Independently inspect <slice-id> plan, code, baseline and deltas; run required comparisons and recovery checks.
Classify every material difference. Save verification and rollout limits; unavailable proof remains HOLD.
```

For orchestration instead of direct stage invocation, use the [four-mode prompts](#choose-how-to-drive-the-suite-four-orchestrator-modes). Name the authorized scope and checkpoint when continuing; a continuation request does not authorize production cutover.

## Repeat by domain and slice

The normal shape is:

```text
engagement: intake → broad recon → choose candidate → rules/validation
                         ↓
first slice: safety-net → transition design → slice plan → execute → verify
                         ↑                                │
                         └── new facts / failed gate ─────┘

next slice: refresh rules/validation → plan + current safety-net → execute → verify
                              ↑                                  │
                              └── revisit affected prerequisites ┘
```

The short `slice → execute → verify` loop in [USAGE.md, line 32](../ai-migration-skill/references/USAGE.md#32) assumes prerequisites remain satisfied. Do not reuse a quote-only baseline to approve an order-writing slice. Each new slice needs its own observable behavior and effects protected; a shared dependency change can invalidate prior proof.

For a huge repository, use the [large-repository exploration policy](#explore-a-repository-with-millions-of-lines). A fresh worker loads the charter, relevant coverage/rules/unknowns and current slice rather than rereading every global report on each turn.

In this worked run, S-01 quotes expose a rounding mismatch. S-02 writes expose missing credit/audit effects, which drive a revisit to business rules, validation and protection before corrected verification. Those are deliberately planted teaching defects with actual comparisons, not blind-discovery performance measurements. See [run-log.md](run-log.md).

## Explore a repository with millions of lines

The intended process does **not** require the model to read every source line in one pass. `ai-migration` first inspects migration state and routes the work; `migration-recon` performs inventory and system mapping. Tool-based inventory may traverse the entire authorized repository or search its contents, but enumeration and search are different from sending every file into the model's context. See [ai-migration/SKILL.md, line 157](../ai-migration-skill/SKILL.md#157) and [migration-recon/SKILL.md, line 18](../ai-migration-skill/skills/migration-recon/SKILL.md#18).

The suite already specifies these ways to limit exploration cost:

- **Inventory with tools before reasoning deeply.** Enumerate repositories, modules, deployables, entry points, database objects, jobs and integrations with commands/scripts where practical. This establishes the surfaces to account for. See [migration-recon/SKILL.md, line 20](../ai-migration-skill/skills/migration-recon/SKILL.md#20).

- **Breadth before depth.** Map business/runtime flows and subsystems before implementation details. Deep investigation should resolve a material unknown or affect a migration decision; redirect work that does neither. See [migration-recon/SKILL.md, line 42](../ai-migration-skill/skills/migration-recon/SKILL.md#42) and [line 81](../ai-migration-skill/skills/migration-recon/SKILL.md#81).

- **Track partial coverage honestly.** Every discovered area receives `uninspected`, `sampled`, `mapped`, `deep-reviewed`, `excluded` or `unresolved`; an inventory entry does not mean its code was understood. See [migration-recon/SKILL.md, line 40](../ai-migration-skill/skills/migration-recon/SKILL.md#40).

- **Partition deeper work and reconcile dependencies.** The field guide recommends domain/module/runtime partitions, fresh-context workers for independent areas, a cross-cutting merge and an audit of excluded or uncovered areas. It explicitly says not to require every line to be read. These are guide instructions, not a built-in parallel scheduler, and neither the orchestrator nor recon skill explicitly references this guide. Include the policy in a large-repository prompt. See [FIELD-GUIDE.md, line 164](../ai-migration-skill/references/FIELD-GUIDE.md#164) and [line 197](../ai-migration-skill/references/FIELD-GUIDE.md#197).

- **Persist evidence and migrate one slice at a time.** Repository records allow a fresh context to resume relevant work instead of reconstructing the entire system. Revisit affected prerequisites when new discoveries invalidate them. See [ai-migration/SKILL.md, line 123](../ai-migration-skill/SKILL.md#123), [line 312](../ai-migration-skill/SKILL.md#312) and [USAGE.md, line 39](../ai-migration-skill/references/USAGE.md#39).

The field guide also recommends stopping repeated failed exploration, avoiding unused giant reports, matching model cost to mechanical versus high-risk reasoning work, and creating workers only for useful bounded partitions. These are optional cost controls, not automatically selected models or enforced worker limits. See [FIELD-GUIDE.md, line 413](../ai-migration-skill/references/FIELD-GUIDE.md#413) and [line 1105](../ai-migration-skill/references/FIELD-GUIDE.md#1105).

These are exploration policies in Markdown prompts. The bundle ships no scanning engine, persistent symbol index, automatic hash-based incremental scanner, dependency-aware cache invalidation, enforced context budget or automatic partition scheduler. An agent can create inventory tooling during a run, but the suite does not guarantee those optimizations. It also supplies no million-line benchmark or measured token/time savings. The small worked example demonstrates the process, not enterprise-scale scanning performance.

For a large repository, add an explicit operating policy rather than assuming the model will implement the guide's recommendations. The block below is a suggested run configuration, not a claim that the original skill already enforces incremental scanning:

```text
$migration-recon
This repository has millions of lines. Apply the huge-system policy in <installed-ai-migration>/references/FIELD-GUIDE.md.
Inventory all authorized source roots, deployables, DB executable objects, jobs and integrations with tools first.
Record inventory commands, source revisions, missing inputs and coverage states.
Identify generated/vendor/build artifacts; record exclusions with reasons. Have an independent reviewer sample excluded and low-risk areas for missed cross-cutting dependencies.
Map top-level runtime boundaries before deep reading. Deep-read candidate flows and high-risk dependencies.
Partition deeper recon by domain/runtime boundary. Give each worker a bounded scope, output, coverage responsibility, evidence requirements and merge point.
Use separate workers only where the host supports them and project rules authorize delegation.
Per bounded pass, save new evidence, coverage changes, unknowns and next partition; report partial work honestly.
Reuse evidence after checking source/config/schema/environment identity. Reinspect changed surfaces and affected dependencies; refresh broader inventory when needed.
Complete recon when major discovered surfaces are accounted for and topology identifies candidate boundaries. Record high-risk unknowns for later recovery/validation.
Do not claim every line was read or all business rules recovered. No implementation, production operations or advance into another stage.
```

For the user installation above, replace `<installed-ai-migration>` with `~/.agents/skills/ai-migration`; for a repository installation, use its actual directory. Resume an unfinished recon pass before moving forward; do not mistake a partial partition report for stage completion. Assign one record owner to integrate findings, and check shared database/transaction boundaries and integrations across partitions. Source search alone cannot prove a procedure unused or reveal all runtime behavior.

## Monitor and recover

Apply [migration-monitor/SKILL.md, line 18](../ai-migration-skill/skills/migration-monitor/SKILL.md#18) independently at a milestone or when progress looks unhealthy:

```text
$migration-monitor
Read status, coverage, unknowns, evidence, current slice and actual diffs/checks independently.
Return GREEN/YELLOW/RED with concrete signals and smallest corrective action. Do not implement.
Give findings to the record owner; avoid concurrent edits to shared migration records.
```

The final record-owner instruction resolves the original monitor's [unconditional preamble, line 12](../ai-migration-skill/skills/migration-monitor/SKILL.md#12) versus [conditional status update, line 46](../ai-migration-skill/skills/migration-monitor/SKILL.md#46). One owner integrates findings after reviewing them. Separate context provides a different check, not proof of correctness.

Before resuming, inspect actual source identity and checks against the saved status. A report named `verification.md` is not proof that it passed. If a required environment is missing, save the blocker and next action; do useful independent work without relabeling a model as the missing system.

If a target mismatch occurs, preserve the failed input/output first. Determine whether it is a regression, a previously approved delta, legitimate normalization or unexplained. Repair only after the cause is understood. If a trigger changes the slice's writer boundary, revisit business logic and design rather than merely updating an expected value.

## Read the reports in class

Start with [project/.migration/charter.md](project/.migration/charter.md): ask students to identify permitted work and the difference between a desired target and a proven target.

Then open [inventory.md](project/.migration/inventory.md), [coverage.md](project/.migration/coverage.md) and [system-map.md](project/.migration/system-map.md). Have them trace one entry through Java and the database source, and explain which surfaces are unexecuted or outside the slice.

Read [business-rules.md](project/.migration/business-rules.md), [unknowns.md](project/.migration/unknowns.md) and [validation.md](project/.migration/validation.md). Ask which statements are observed, inferred, corrected or unresolved. A missing business expert should remain visible rather than be replaced by an invented interview.

Use [safety-net.md](project/.migration/safety-net.md) to find the actual capture/replay commands. Run the bad target and inspect the saved mismatches before showing the correction. Explain why a target return value can match while database-side credit/audit effects differ.

Compare S-01 and S-02 [plans](project/.migration/slices/S-01/plan.md) and [verification](project/.migration/slices/S-02/verification.md). Show the revisit in [progress.md](project/.migration/progress.md), then contrast model-level parity with the production HOLD in [status.md](project/.migration/status.md).

End with [strategy.md](project/.migration/strategy.md) and [S-02 rollout.md](project/.migration/slices/S-02/rollout.md). Ask students what additional evidence is required for real Oracle, target database ownership, duplicate deliveries, post-switch data and production rollback. Passing local comparisons supports the local claim; it does not answer those untested questions.

## Guide ownership

This manual owns installation and operating guidance; [assessment.md](assessment.md) owns findings and recommendations. [project/README.md](project/README.md) owns exact executable commands and runtime scope, while [run-log.md](run-log.md) owns the observed stage sequence. [project/legacy/exercises.md](project/legacy/exercises.md) owns all three practice briefs and the step-by-step flow; [exercises.md](exercises.md) is the distribution entry point. `exercises/check.py` and `exercises/ExerciseScenario.java` own the common check sources; keep their three distributed `project/legacy/{S-01,E-01,E-02}/tools/` copies identical. The distributed `project/legacy/skills/` snapshot must match `../ai-migration-skill/` when the source skills change. Each practice folder owns its unfinished target and frozen inputs. The original project owns the completed S-01/S-02 solution. Slice records own their boundaries and proof. Update their dependent links/examples if commands, paths, source skill instructions or the demonstration's evidence scope change.
