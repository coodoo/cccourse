-- Inspected fictional Oracle source; not executed or translated by this example.
CREATE TABLE customer_credit(customer_id NUMBER PRIMARY KEY, available NUMBER(12,2));
CREATE TABLE stock(sku VARCHAR2(20) PRIMARY KEY, available NUMBER CHECK(available >= 0));
CREATE TABLE orders(order_key VARCHAR2(40) PRIMARY KEY, customer_id NUMBER, amount NUMBER(12,2));
CREATE TABLE order_audit(order_key VARCHAR2(40), amount NUMBER(12,2));
CREATE TABLE event_outbox(order_key VARCHAR2(40), kind VARCHAR2(40));
CREATE TABLE callback_config(callback_name VARCHAR2(128));
CREATE OR REPLACE FUNCTION quote_price(p_unit NUMBER,p_qty NUMBER) RETURN NUMBER IS
BEGIN RETURN ROUND(p_unit*p_qty,2); END;
/
CREATE OR REPLACE TRIGGER order_credit_audit AFTER INSERT ON orders FOR EACH ROW
BEGIN
 UPDATE customer_credit SET available=available-:new.amount WHERE customer_id=:new.customer_id;
 INSERT INTO order_audit VALUES(:new.order_key,:new.amount);
END;
/
CREATE OR REPLACE PROCEDURE submit_order(p_key VARCHAR2,p_customer NUMBER,p_qty NUMBER,p_amount NUMBER) IS
BEGIN
 UPDATE stock SET available=available-p_qty WHERE sku='TEA';
 INSERT INTO orders VALUES(p_key,p_customer,p_amount);
 INSERT INTO event_outbox VALUES(p_key,'OrderAccepted');
END;
/
CREATE OR REPLACE PROCEDURE nightly_reconcile IS
 v_callback VARCHAR2(128);
BEGIN
 SELECT callback_name INTO v_callback FROM callback_config;
 EXECUTE IMMEDIATE 'BEGIN '||DBMS_ASSERT.QUALIFIED_SQL_NAME(v_callback)||'; END;';
END;
/
BEGIN DBMS_SCHEDULER.CREATE_JOB(job_name=>'NIGHTLY_RECONCILE',job_type=>'STORED_PROCEDURE',job_action=>'NIGHTLY_RECONCILE',start_date=>SYSTIMESTAMP,repeat_interval=>'FREQ=DAILY',enabled=>FALSE); END;
/
