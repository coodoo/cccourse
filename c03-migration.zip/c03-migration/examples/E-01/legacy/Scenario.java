final class Scenario {
 public static void main(String[] args){
  String mode=args[0],slice=args[1];
  if(slice.equals("S-01")){
   quote(mode,"boundary","1.005",1,null);quote(mode,"multiple","2.335",3,"");quote(mode,"reason","10",2,"VIP");quote(mode,"invalid","1",0,null);return;
  }
  State s=new State();order(mode,s,"accept","a",2,200,false);order(mode,s,"retry","a",2,200,false);
  order(mode,s,"conflict","a",2,201,false);order(mode,s,"stock","b",8,100,false);order(mode,s,"credit","c",1,900,false);
  order(mode,s,"invalid","d",0,100,false);order(mode,s,"rollback","e",1,100,true);order(mode,s,"retry-after-failure","e",1,100,false);
 }
 static void quote(String mode,String label,String p,int q,String reason){
  String result=mode.equals("legacy")?LegacyQuote.quote(p,q,reason):Bridge.quote(mode,p,q,reason);
  System.out.println(label+"="+result);
 }
 static void order(String mode,State s,String label,String key,int q,int amount,boolean fail){
  String result=mode.equals("legacy")?LegacyOrders.submit(s,key,q,amount,fail):Bridge.order(mode,s,key,q,amount,fail);
  System.out.println(label+"="+result+"|"+s.snapshot());
 }
}
