---
name: migration-slice
description: Select and plan the next small, representative, reversible vertical migration slice with explicit behavior, dependencies, verification, and rollback.
---

Use `.migration/` as the persistent project memory. Preserve existing artifacts and update them rather than silently replacing prior conclusions.

Classify material claims as **Observed**, **Inferred**, **Unknown**, or **Contradicted**. Important claims need evidence.

Never perform production writes, destructive database operations, production cutover, or irreversible actions unless separately and explicitly authorized.

Update `.migration/status.md` and `.migration/progress.md` before finishing.

# Migration Slice

Goal: select the next vertical slice and make it execution-ready. Do not implement it in this skill.

Use the selected workflow in owner instructions/`decisions.md`; workflow selection happened before focused bizlogic. If missing or ambiguous, ask for selection before target-dependent planning. Check that discovery, validated rules, safety-net and design cover the proposed boundary; revisit unmet prerequisites, including dependencies or a changed workflow. This stage selects a small implementation change within that workflow; neither workflow choice nor this plan grants additional execution authority.

Choose a slice that is:

- real enough to validate the migration approach
- bounded in blast radius
- observable/testable
- reversible
- limited in dependencies
- representative of important legacy mechanics
- not needlessly mission-critical for the first pilot

Avoid choosing a slice solely because its code is easy.

Create `.migration/slices/<slice-id>/plan.md` with:

- objective
- entry points
- current runtime path
- affected Java modules
- affected DB/PLSQL objects
- integrations
- current behavior
- intentional new behavior, if any
- invariants
- dependencies
- transaction/data implications
- characterization tests
- exact implementation steps
- likely files/components to change
- verification plan
- rollout/rollback plan
- out-of-scope
- stop conditions
- unresolved assumptions

If migration and a new feature are combined, make migration parity and intentional business deltas independently visible through `behavior-deltas.md`.

Reject or shrink the slice if safe verification requires undefined work across many unrelated domains/teams.

Exit only when the slice can be summarized as:

`understand -> test -> implement -> compare -> deploy -> roll back`
