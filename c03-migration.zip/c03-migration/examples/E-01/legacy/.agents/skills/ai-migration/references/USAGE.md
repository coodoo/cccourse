# Codex Skill Bundle Usage

These skills are configured for explicit invocation.

Copy the skill folders into your Codex skills directory:

```sh
mkdir -p ~/.codex/skills
cp -R skills/* ~/.codex/skills/
```

Typical sequence:

```text
$migration-intake
$migration-recon
# Owner selects a workflow, unless already clearly selected.
$migration-bizlogic
$migration-validate
$migration-safety-net
$migration-design
$migration-slice
$migration-execute
$migration-verify
```

Run `$migration-monitor` from a separate agent/session whenever you want an independent health check.

Then repeat:

```text
$migration-slice -> $migration-execute -> $migration-verify
```

for each migration wave only while the relevant discovery, validated rules, safety-net and design remain applicable. A new workflow or dependency may require earlier stages again.

Recon maps the authorized system and recommends candidate workflows. Reuse a clear applicable owner selection; otherwise ask the owner to choose or narrow one before focused bizlogic, including direct invocation. Record source/reason in `decisions.md` and scope/blocker/next action in `status.md`. Pause target-dependent work while selection is pending; bounded authorized support for selection can continue. Workflow selection is not implementation authorization. `migration-slice` later finalizes a small implementable change within the investigated workflow.

Each stage should read and update `.migration/` artifacts so fresh agent contexts can continue the project without depending on a single long conversation.
