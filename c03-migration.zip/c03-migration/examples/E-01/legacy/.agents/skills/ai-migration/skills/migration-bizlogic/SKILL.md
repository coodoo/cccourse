---
name: migration-bizlogic
description: Recover legacy business behavior across Java and Oracle PL/SQL, including hidden database-side rules, side effects, jobs, and transactions.
---

Use `.migration/` as the persistent project memory. Preserve existing artifacts and update them rather than silently replacing prior conclusions.

Classify material claims as **Observed**, **Inferred**, **Unknown**, or **Contradicted**. Important claims need evidence.

Never perform production writes, destructive database operations, production cutover, or irreversible actions unless separately and explicitly authorized.

Update `.migration/status.md` and `.migration/progress.md` before finishing.

# Migration Business-Logic Archaeology

Goal: recover behavior that must survive modernization. Do not assume the Java business layer contains all business logic.

## Target precondition — including direct invocation

Before target-dependent tracing, check owner instructions, `.migration/decisions.md` and `status.md` for a clear applicable selected workflow. Reuse it without asking again; a clear direct owner request counts. Record selection/source/reason in `decisions.md` and workflow, blockers and next action in `status.md`.

If missing, ambiguous or outside authorized scope, present evidenced workflow candidates with value, entry points, dependencies, risks, baseline/test availability and blocking unknowns; recommend one and ask the owner to choose or narrow it. If recon is insufficient, identify missing evidence. Pause target-dependent tracing and downstream work; only recon summaries or already-authorized bounded investigation needed for selection may continue. Never self-select or deep-trace every workflow.

Selection is not implementation authorization. Trace the selected workflow and relevant shared dependencies, even across module boundaries. For a changed target, check and revisit unmet discovery/validation/protection/design prerequisites; do not inherit readiness from another workflow.

## Recover the selected workflow

Inventory and trace relevant Oracle mechanisms:

- packages/package bodies
- procedures/functions
- triggers
- views/materialized views
- constraints and DB-enforced rules
- scheduler jobs
- sequences
- synonyms/database links
- native SQL
- callable statements
- ORM stored-procedure mappings
- code/config tables
- batch SQL/scripts
- queue/messaging mechanisms implemented through Oracle

For the current domain or candidate migration area, trace end-to-end:

`entry point -> Java path -> SQL/procedure -> PL/SQL path -> tables/state -> downstream side effects`

Create/update `.migration/business-rules.md`.

For each important rule record:

- rule ID
- plain-English behavior
- workflow/domain
- inputs/preconditions
- calculations/decisions
- outputs
- state transitions
- DB mutations
- other side effects
- error/edge behavior
- Java evidence
- Oracle evidence
- runtime evidence if available
- confidence
- validation status

Update `coverage.md`, `evidence.md`, `unknowns.md`, and `system-map.md`.

Do not label DB logic unused from static search alone when runtime evidence can reasonably be checked.

Prefer executable examples and observed behavior over prose interpretation.

Exit when the candidate migration area has enough behavior and side-effect understanding to build characterization tests without inventing expected semantics.
