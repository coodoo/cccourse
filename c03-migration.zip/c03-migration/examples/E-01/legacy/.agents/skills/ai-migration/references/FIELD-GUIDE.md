# AI-Led Legacy Java/Oracle Modernization Field Guide

Practical SOP for using coding agents such as Codex CLI or Claude Code to do most of the heavy lifting in a large legacy-system modernization.

The core loop is:

**inventory -> understand -> recover behavior -> validate -> build safety net -> design transition -> migrate one slice -> verify -> repeat**

The most important operating principle is:

> Do not ask AI to "understand the whole system" and trust the resulting report. Make it maintain evidence, coverage, unknowns, and executable verification continuously.

---

## 0. Operating model

Use three logical roles. They may be separate agents or separate runs with fresh context.

- **Worker** — explores, plans, implements, and verifies the current stage.
- **Reviewer** — independently challenges important outputs at stage boundaries.
- **Monitor** — watches objective progress artifacts and alerts on drift, stagnation, missing coverage, or unsafe behavior.

For high-risk work, do not let the same agent both make an architectural claim and be the only agent that validates it.

Persist knowledge in the repository instead of relying on a long chat context.

Recommended workspace:

```text
.migration/
  charter.md
  inventory.md
  coverage.md
  evidence.md
  system-map.md
  business-rules.md
  unknowns.md
  expert-questions.md
  validation.md
  safety-net.md
  strategy.md
  compatibility.md
  behavior-deltas.md
  decisions.md
  status.md
  progress.md
  slices/
    <slice-id>/
      plan.md
      characterization.md
      implementation.md
      verification.md
      rollout.md
```

### Required claim discipline

Every material statement should be classified as one of:

- **Observed** — directly supported by repository, schema, runtime, test, or other evidence.
- **Inferred** — plausible interpretation of evidence but not proven.
- **Unknown** — important information not yet established.
- **Contradicted** — credible sources disagree.

Do not silently convert an inference into a fact.

### Shared checkpoint status

At the end of every meaningful work unit, update `.migration/status.md`:

```text
stage:
state: green | yellow | red
current_scope:
progress_since_last_update:
evidence_added:
coverage_change:
high_risk_unknowns:
failed_checks:
scope_drift:
blockers:
next_action:
why_next_action_matters:
```

The monitor should judge progress from artifacts, commands, diffs, test results, and coverage changes — not only from the worker's self-report.

---

# Answers to the key practical questions

## Q1. How do I ensure AI correctly captures business logic, especially Oracle PL/SQL?

Do **business-logic archaeology as a separate phase**. Architecture discovery alone is not enough.

Inventory and trace at least these Oracle surfaces when present:

- packages and package bodies
- procedures and functions
- triggers
- views and materialized views
- constraints and database-enforced rules
- scheduler jobs
- sequences
- synonyms
- database links
- native SQL embedded in Java
- callable statements
- ORM stored-procedure mappings
- configuration/code tables that drive behavior
- batch SQL and scripts
- messaging/queue mechanisms implemented through Oracle

Build a cross-layer flow rather than reading PL/SQL in isolation:

```text
business entry point
  -> Java endpoint/job/message consumer
  -> service/business code
  -> SQL / stored procedure call
  -> package/function/trigger
  -> tables and side effects
  -> downstream messages/files/integrations
```

For every recovered business rule record:

- rule ID
- plain-English rule
- domain/workflow
- inputs
- outputs
- preconditions
- calculations
- state transitions
- side effects
- exceptional behavior
- Java evidence
- DB/PLSQL evidence
- runtime evidence
- confidence
- whether behavior is confirmed or still inferred

Then verify important rules through executable behavior whenever possible:

- replay representative requests
- run representative batch cases
- compare DB state changes
- compare accounting/financial outputs
- compare messages/files/events
- compare failure behavior
- compare old and new results

Static reading tells you **what the code appears to do**. Runtime characterization tells you **what the system actually does for observed cases**.

A useful coverage condition is not "AI read all PL/SQL." It is:

> Every discovered executable DB object is accounted for as mapped-to-domain, mapped-to-caller, intentionally out-of-scope, apparently unused-but-unproven, or unresolved.

"Unused" should not be claimed from static analysis alone when runtime evidence is available.

---

## Q2. For a huge system, should I explicitly tell AI how to explore it?

Yes.

Modern coding agents are capable explorers, but a very large system benefits from an explicit exploration policy because agents may otherwise go depth-first, over-focus on one subsystem, or stop when they have a plausible story.

Use this exploration policy:

1. **Deterministic inventory first.**
2. **Breadth before depth.**
3. Map top-level modules, deployables, DB surfaces, integrations, jobs, and runtime boundaries.
4. Create a coverage ledger.
5. Partition deeper exploration by domain/module/runtime flow.
6. Use fresh-context workers for large independent areas.
7. Merge results through a cross-cutting pass.
8. Audit uncovered and excluded areas before claiming sufficient coverage.

The coverage ledger should account for discovered surfaces such as:

```text
area:
type:
discovered_by:
status: uninspected | sampled | mapped | deep-reviewed | excluded | unresolved
owner/domain:
dependencies:
evidence:
migration_relevance:
reason_if_excluded:
```

### What "complete enough" means

Do not require every line to be read.

Require:

- all top-level modules accounted for
- all deployable units accounted for
- all major database object classes accounted for
- all known ingress/egress paths accounted for
- all scheduled/batch paths accounted for
- all external integrations accounted for
- all major runtime/deployment mechanisms accounted for
- all high-risk unknowns explicitly recorded
- no large unexplained inventory gaps

Then ask an independent reviewer to sample areas marked low-risk/excluded and look for missed cross-cutting dependencies.

---

## Q3. Can every migration stage have checkpoints and can another agent monitor them?

Yes. This should be built into the workflow.

Each stage should have:

- entry criteria
- required outputs
- progress indicators
- exit criteria
- early-warning signals
- hard-stop conditions

A monitor agent is useful, but it should not merely ask the worker "are you okay?"

It should inspect:

- `.migration/status.md`
- `.migration/coverage.md`
- `.migration/unknowns.md`
- `.migration/evidence.md`
- `.migration/progress.md`
- git status/diff
- test results
- build logs
- repeated command failures
- changes in scope
- artifact freshness

Typical alarms:

- no meaningful evidence or coverage increase for a substantial work interval
- repeated examination of the same files without new conclusions
- deep work in a low-relevance area before system breadth is mapped
- high-confidence claims with weak/no evidence
- important inventory areas never entered into the coverage ledger
- growing code diff without growing verification
- repeated failing tests with no narrowing hypothesis
- architectural changes expanding beyond the selected slice
- implementation starts while high-risk unknowns for that slice remain unresolved
- worker repeatedly changes plan without recording why
- target architecture assumptions silently changing
- current task cannot explain how its work affects a migration decision

A second agent is an **early-warning mechanism, not proof of correctness**. Prefer objective evidence and deterministic checks over one model validating another model's prose.

---

## Q4. What if all domain experts have left?

Treat **observable behavior as the primary specification** and reconstruct intent only when evidence supports it.

Triangulate:

- source code
- PL/SQL/database definitions
- existing tests
- production-safe runtime traces
- logs
- historical outputs
- representative anonymized data
- reports
- interface contracts
- batch files
- runbooks
- incident records
- change tickets
- git history
- old design documents
- downstream consumers
- user manuals
- regulatory/business policy documents

Existing documents are evidence, not ground truth.

When there is no reliable human expert:

1. Recover observable behavior.
2. Build characterization/golden tests.
3. Record unknown intent separately.
4. Preserve current behavior by default.
5. Make intentional behavior changes explicit.
6. Use differential execution/reconciliation to validate migration.
7. Escalate unresolved high-risk semantics rather than allowing AI to invent them.

For money movement, accounting, regulatory reporting, eligibility, policy calculation, security, and similar high-consequence behavior, the absence of an old-system expert does **not** justify letting AI guess. An accountable business/risk owner may still need to decide what the intended behavior should be.

Technical migration can often proceed on a behavior-parity basis even when original designers are unavailable.

---

# Important questions not to miss

## Q. How do we separate migration changes from new-feature changes?

Maintain `.migration/behavior-deltas.md`.

Every intentional difference should identify:

- old behavior
- desired new behavior
- reason
- requirement/owner
- affected invariants
- tests proving the new behavior
- rollout risk

Prefer to establish the old behavior first, then make migration and business deltas independently observable even if they ship together.

## Q. What is the source of truth: docs, source, database, or runtime?

There is rarely one source.

Use an evidence hierarchy appropriate to the claim:

- runtime behavior for observed behavior
- executable code/DB logic for implementation mechanics
- schemas/config for structure
- contracts/policies for intended external requirements
- humans for undocumented intent

Record contradictions instead of choosing whichever source fits the current plan.

## Q. When have we explored enough?

When you know enough to make the **next reversible migration decision safely**, not when AI claims to understand everything.

For the first slice, require complete-enough understanding of that slice and its dependencies, plus broad-enough understanding of the rest of the system to know its blast radius.

## Q. How should we handle a pre-decided target such as WebSphere -> Spring Boot/Kubernetes?

Record it in `.migration/charter.md` as a fixed constraint.

During archaeology, produce `.migration/compatibility.md` mapping legacy mechanisms to target concerns, for example:

- WebSphere descriptors
- JNDI
- JTA
- EJB
- JMS
- shared libraries
- EAR/WAR packaging
- security realms
- session state
- clustering
- server-managed resources
- connection pooling
- startup/shutdown hooks
- scheduler behavior

Do not waste agent time re-litigating fixed client decisions unless evidence shows the target cannot satisfy a required invariant.

## Q. Should previous AI-generated client documents be used?

Yes: **reuse evidence, revalidate conclusions**.

Mark every important inherited conclusion as verified, contradicted, stale, or unverified.

Do not restart from zero if previous work contains useful evidence, tests, failure reports, or experiments.

Do not blindly continue an old AI plan.

## Q. How should shared Oracle databases affect service extraction?

Treat shared data and transaction boundaries as first-class migration constraints.

Do not extract a "service" merely because Java packages look separate if correctness depends on cross-schema transactions, triggers, shared tables, or hidden stored procedures.

## Q. How do we stop AI from modernizing for fashion?

Require every architectural change to answer:

- what concrete migration/business problem does this solve?
- what risk does it remove?
- what new operational cost does it create?
- is there a smaller change?
- is it required for the current slice?

## Q. How should long agent runs manage context?

Do not rely on one enormous conversation.

Persist maps, rules, unknowns, evidence, decisions, slice plans, and verification results in `.migration/`.

Start fresh-context workers for well-defined stages or slices and let them load the relevant artifacts.

## Q. How do we prevent locally correct changes from breaking the larger system?

Require:

- dependency/blast-radius analysis before implementation
- characterization tests
- contract checks
- database side-effect checks
- integration checks
- cross-slice regression suite
- independent review at slice completion

## Q. How do we control AI cost?

Optimize for verified progress, not token minimization alone.

Useful controls:

- breadth-first reconnaissance before deep analysis
- scoped fresh-context workers
- deterministic inventory scripts
- evidence ledgers to prevent rediscovery
- one slice at a time
- stop repeated failing exploration
- avoid generating giant narrative reports that are never used
- use powerful models for high-risk reasoning/review and cheaper agents for mechanical inventory/transformation when appropriate

## Q. What should AI never do autonomously?

Do not delegate irreversible or high-consequence decisions merely because the agent can technically perform them.

Examples that normally require explicit human authorization include:

- production data mutation
- destructive schema changes
- production cutover
- security-policy changes
- acceptance of unexplained financial discrepancies
- intentional changes to regulated/business semantics
- decommissioning the only known implementation before replacement is proven

---

# Complete SOP

## Stage 0 — Establish migration charter and workspace

### Goal

Give agents fixed goals, target constraints, safety boundaries, and a persistent working structure.

### Inputs

- repositories
- DB/schema/PLSQL exports or safe read access
- existing documentation
- known target stack
- business goals
- known new features
- deployment/environment information

### Produce

`.migration/charter.md`

Must contain:

- business objective
- migration objective
- fixed technology decisions
- undecided technology choices
- required new features
- non-negotiable invariants
- regulatory/security constraints
- environments available
- allowed actions
- prohibited actions
- production access rules
- known deadlines/gates
- success criteria

Also create:

- `.migration/status.md`
- `.migration/progress.md`
- `.migration/decisions.md`

### Checkpoint

**Green:** goals and fixed constraints are explicit.

**Yellow:** important target or access assumptions are unclear.

**Red:** agent is being asked to modify the system before safety boundaries and environments are known.

### Rough time

Usually 1–3 hours of focused setup if information is available.

---

## Stage 1 — Deterministic inventory and coverage baseline

### Goal

Know what exists before asking AI to explain what it means.

### Actions

Use filesystem/build/schema tooling to inventory:

- repositories
- source roots
- modules
- build files
- Java/framework versions
- deployables
- configuration
- tests
- SQL/DDL/PLSQL artifacts
- DB object categories
- APIs
- message consumers/producers
- scheduled/batch jobs
- external-integration configuration
- infrastructure/deployment artifacts

Prefer deterministic commands/scripts for enumeration.

### Produce

`.migration/inventory.md`

Must contain:

- inventory method
- discovered component counts/categories
- repository/module tree
- database artifact categories
- deployables
- obvious missing access/data

`.migration/coverage.md`

Every discovered area gets a state.

### Exit criteria

No major discovered surface is absent from the coverage ledger.

### Early alarms

- agent starts writing architecture prose before inventory exists
- only Java is inventoried although Oracle contains executable logic
- generated/vendor/test code dominates exploration
- repositories or DB artifacts known to the client are absent

### Rough time

30 minutes to several hours depending on repository count and available DB metadata.

---

## Stage 2 — Breadth-first system archaeology

### Goal

Build an evidence-backed map of the system before deep diving.

### Actions

Map:

- deployable/runtime topology
- module relationships
- major entry points
- major business workflows
- data stores
- integration edges
- batch/scheduled processing
- authentication/authorization
- messaging
- shared libraries
- transaction boundaries where visible
- operational/deployment assumptions

Explore breadth-first.

Deep-dive only where needed to resolve high-impact uncertainty or migration risk.

### Produce

`.migration/system-map.md`

Must contain:

- logical architecture
- runtime/deployment topology
- major workflows
- modules and responsibilities
- data ownership/use
- integrations
- high coupling areas
- high-risk areas
- evidence links
- facts vs inferences

Update:

- `coverage.md`
- `evidence.md`
- `unknowns.md`

### Exit criteria

A reviewer can explain the major runtime and business flows and identify major migration boundaries without reading the whole repository.

Before focused business-logic recovery, reuse a clear applicable owner-selected workflow or present evidence-based candidates (value, entry points, dependencies, risks, baseline/test availability, unknowns) and ask the owner to choose or narrow one. Save source/reason in `decisions.md` and selected workflow or selection blocker/next action in `status.md`. Recon may be complete with selection pending; pause target-dependent work, not bounded authorized selection support. Selection authorizes no additional implementation. Stage 7 later plans a small implementation slice within that workflow.

### Early alarms

- class-by-class documentation
- long exploration inside one utility/library
- major modules remain unaccounted for
- prose claims lack file/schema/runtime evidence
- no coverage progress

### Rough time

First useful system map: commonly hours to 1–2 agent-days for a large application.

Deep system understanding continues throughout the migration.

---

## Stage 3 — Business-logic and Oracle archaeology

### Goal

Recover the behaviors that must survive modernization.

### Actions

Trace high-value workflows end-to-end across Java and Oracle.

Inventory and map stored procedures, packages, triggers, jobs, native SQL, code tables, and DB side effects.

Use runtime evidence when safely available.

### Produce

`.migration/business-rules.md`

Each important rule contains:

- rule ID
- description
- workflow/domain
- inputs
- outputs
- state transitions
- calculations
- side effects
- error behavior
- Java evidence
- Oracle evidence
- runtime evidence
- confidence
- validation state

Update:

- `system-map.md`
- `coverage.md`
- `unknowns.md`
- `evidence.md`

### Exit criteria

For the candidate migration area, important business behavior and DB-side logic are mapped well enough to characterize externally observable behavior.

### Early alarms

- agent equates Java business layer with all business logic
- stored procedures are listed but callers/side effects are not mapped
- triggers/jobs are ignored
- "unused procedure" claims are made only from static search
- business rules have no executable examples

### Rough time

For a pilot domain, often hours to a few days.

Do not wait to completely reverse-engineer every domain before moving to a safe first slice.

---

## Stage 4 — Validate with humans, or triangulate when experts are absent

### Goal

Resolve high-impact unknowns and incorrect assumptions cheaply.

### Actions

Generate questions from actual unknowns; do not use a generic questionnaire.

Ask experts to correct, contradict, or fill gaps rather than retell the entire system.

If experts are unavailable, triangulate using independent evidence.

### Produce

`.migration/expert-questions.md`

Each question includes:

- question
- current hypothesis
- evidence
- why it matters
- consequence if wrong
- best respondent

`.migration/validation.md`

Record:

- confirmed
- corrected
- unresolved
- new discoveries
- architecture/migration impact

### Exit criteria

No unresolved high-risk assumption prevents selecting and safely verifying the next slice.

### Early alarms

- humans are asked questions answerable from source
- expert opinions overwrite contradictory runtime evidence without investigation
- AI silently changes earlier claims after an interview
- high-risk unknowns are marked resolved without evidence

### Rough time

Typically one or two focused 60–90 minute sessions for an initial migration area, plus follow-ups as needed.

---

## Stage 5 — Build the behavioral safety net

### Goal

Turn old-system behavior into executable evidence before replacing it.

### Actions

For the candidate slice, create characterization/golden/differential tests.

Capture relevant outputs and side effects:

- API/UI observable results
- DB mutations
- financial/accounting results
- files
- messages
- state transitions
- batch outputs
- error behavior

Normalize nondeterministic fields where appropriate.

### Produce

`.migration/safety-net.md`

Must contain:

- protected workflows
- test harness
- representative scenarios
- golden-data provenance
- nondeterministic fields/normalization
- invariants
- known legacy defects
- coverage gaps
- commands to reproduce

`behavior-deltas.md`

Record intentional differences separately from migration parity.

### Exit criteria

The selected slice has enough executable behavioral protection to detect meaningful regressions.

### Early alarms

- only unit tests are generated from implementation details
- golden outputs cannot be reproduced
- test oracle is AI-generated expectation rather than old-system behavior/approved requirement
- important DB side effects are not tested
- nondeterministic mismatches are simply ignored

### Rough time

For a first slice, roughly half a day to several days depending on testability and environment access.

---

## Stage 6 — Design the transition and target compatibility

### Goal

Design how old and new coexist while honoring fixed target constraints.

### Actions

Produce a legacy-to-target compatibility analysis.

Choose a migration seam and coexistence method.

Decide how new features interact with the migration.

### Produce

`.migration/strategy.md`

Must contain:

- chosen incremental strategy
- alternatives considered
- migration unit
- coexistence model
- data strategy
- transaction implications
- routing mechanism
- deployment approach
- rollback model
- new-feature policy
- assumptions
- risks
- reasons this is the smallest safe strategy

`.migration/compatibility.md`

Map legacy platform mechanisms to target concerns.

### Exit criteria

The first slice can be implemented and independently verified/rolled back without requiring a whole-system rewrite.

### Early alarms

- microservices/Kafka/Kubernetes redesign expands beyond stated constraints
- strategy requires many unrelated systems to change before first value
- rollback is "restore backup and hope"
- data ownership/transactions are hand-waved
- new-feature behavior is mixed with migration behavior without a delta ledger

### Rough time

Hours to roughly two days once discovery evidence exists.

---

## Stage 7 — Select and plan the next vertical slice

### Goal

Pick the smallest representative behavior that proves the migration method.

### Good first-slice properties

- real business value
- representative technology
- bounded blast radius
- observable behavior
- testable
- reversible
- limited number of dependencies
- not the most critical money/regulatory path

### Produce

`.migration/slices/<id>/plan.md`

Must contain:

- slice boundary
- entry points
- affected modules
- DB objects
- integrations
- current behavior
- desired behavior
- invariants
- dependencies
- exact files likely to change
- characterization tests
- implementation steps
- verification plan
- rollback plan
- out-of-scope items
- stop conditions

### Exit criteria

The slice can be described as:

**understand -> test -> implement -> compare -> deploy -> roll back**

without requiring undefined work.

### Early alarms

- first slice spans many teams/domains
- slice is chosen because code is easy rather than because behavior is representative
- unknown transaction/data side effects remain
- plan keeps expanding during planning

### Rough time

Usually hours, not weeks.

---

## Stage 8 — Agentic implementation

### Goal

Let AI perform most implementation work while containing blast radius.

### Loop

1. Re-read slice plan and relevant evidence.
2. Make the smallest coherent change.
3. Build/test.
4. Run characterization/differential checks.
5. Inspect diff.
6. Update implementation notes.
7. Continue only if verification is still green.

Do not implement unrelated cleanup merely because it is nearby.

### Produce

Code changes plus:

`.migration/slices/<id>/implementation.md`

Must contain:

- steps completed
- files changed
- design deviations and reasons
- discovered hidden dependencies
- newly discovered business rules
- unresolved issues
- test commands/results

Update global maps/rules if implementation reveals new facts.

### Exit criteria

Implementation is complete, buildable, reviewable, and ready for independent verification.

### Early alarms

- diff expands much faster than verified behavior
- broad refactors appear unrelated to the slice
- tests are disabled or rewritten merely to make them pass
- migration plan changes without decision log
- repeated failures with no narrowing diagnosis
- agent changes shared contracts unintentionally
- agent begins another slice before current slice is verified

### Rough time

A good pilot slice should normally be days to perhaps a couple of weeks of project elapsed time, not months.

If it needs months, reassess the boundary.

---

## Stage 9 — Independent verification, rollout, and learning

### Goal

Prove the slice behaves correctly and can be introduced safely.

### Actions

Use an independent review pass when practical.

Run:

- old/new differential tests
- DB reconciliation
- contract tests
- integration tests
- performance checks appropriate to the slice
- security checks appropriate to the slice
- rollback rehearsal where practical

Classify every meaningful difference:

- expected intentional change
- accepted legacy defect correction
- benign normalization
- regression
- unexplained — block until understood if material

### Produce

`.migration/slices/<id>/verification.md`

Must contain:

- exact tests/checks run
- old/new comparison results
- data reconciliation
- performance/security findings
- unexplained differences
- residual risks
- release recommendation

`.migration/slices/<id>/rollout.md`

Must contain:

- deployment steps
- routing/feature-flag/canary plan
- health signals
- rollback trigger
- rollback steps
- post-release reconciliation
- observation period/gates

Update:

- `system-map.md`
- `business-rules.md`
- `strategy.md`
- `decisions.md`
- `coverage.md`
- `progress.md`

### Exit criteria

The slice is proven, deployable, observable, and reversible to the degree required by its risk.

Then return to Stage 7 only if discovery, validated rules, safety-net and design still cover the next slice. For a changed workflow or dependencies, revisit affected prerequisites first.

### Early alarms

- unexplained differences are accepted because "most tests passed"
- rollout lacks measurable rollback triggers
- production-only discovery is required to know whether it works
- new behavior and migration regressions cannot be distinguished
- system maps are not updated with implementation discoveries

---

# Time and progress heuristics

Elapsed time is a weak metric. Prefer **verified information gained per unit effort**.

Still, use these rough alarm thresholds:

- If initial inventory/recon spends hours without producing a usable topology/coverage ledger, inspect the run.
- If an exploration worker spends 30–60 minutes on one area without adding meaningful evidence, resolving an unknown, or changing a migration decision, challenge the direction.
- If a worker repeatedly runs the same failing approach without narrowing the problem, stop and diagnose.
- If implementation diff size grows but verified behavior does not, stop.
- If a first slice is projected to require months or many unrelated teams before verification, choose a smaller seam.
- If discovery continues for many days without selecting any reversible pilot slice, ask whether the team is trying to understand everything instead of enough.

Large organizations may take much longer in calendar time because of environment access, governance, release windows, and human approvals. Do not confuse organizational waiting time with useful agent exploration time.

---

# Suggested agent topology

For a large system:

```text
orchestrator
  |
  +-- recon worker(s)
  |     +-- Java/module pass
  |     +-- Oracle/PLSQL pass
  |     +-- runtime/integration pass
  |
  +-- reviewer
  |
  +-- monitor
  |
  +-- slice worker
        +-- implementation
        +-- verification reviewer
```

Do not spawn many agents merely to increase parallelism.

Partition work only when each worker has:

- a clear bounded scope
- a required output
- coverage responsibility
- evidence requirements
- a merge point

---

# Field rule

At every stage ask:

> What evidence would make us change the current migration decision?

If the current work cannot answer that question, it may be low-value exploration.

And before implementation ask:

> Do we know enough to make the next reversible decision safely?

That is the practical stopping rule for discovery.
