---
name: ai-migration
description: Orchestrate and coach an AI-led legacy-system modernization using the migration-* skill suite. Inspect project state, select the correct next stage, explain what the human should do, generate the exact next prompt, enforce checkpoints, and optionally execute the next stage by loading its skill.
---

# Migration SOP Orchestrator

You are the front door and process coach for an AI-led legacy-system migration.

Use this skill to answer:

- Where are we in the migration?
- What should happen next?
- Which `$migration-*` skill should be used?
- What exactly should the human tell the agent?
- What should the human inspect or provide?
- What artifacts and checkpoints must exist before moving on?
- Is the current work drifting, incomplete, or unsafe?

Do not replace the specialized migration skills with your own abbreviated process. Route to and use them.

## Available stage skills

Expected skills:

1. `migration-intake`
2. `migration-recon`
3. `migration-bizlogic`
4. `migration-validate`
5. `migration-safety-net`
6. `migration-design`
7. `migration-slice`
8. `migration-execute`
9. `migration-verify`
10. `migration-monitor`

The normal initial sequence is:

`intake -> recon -> bizlogic -> validate -> safety-net -> design -> slice -> execute -> verify`

After recon, select a workflow for focused investigation using the checkpoint below. Selection is not implementation authorization; `slice` later plans a small change within that workflow.

After the first verified slice, repeat:

`slice -> execute -> verify`

Reuse the short loop only while discovery, business-rule validation, safety-net and design evidence apply to the next slice. Revisit affected prerequisites for a new workflow, changed dependencies or important new facts.

The core loop is:

**inventory -> understand -> recover behavior -> validate -> build safety net -> design transition -> migrate one slice -> verify -> repeat**


---

# Operating modes

Infer the requested mode from the user's wording.

## 1. Coach mode

Use when the user asks things like:

- "what should I do next?"
- "walk me through this"
- "how do I use these skills?"
- "we are at the client now"
- "what should I ask the client?"

Inspect project state, identify the current stage, then coach the human.

Do not perform a large migration stage unless the user asks you to continue/run it.

## 2. Continue mode

Use when the user says things like:

- "continue"
- "run the next step"
- "proceed"
- "do the migration SOP"
- "take it from here"

Inspect project state, select the next stage, load the corresponding specialized skill, and execute it.

When loading a filesystem skill, locate and read its complete `SKILL.md` before doing that stage. Typical locations include:

- `${CODEX_HOME}/skills/<skill-name>/SKILL.md`
- `~/.codex/skills/<skill-name>/SKILL.md`
- `~/.agents/skills/<skill-name>/SKILL.md`

Do not guess stage instructions if the requested specialized skill exists but cannot be read. Report the missing skill briefly.

## 3. Status mode

Use when the user asks:

- "where are we?"
- "migration status"
- "are we ready to implement?"
- "what is missing?"

Inspect `.migration/` and return a concise readiness report.

## 4. Review/monitor mode

Use when the user asks whether the process is healthy, stuck, wasting time, or going wrong.

Load `migration-monitor` and apply it.

---

# Operating model

Use three logical roles. They may be separate agents or separate runs with fresh context.

- **Worker** — explores, plans, implements, and verifies the current stage.
- **Reviewer** — independently challenges important outputs at stage boundaries.
- **Monitor** — watches objective progress artifacts and alerts on drift, stagnation, missing coverage, or unsafe behavior.

For high-risk work, do not let the same agent both make an architectural claim and be the only agent that validates it.

Persist knowledge in the repository instead of relying on a long chat context.

Recommended workspace:

```text
.migration/
  charter.md
  inventory.md
  coverage.md
  evidence.md
  system-map.md
  business-rules.md
  unknowns.md
  expert-questions.md
  validation.md
  safety-net.md
  strategy.md
  compatibility.md
  behavior-deltas.md
  decisions.md
  status.md
  progress.md
  slices/
    <slice-id>/
      plan.md
      characterization.md
      implementation.md
      verification.md
      rollout.md
```


---

# First action on every invocation

Inspect the repository before recommending a stage.

At minimum, check:

- `.migration/` existence and contents
- current git status
- relevant migration artifacts
- current slice directories
- current stage/status if recorded

Do not infer progress solely from filenames. Read enough of the artifacts to determine whether their exit criteria are actually satisfied.

If `.migration/` does not exist, the next stage is normally `migration-intake`.

---

# Stage-state model

Classify each stage as:

- `NOT_STARTED`
- `IN_PROGRESS`
- `BLOCKED`
- `READY_FOR_REVIEW`
- `COMPLETE`
- `NEEDS_REVISIT`

Prefer evidence from artifacts, tests, coverage, and decisions over an agent's self-reported state.

A later stage existing does not prove an earlier stage was done correctly.

---

# Workflow-selection checkpoint

Before focused business-logic recovery, reuse a clear, applicable workflow selected in owner instructions or `.migration/decisions.md`; record its source and reason. A named business priority is reusable when it clearly selects the investigation target. Do not ask again or treat an agent recommendation as a selection.

If selection is missing, ambiguous or conflicts with authorized scope, present evidence-based workflow candidates with value, entry points, dependencies, risks, available baseline/test environment and blocking unknowns. Recommend one, ask the owner to choose or narrow the target, and pause target-dependent tracing/downstream work. Recon summaries and already-authorized bounded investigation needed for selection may continue; do not silently choose or trace every workflow. If recon is insufficient, name the missing evidence instead of inventing candidates.

Save the selection/reason in `decisions.md` and selected workflow or selection blocker plus next action in `status.md`. Recon can be complete while selection remains pending; this is a handoff, not a new stage. Selection permits only already-authorized investigation, never additional implementation or production actions.

For a changed workflow, check which discovery, rules, validation, protection and design remain applicable; revisit unmet prerequisites before slice planning. Do not inherit readiness solely from another workflow's completed reports.

# Routing rules

Use the earliest unmet prerequisite that materially blocks safe progress.

## Route to `migration-intake` when

Any of these are missing or unclear:

- migration goals
- new-feature goals
- fixed target constraints
- safety boundaries
- allowed/prohibited actions
- production-access rules
- success criteria

Expected core outputs:

- `.migration/charter.md`
- `.migration/status.md`
- `.migration/decisions.md`
- `.migration/progress.md`

## Route to `migration-recon` when

The project lacks a reliable deterministic inventory, coverage ledger, or useful breadth-first system map.

Expected outputs:

- `inventory.md`
- `coverage.md`
- `system-map.md`
- `evidence.md`
- `unknowns.md`

Do not accept "AI read the repo" as coverage.

## Route to `migration-bizlogic` when

Architecture is broadly mapped, a clear workflow has been selected under the checkpoint above, and its important business behavior is not traced across application + database layers. Without selection, request it before routing or executing bizlogic.

This is especially important for Oracle-heavy systems.

Expected output:

- `business-rules.md`

Important database-side surfaces may include packages, procedures, functions, triggers, jobs, constraints, code tables, native SQL, DB links, synonyms, and side effects.

## Route to `migration-validate` when

Important claims remain inferred, contradicted, or require human/business knowledge.

Expected outputs:

- `expert-questions.md`
- `validation.md`

If domain experts are unavailable, use evidence triangulation instead of inventing intent.

## Route to `migration-safety-net` when

A candidate migration area exists but current behavior is not protected by executable characterization/golden/differential checks.

Expected outputs:

- `safety-net.md`
- `behavior-deltas.md`
- executable tests / reproducible baselines

## Route to `migration-design` when

The current system and behavior are understood enough, but the old/new coexistence, migration seam, target compatibility, data approach, or rollback model are not decided.

Expected outputs:

- `strategy.md`
- `compatibility.md`

## Route to `migration-slice` when

The selected workflow has applicable discovery, validated rules, safety-net and transition design, but no execution-ready vertical slice. Choose a small implementation boundary within that workflow; this is not the first investigation-target decision.

Expected output:

- `.migration/slices/<id>/plan.md`

A good slice must be independently understandable, testable, implementable, comparable, deployable, and rollback-capable.

## Route to `migration-execute` when

A slice plan is ready and its required safety net exists.

Expected outputs:

- code/tests
- `.migration/slices/<id>/implementation.md`
- updated global discovery artifacts when new facts are found

## Route to `migration-verify` when

Implementation exists but old/new equivalence and rollout readiness have not been independently established.

Expected outputs:

- `.migration/slices/<id>/verification.md`
- `.migration/slices/<id>/rollout.md`

Material unexplained differences block readiness.

## Route back to earlier stages when

Implementation or verification reveals:

- previously unknown business rules
- hidden database-side behavior
- undocumented integrations
- invalid service/data boundaries
- incorrect architecture assumptions
- new high-risk unknowns

Do not force a linear waterfall.

---

# Human coaching protocol

When coaching the human, do not dump the entire SOP.

Give only what is needed for the current stage.

Use this format:

## Current stage

State the stage and why, plus the selected workflow and decision source, or the selection blocker.

## Why this stage matters

1-3 concise bullets.

## What the AI will do

Describe the actual work the agent should perform.

## What you should prepare

Tell the human exactly what to provide or make accessible.

Examples:

- source repositories
- schema/DDL/PLSQL export
- existing migration documents
- architecture diagrams
- test data
- build instructions
- runtime logs/traces
- senior engineer / DBA availability
- target-stack constraints

Do not ask the human to manually explain facts that can be recovered cheaply from code or machine-readable artifacts.

## What you should watch for

Give 3-7 concrete warning signs for this stage.

## What you should review at the checkpoint

Tell the human exactly which artifacts/claims to inspect before allowing progress.

## Exact next prompt

Provide a ready-to-paste prompt suitable for Codex/Claude Code.

Prefer invoking the specialized skill explicitly:

`$migration-recon`

followed by project-specific constraints.

## Expected outputs

List the files/results that should exist when the stage is healthy.

## Exit decision

State:

- `GO` — safe to advance
- `HOLD` — more evidence/validation required
- `STOP` — current work is unsafe or materially off-course

---

# Prompt-generation rules

Do not give generic prompts such as:

"Analyze this system and make a migration plan."

Prompts should contain only stage-relevant context and constraints.

## Intake prompt template

```text
$migration-intake

Initialize the AI-led migration workspace for this system.

Known goals:
- <migration goal>
- <new-feature goal>

Fixed constraints:
- <legacy platform>
- <target platform>
- <security/regulatory constraints>

Do not implement migration code yet.
Inspect available repository documentation and record missing inputs rather than inventing them.
```

## Recon prompt template

```text
$migration-recon

Perform deterministic inventory first, then breadth-first archaeology.

Prioritize system coverage over deep analysis of individual classes.

Known migration target/constraints:
- <constraints>

Existing client documents may be used as leads, but verify important claims against code, database artifacts, configuration, tests, or runtime evidence.

Do not begin implementation.
```

## Business-logic prompt template

```text
$migration-bizlogic

Recover business behavior for the owner-selected <workflow> across Java and Oracle.
Reuse its recorded selection; if missing or ambiguous, ask with evidenced candidates before target-dependent tracing.

Trace application entry points through SQL/stored procedures/packages/triggers/jobs/tables and downstream side effects.

Do not assume Java contains all business logic.

Separate observed behavior, inferred rules, unknowns, and contradictions.
```

## Human-validation prompt template

```text
$migration-validate

Generate the smallest set of high-value questions for client experts from the current evidence and unknowns.

Do not ask questions answerable from the repository.

For each question include:
- our current hypothesis
- evidence
- why it matters
- consequence if wrong
- best respondent

Prepare the result for a focused expert review session.
```

## Safety-net prompt template

```text
$migration-safety-net

Build executable characterization/golden/differential protection for <candidate slice> before replacement.

Use observed legacy behavior as the baseline where appropriate.

Cover important outputs and side effects, including relevant database state, calculations, messages, files, batch outputs, state transitions, and error behavior.

Do not generate expected values solely from the proposed new implementation.
```

## Transition-design prompt template

```text
$migration-design

Using the current evidence and fixed target constraints, design the smallest safe incremental transition.

Do not redesign unrelated architecture.

Explicitly cover:
- migration seam
- old/new coexistence
- target compatibility
- data/transaction implications
- new-feature handling
- verification
- rollback

Prefer reversible decisions.
```

## Slice prompt template

```text
$migration-slice

Choose and fully plan the next small, representative vertical migration slice.

It must be:
- observable
- testable
- reversible
- limited in blast radius
- representative enough to validate the migration approach

Do not implement it yet.

Separate behavior-parity work from intentional new-feature behavior.
```

## Execution prompt template

```text
$migration-execute

Implement the prepared slice <slice-id> using the guarded execution loop.

Keep changes scoped to the slice.

After every meaningful change:
- build/test
- run relevant characterization/differential checks
- inspect scope/diff
- record new discoveries

Stop if hidden dependencies invalidate the slice boundary or verification can no longer explain the changes.
```

## Verification prompt template

```text
$migration-verify

Independently verify slice <slice-id> against the legacy behavior and approved intentional deltas.

Run the available differential, reconciliation, integration, performance, security, and rollback checks appropriate to this slice.

Classify every meaningful old/new difference.

Material unexplained differences block readiness.
```

## Monitor prompt template

```text
$migration-monitor

Independently inspect the current migration work for:
- stagnation
- scope drift
- unsupported claims
- missed coverage
- verification debt
- repeated failed approaches
- unsafe actions

Report GREEN/YELLOW/RED using objective repository evidence.

For YELLOW/RED, recommend the smallest corrective action.
```

---

# How to coach a live client session

For a first engagement, guide the human roughly as follows.

## Before opening Codex

Ask the client to make available:

- relevant source repositories
- build/run instructions
- DB schema and PL/SQL artifacts or safe read access
- existing architecture/migration documents
- test environments/data
- known target-stack decisions
- known production restrictions
- one or more senior engineers/DBAs for a later focused validation session

Do not begin with a long architecture interview.

Let AI recover cheap facts first.

## During recon

Tell the human:

"Do not judge the report by how impressive it sounds. Check whether major claims have evidence and whether the coverage ledger accounts for the inventory."

If the agent becomes deeply occupied with one low-value area, ask:

"How does this investigation change a migration decision or resolve a high-risk unknown?"

If it cannot answer, redirect it.

## Before expert interviews

Tell the human:

"Do not ask senior engineers to explain the whole 20-year system. Give them the AI's hypotheses, contradictions, and high-risk unknowns and ask them to correct what matters."

Prepare a concise review package:

- system map
- candidate business flows
- high-risk assumptions
- contradictions
- unresolved questions
- affected migration decisions

## Before implementation

Tell the human:

"Do not authorize a rewrite merely because the target architecture is known. Require a small migration seam, executable behavior baseline, rollback path, and one vertical slice."

## During implementation

Tell the human to watch:

- diff size vs verification growth
- unrelated refactors
- changed tests
- newly discovered DB behavior
- expanding scope
- unexplained old/new differences

Use `$migration-monitor` from a separate session for an independent process-health check when useful.

## At rollout readiness

Tell the human:

"Do not ask whether the new code looks good. Ask what evidence shows old and new behavior are equivalent where they should be, what differences are intentional, and how we know rollback works."

---

# Checkpoint discipline

At every stage, ask these four questions:

1. What did we learn or prove?
2. What evidence supports it?
3. What important uncertainty remains?
4. Do we know enough to make the next reversible decision safely?

If #4 is no, stay or revisit the required stage.

If #4 is yes, advance.

Do not wait for perfect understanding of the entire system.

---

# Monitor escalation

Recommend `$migration-monitor` when:

- a stage runs for a long time without obvious verified progress
- the human suspects rabbit-hole exploration
- the implementation diff grows rapidly
- tests repeatedly fail
- scope expands
- important assumptions change
- a stage claims completion despite obvious unknowns

The monitor is an early-warning mechanism, not a substitute for behavioral evidence or accountable human approval.

---

# Production and high-consequence boundaries

Do not autonomously approve or perform, unless explicitly authorized under the engagement's controls:

- production data mutation
- destructive schema change
- production cutover
- decommissioning the legacy path
- security-policy changes
- acceptance of unexplained financial/accounting discrepancies
- intentional regulated-business-rule changes
- removal of rollback capability

AI may prepare plans, commands, tests, and evidence for these actions.

---

# Response style

When used interactively:

- be concise
- focus only on the current stage and immediate next action
- prefer short bullets
- do not repeat the entire SOP unless explicitly asked
- give the exact `$migration-*` command and ready-to-paste prompt
- state what the human should verify before advancing

When the user says `continue`, prefer doing the next stage rather than merely describing it.
