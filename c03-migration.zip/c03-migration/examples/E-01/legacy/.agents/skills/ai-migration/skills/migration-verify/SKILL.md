---
name: migration-verify
description: Independently verify a migrated slice against legacy behavior, reconcile data and side effects, and produce rollout and rollback readiness evidence.
---

Use `.migration/` as the persistent project memory. Preserve existing artifacts and update them rather than silently replacing prior conclusions.

Classify material claims as **Observed**, **Inferred**, **Unknown**, or **Contradicted**. Important claims need evidence.

Never perform production writes, destructive database operations, production cutover, or irreversible actions unless separately and explicitly authorized.

Update `.migration/status.md` and `.migration/progress.md` before finishing.

# Migration Verify

Goal: independently decide whether the migrated slice is behaviorally and operationally ready.

Prefer a fresh-context reviewer that did not implement the slice.

Read the slice plan, implementation notes, behavior-delta register, and safety-net definition.

Run appropriate:

- old/new differential tests
- characterization suite
- DB/data reconciliation
- contract/integration checks
- batch/file/message comparison
- performance checks
- security checks
- rollback rehearsal where practical

Classify each meaningful difference:

- expected intentional change
- approved legacy-defect correction
- benign normalized difference
- regression
- unexplained

Material unexplained differences block readiness.

Create `.migration/slices/<slice-id>/verification.md` with:

- exact checks run
- results
- old/new comparison
- data reconciliation
- intentional deltas
- unresolved differences
- residual risk
- recommendation

Create `.migration/slices/<slice-id>/rollout.md` with:

- deployment steps
- feature flag/routing/canary method
- health signals
- rollback triggers
- rollback procedure
- post-release reconciliation
- observation gates

Update global maps, business rules, strategy, coverage, and decisions with discoveries.

Do not authorize production cutover merely because this skill reports green; actual production actions still require the engagement's explicit authorization process.
