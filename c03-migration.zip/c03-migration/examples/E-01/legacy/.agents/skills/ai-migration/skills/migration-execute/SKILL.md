---
name: migration-execute
description: Implement one approved migration slice through a guarded agentic loop with small diffs, continuous tests, scope control, and persistent discoveries.
---

Use `.migration/` as the persistent project memory. Preserve existing artifacts and update them rather than silently replacing prior conclusions.

Classify material claims as **Observed**, **Inferred**, **Unknown**, or **Contradicted**. Important claims need evidence.

Never perform production writes, destructive database operations, production cutover, or irreversible actions unless separately and explicitly authorized.

Update `.migration/status.md` and `.migration/progress.md` before finishing.

# Migration Execute

Goal: implement exactly one prepared slice. Work from `.migration/slices/<slice-id>/plan.md`.

Before coding, verify:

- the plan is current
- required safety-net checks exist
- high-risk assumptions for this slice are resolved or explicitly accepted
- target constraints are known

Execution loop:

1. Make the smallest coherent implementation change.
2. Build/lint/test as applicable.
3. Run relevant characterization/differential checks.
4. Inspect the diff for scope creep.
5. Record newly discovered dependencies/rules.
6. Update plan/decision log if evidence requires a change.
7. Continue only if verification remains explainably green.

Do not:

- perform unrelated cleanup
- rewrite tests merely to match the new implementation
- disable failing checks without explaining the underlying behavior
- broaden architecture because a cleaner design is possible
- begin another slice before this one reaches verification

Create/update `.migration/slices/<slice-id>/implementation.md` with:

- completed steps
- files changed
- test commands/results
- plan deviations and reasons
- newly discovered dependencies/business rules
- unresolved issues

Feed new facts back into global `system-map.md`, `business-rules.md`, `evidence.md`, or `unknowns.md`.

Stop and mark YELLOW/RED if the diff expands faster than verified behavior, repeated failures are not narrowing, or hidden dependencies invalidate the slice boundary.
