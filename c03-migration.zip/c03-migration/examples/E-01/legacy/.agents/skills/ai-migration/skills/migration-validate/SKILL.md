---
name: migration-validate
description: Generate evidence-driven domain-expert questions and reconcile answers, or triangulate system behavior when original experts are unavailable.
---

Use `.migration/` as the persistent project memory. Preserve existing artifacts and update them rather than silently replacing prior conclusions.

Classify material claims as **Observed**, **Inferred**, **Unknown**, or **Contradicted**. Important claims need evidence.

Never perform production writes, destructive database operations, production cutover, or irreversible actions unless separately and explicitly authorized.

Update `.migration/status.md` and `.migration/progress.md` before finishing.

# Migration Validation

Goal: challenge high-impact assumptions instead of asking humans to explain the whole system.

Read:

- `system-map.md`
- `business-rules.md`
- `unknowns.md`
- `evidence.md`
- `coverage.md`

Create/update `.migration/expert-questions.md`.

Ask only questions whose answers cannot reasonably be obtained from available artifacts.

For each question include:

- question
- current hypothesis
- supporting/contradictory evidence
- why the answer matters
- consequence if wrong
- preferred respondent: developer / DBA / architect / ops / security / business SME

Prioritize high-impact uncertainty affecting correctness, money, compliance, transactions, data ownership, cutover, or sequencing.

When answers are supplied, create/update `.migration/validation.md` with:

- confirmed
- corrected
- still unresolved
- new discoveries
- migration impact

Do not silently overwrite previous claims; preserve corrections and evidence.

## No-expert mode

If original experts are unavailable, triangulate using:

- executable code/PLSQL/schema
- tests
- safe runtime traces/logs
- historical outputs
- interface contracts
- runbooks/incidents/change tickets
- git history
- downstream behavior
- policy/requirements documents

Preserve observed behavior by default. Do not invent missing business intent.

Exit when no unresolved high-risk assumption prevents safely characterizing and migrating the next selected behavior.
