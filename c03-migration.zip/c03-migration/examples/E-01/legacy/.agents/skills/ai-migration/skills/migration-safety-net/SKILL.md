---
name: migration-safety-net
description: Build characterization, golden-master, differential, and reconciliation tests around a legacy migration slice before replacing behavior.
---

Use `.migration/` as the persistent project memory. Preserve existing artifacts and update them rather than silently replacing prior conclusions.

Classify material claims as **Observed**, **Inferred**, **Unknown**, or **Contradicted**. Important claims need evidence.

Never perform production writes, destructive database operations, production cutover, or irreversible actions unless separately and explicitly authorized.

Update `.migration/status.md` and `.migration/progress.md` before finishing.

# Migration Safety Net

Goal: create executable evidence of current behavior before replacement.

For the candidate slice:

1. Identify observable inputs, outputs, state changes, side effects, and failure behavior.
2. Capture representative cases from approved non-production or production-safe evidence.
3. Build characterization/golden tests that exercise the old implementation.
4. Include relevant:
   - API/UI results
   - DB state changes
   - calculations/accounting outputs
   - files
   - messages/events
   - batch results
   - state transitions
   - error behavior
5. Normalize legitimate nondeterminism explicitly; never hide unexplained mismatches.
6. Record known legacy defects separately.
7. Create `.migration/safety-net.md` containing:
   - protected workflows
   - test harness/commands
   - scenario provenance
   - invariants
   - normalization rules
   - known defects
   - coverage gaps
8. Create/update `.migration/behavior-deltas.md`.

Do not use AI-authored expected values as the sole test oracle when old-system behavior or approved requirements can be observed.

Exit when meaningful regressions in the selected slice would be detected by executable checks.
