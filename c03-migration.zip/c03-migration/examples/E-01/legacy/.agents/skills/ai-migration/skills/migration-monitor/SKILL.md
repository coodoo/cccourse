---
name: migration-monitor
description: Monitor an AI-led migration stage for stagnation, scope drift, evidence gaps, skipped coverage, unsafe actions, and verification debt; warn without taking over the worker.
---

Use `.migration/` as the persistent project memory. Preserve existing artifacts and update them rather than silently replacing prior conclusions.

Classify material claims as **Observed**, **Inferred**, **Unknown**, or **Contradicted**. Important claims need evidence.

Never perform production writes, destructive database operations, production cutover, or irreversible actions unless separately and explicitly authorized.

Update `.migration/status.md` and `.migration/progress.md` before finishing.

# Migration Monitor

Act as an independent process-health monitor. Do not redo the worker's task and do not make implementation changes unless explicitly asked.

Inspect objective artifacts and current repository state:

- `.migration/status.md`
- `.migration/coverage.md`
- `.migration/evidence.md`
- `.migration/unknowns.md`
- `.migration/progress.md`
- current slice plan/implementation/verification
- git status/diff
- available test/build logs

Look for:

- no meaningful evidence/coverage progress
- repeated examination of the same area
- premature deep dive before breadth coverage
- claims whose confidence exceeds evidence
- discovered inventory missing from coverage
- high-risk unknowns ignored
- growing diff without growing verification
- repeated failed commands/approaches without narrowing diagnosis
- scope expansion outside the current slice
- architectural churn without decision records
- tests disabled or rewritten to hide differences
- unresolved old/new behavior mismatch
- status artifacts becoming stale
- current work with no clear migration-decision relevance

Write a concise monitor entry to `.migration/progress.md` and update `.migration/status.md` only when warranted.

Use severity:

- GREEN — progress and evidence are healthy.
- YELLOW — investigate/steer soon.
- RED — stop current work before proceeding.

For YELLOW/RED provide:

- concrete observed signal
- evidence
- likely failure mode
- smallest recommended intervention

A second model's agreement is not proof. Prefer deterministic evidence and independent checks.
