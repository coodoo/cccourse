---
name: migration-design
description: Design an incremental legacy-to-target transition, coexistence model, and compatibility mapping using discovered evidence and fixed client constraints.
---

Use `.migration/` as the persistent project memory. Preserve existing artifacts and update them rather than silently replacing prior conclusions.

Classify material claims as **Observed**, **Inferred**, **Unknown**, or **Contradicted**. Important claims need evidence.

Never perform production writes, destructive database operations, production cutover, or irreversible actions unless separately and explicitly authorized.

Update `.migration/status.md` and `.migration/progress.md` before finishing.

# Migration Design

Goal: choose the smallest safe incremental transition, not a fashionable redesign.

Read the charter, system map, business rules, safety-net status, unknowns, and fixed target constraints.

If the target is pre-decided (for example WebSphere -> Spring Boot/Kubernetes), accept it as a constraint unless evidence shows a required invariant cannot be met.

Create/update `.migration/compatibility.md` mapping legacy mechanisms to target concerns. Inspect relevant legacy mechanisms such as JNDI, JTA, EJB, JMS, descriptors, shared libraries, packaging, security realms, session state, clustering, server-managed resources, connection pools, jobs, and lifecycle hooks when present.

Create/update `.migration/strategy.md` covering:

- chosen migration unit
- seam/routing mechanism
- old/new coexistence
- data strategy
- transaction implications
- deployment model
- rollback
- observability
- treatment of new features during transition
- alternatives rejected
- assumptions/risks
- why this is the smallest safe strategy

For every architectural change ask:

- what concrete problem does this solve?
- is it required for the next slice?
- what new operational cost/risk does it introduce?
- is there a smaller alternative?

Do not redesign unrelated areas.

Exit when at least one useful vertical slice can be migrated, independently verified, and rolled back without requiring a whole-system rewrite.
