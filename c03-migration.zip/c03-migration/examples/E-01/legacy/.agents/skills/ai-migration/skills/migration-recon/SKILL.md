---
name: migration-recon
description: Inventory and breadth-first map a large legacy system with evidence and coverage tracking before deep migration work begins.
---

Use `.migration/` as the persistent project memory. Preserve existing artifacts and update them rather than silently replacing prior conclusions.

Classify material claims as **Observed**, **Inferred**, **Unknown**, or **Contradicted**. Important claims need evidence.

Never perform production writes, destructive database operations, production cutover, or irreversible actions unless separately and explicitly authorized.

Update `.migration/status.md` and `.migration/progress.md` before finishing.

# Migration Recon

Goal: create a deterministic inventory and evidence-backed high-level system map. Do not start implementation.

## First: deterministic inventory

Enumerate, using commands/scripts rather than model memory where practical:

- repositories/source roots/modules
- build files and Java/framework versions
- deployables
- configuration
- tests
- SQL/DDL/PLSQL artifacts
- database object categories
- APIs
- message producers/consumers
- scheduled/batch jobs
- external integrations
- infrastructure/deployment artifacts

Create/update:

- `.migration/inventory.md`
- `.migration/coverage.md`

Every discovered area must be accounted for as `uninspected`, `sampled`, `mapped`, `deep-reviewed`, `excluded`, or `unresolved`.

## Then: breadth-first archaeology

Map:

- logical architecture
- runtime/deployment topology
- major entry points and workflows
- module relationships
- data stores and likely ownership
- integrations
- batch/scheduled paths
- auth/security boundaries
- messaging
- shared libraries
- visible transaction boundaries
- high-coupling/high-risk regions

Prefer business/runtime flow -> subsystem -> implementation detail. Avoid class-by-class narration.

Create/update:

- `.migration/system-map.md`
- `.migration/evidence.md`
- `.migration/unknowns.md`

For each important conclusion include evidence.

## Exploration loop

At regular meaningful checkpoints report:

- what is newly known
- evidence added
- coverage change
- high-risk unknowns
- current hypothesis
- next investigation
- why it affects a migration decision

Stop or redirect if one area is being explored deeply without improving coverage, resolving an important unknown, or influencing migration decisions.

Exit only when all major discovered surfaces are accounted for and the high-level topology is useful enough to identify candidate migration boundaries.


## Handoff to focused investigation

Present evidence-based candidate workflows with business value, entry points, dependencies, risks, available baseline/test environment and blocking unknowns. Reuse a clear applicable owner selection from instructions or `decisions.md`; otherwise recommend candidates and ask the owner to choose or narrow one. If evidence cannot support candidates, name the smallest useful authorized investigation.

Save the selection/source/reason in `.migration/decisions.md`; put the selected workflow or selection blocker and next action in `status.md`. Recon completion does not require a choice, but focused bizlogic and dependent stages do. Pause only target-dependent work pending selection; never silently select or recover every workflow. Selection is for investigation, not implementation; `migration-slice` later plans a small executable change within the selected workflow.
