---
name: migration-intake
description: Initialize or refresh the charter, constraints, safety boundaries, and persistent workspace for an AI-led legacy modernization engagement.
---

Use `.migration/` as the persistent project memory. Preserve existing artifacts and update them rather than silently replacing prior conclusions.

Classify material claims as **Observed**, **Inferred**, **Unknown**, or **Contradicted**. Important claims need evidence.

Never perform production writes, destructive database operations, production cutover, or irreversible actions unless separately and explicitly authorized.

Update `.migration/status.md` and `.migration/progress.md` before finishing.

# Migration Intake

Prepare the engagement for later migration stages. Do not implement migration code.

1. Inspect available repositories, existing migration documents, target-stack decisions, environment notes, and requirements.
2. Create or update `.migration/charter.md`.
3. Record:
   - migration and business goals
   - required new features
   - fixed target decisions vs undecided choices
   - non-negotiable business/technical invariants
   - security/regulatory constraints
   - available environments and access
   - permitted and prohibited actions
   - production-access rules
   - success criteria
4. Create missing shared files: `status.md`, `progress.md`, and `decisions.md`.
5. Treat inherited AI documents as leads. Mark important conclusions verified, contradicted, stale, or unverified.
6. End with the smallest set of missing inputs required to begin deterministic inventory.

Checkpoint:
- RED if implementation is requested before safety/access boundaries are known.
- YELLOW if fixed target constraints or required new-feature scope are unclear.
- GREEN when an exploration worker can act without inventing engagement rules.
