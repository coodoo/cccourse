// Reflection keeps legacy baseline compilation independent from target source.
final class Bridge {
 static String quote(String mode,String price,int quantity,String reason){return call("quote",new Class<?>[]{String.class,String.class,int.class,String.class},mode,price,quantity,reason);}
 static String order(String mode,State s,String key,int quantity,int amount,boolean fail){return call("order",new Class<?>[]{String.class,State.class,String.class,int.class,int.class,boolean.class},mode,s,key,quantity,amount,fail);}
 static String call(String method,Class<?>[] types,Object... args){try{return (String)Class.forName("Target").getDeclaredMethod(method,types).invoke(null,args);}catch(ReflectiveOperationException e){throw new IllegalStateException(e);}}
}
