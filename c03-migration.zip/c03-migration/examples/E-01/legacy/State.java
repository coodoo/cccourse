import java.util.*;
final class State {
 int stock=5, credit=1000; final Map<String,Integer> orders=new TreeMap<>();
 final List<String> audit=new ArrayList<>(), events=new ArrayList<>();
 State copy(){State s=new State(); s.stock=stock;s.credit=credit;s.orders.putAll(orders);s.audit.addAll(audit);s.events.addAll(events);return s;}
 void restore(State s){stock=s.stock;credit=s.credit;orders.clear();orders.putAll(s.orders);audit.clear();audit.addAll(s.audit);events.clear();events.addAll(s.events);}
 String snapshot(){return "stock="+stock+";credit="+credit+";orders="+orders+";audit="+audit+";events="+events;}
}
