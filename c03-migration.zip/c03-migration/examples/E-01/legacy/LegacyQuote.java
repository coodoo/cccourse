import java.math.*;
final class LegacyQuote {
 static String quote(String price,int quantity,String reason){
  if(quantity<=0) return "ERROR:QUANTITY";
  return new BigDecimal(price).multiply(BigDecimal.valueOf(quantity)).setScale(2,RoundingMode.HALF_UP).toPlainString()+"|reason="+(reason==null?"<null>":reason);
 }
}
