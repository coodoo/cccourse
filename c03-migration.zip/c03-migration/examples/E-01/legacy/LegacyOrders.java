final class LegacyOrders {
 static String submit(State s,String key,int quantity,int amount,boolean fail){
  if(s.orders.containsKey(key)) return s.orders.get(key)==amount?"DUPLICATE":"ERROR:KEY_CONFLICT";
  State before=s.copy();
  try {
   if(quantity<=0||amount<=0) throw new IllegalArgumentException("INPUT");
   if(s.stock<quantity) throw new IllegalArgumentException("STOCK");
   if(s.credit<amount) throw new IllegalArgumentException("CREDIT");
   s.stock-=quantity;s.credit-=amount;s.orders.put(key,amount);s.audit.add("ORDER:"+key+":"+amount);
   if(fail) throw new IllegalArgumentException("INJECTED");
   s.events.add("OrderAccepted:"+key);return "ACCEPTED";
  } catch(IllegalArgumentException e){s.restore(before);return "ERROR:"+e.getMessage();}
 }
}
