# Setup before class

Complete this at least two business days before class. Bring the output to the instructor. A blocked download or unavailable Claude account is an environment issue; it is never a passing exercise.

## Requirements

- Java 17 JDK with `java` on PATH; a JRE alone is insufficient. Samples compile for Java 17. Check with `java -version` and `javac -version`.

- Node 24.21.0 LTS recommended (minimum 22.13), pnpm 12.11.2, Git, a terminal and an editor. Host verification used Node 26.11.1 and Java 17.0.3; Node 24/22 and Windows have not been executed here. The SQL demonstration uses Node's built-in SQLite API, available in supported recent Node releases.

- Claude Code installed and signed in using your organization's approved access. Check `claude --version`; start `claude` interactively and confirm a small request works. Do not put authentication tokens in devlogs or prompts. Confirm your organization's quotas and network allowlist with the instructor.

- macOS/Linux are the automated-bootstrap paths. On Windows use a preflighted WSL2 environment only; native Windows .cmd wrappers are unsupported. WSL2 teaching has not been executed here. Do not discover this during class.

- Maven 3.9.11 is downloaded into `~/.cache/aglite-workshops/` on first use and verified against its pinned SHA512. No global Maven installation is required. Existing corporate Maven can be used by setting `WORKSHOP_MAVEN` to its absolute executable path after confirming its version.

## Preflight commands

Run these in the unpacked `workshops/` directory. Claude prompts in the workbooks go into the Claude chat; the commands below go into a terminal.

```sh
java -version
javac -version
node --version
pnpm --version
git --version
claude --version
node tooling/install-aglite.cjs
pnpm --dir tooling install --frozen-lockfile
pnpm --dir tooling exec playwright install chromium
node tooling/lab.cjs test 01-new-system initial
node tooling/lab.cjs test 01-new-system complete
```

If pnpm is not installed, use the organization's approved installation procedure. A local fallback is `npx --yes pnpm@12.11.2 --version`; the wrapper expects `pnpm` on PATH for Vue operations, so arrange a working executable before class. Do not assume Corepack is bundled with Node.

An actual host preflight found that `pnpm --version` succeeded while project builds failed with ENOEXEC during pinned-version switching. Its cached pnpm package still contained the native-install placeholder. Completing that already installed package's own `install.js` repaired the cache, and the actual wrapper passed afterward. Treat this as an installation issue to resolve through your approved pnpm procedure before class; a version display alone is insufficient acceptance evidence.

If aglite already exists, the installer preserves it and checks the installed `SKILL.md` SHA256 against the bundle. A mismatch blocks this preflight without overwriting anything; inspect both skills and choose the matching workshop version. The version label alone may miss edits within a release. These exercises use aglite, not the older agentflow/agv8 workflow. Restart Claude after installation. See the [bundled workflow source, SKILL.md line 12](vendor/aglite/SKILL.md), [actual commands](vendor/aglite/docs/CHEATSHEET.md) and [captured skill provenance](reference-runs/skill-provenance.md).

Maven needs access to `repo.maven.apache.org`; pnpm needs the configured npm registry; Playwright needs its browser download service. Use corporate proxy/certificate settings, including Maven `~/.m2/settings.xml`, rather than disabling TLS verification. The package is source-complete, but the first dependency downloads and AI provider are not offline. Warm all caches before class.

## Codex CLI alternative

The same aglite wishes, supervision gates and acceptance checks can be rehearsed with Codex CLI. Verify `codex --version`, approved sign-in and the installed aglite skill before class; launch `codex` from the independent student project, then type `godev` in its chat. These are aglite exercises rather than a change to the Java/Spring contract. Keep provider-specific results separate when comparing generated answers.

Codex's interactive `/clear` starts a fresh chat and clears the terminal view; send it while idle, then send a separate `godev` to recover saved project state. This matches the workshop's context-recovery exercise. [Official CLI commands](https://learn.chatgpt.com/docs/developer-commands?surface=cli) document this behavior; captured PTY evidence verifies the actual installed version. Merely clearing terminal scrollback is insufficient proof.

The reference-run summaries record actual CLI flags and permission modes. Use your organization's approved interactive permissions when teaching; a captured automation run does not establish OS isolation.

## Check an actual browser journey

Keep the server running in terminal A, then use terminal B:

```sh
# Terminal A, workshops directory
node tooling/lab.cjs start 02-brownfield complete
```

```sh
# Terminal B, workshops directory
node tooling/golden.cjs http://127.0.0.1:8080 edit
```

Use Ctrl+C in terminal A when finished. Only stop the process you started. Do not run several examples on the same port. Set `WORKSHOP_PORT` to a different port if needed and use that port in the golden command. `WORKSHOP_DB` chooses the SQLite file; always use synthetic data and a copied database for migration.

## Start your independent lab

The command refuses an existing destination and copies no build output, database, Git history or ownership marker:

```sh
# workshops directory; select your course
node tooling/lab.cjs copy 01-new-system ../my-course-1
cd ../my-course-1
git init
git add pom.xml src README.md AGENTS.md CLAUDE.md ag.json .gitignore workshop.cjs .workshop
git commit -m "Start independent workshop lab"
node workshop.cjs test
claude
```

For course 3 also stage the supplied `next` skeleton in the initial commit. Check `git remote -v`: it must be empty. The lab config disables automatic commits and pushes; students make named-path checkpoint commits themselves. `gate-design: on` lets you inspect the saved plan before approving implementation.

In Claude type `godev`. The initially absent notebook will be initialized at `.agentflow/lab.devlog.md`; this is your lab's memory, separate from previous cohorts. Course 1 starts with a working shell and intentional missing membership routes. Its build passing does not mean registration works yet.

## When something blocks

- **Download/build problem:** capture the first error and version outputs; ask the instructor to compare with the preflight machine. Do not change dependency versions during class.

- **Claude unavailable:** pair temporarily or use the instructor reference checkpoint, recording `BLOCKED(provider)` or `RESCUED`. Do not claim an advisor ran.

- **Golden/browser problem:** check the correct running port first, then Chromium installation. An unrun suite is unproved.

- **Behind on an exercise:** save a named-path attempt commit, use the course's scoped rescue, run the corresponding check, and continue the next exercise. Rescue does not prove you implemented that step.

## Sources checked for this package

[Spring MVC / Java 17 compatibility](https://docs.spring.io/spring-framework/reference/6.2/overview.html), [Spring Boot 3.5 requirements](https://docs.spring.io/spring-boot/3.5/system-requirements.html), [Node release status](https://nodejs.org/en/about/previous-releases), [Node SQLite API](https://nodejs.org/download/release/latest-v24.x/docs/api/sqlite.html), [Vue tooling](https://vuejs.org/guide/quick-start.html), [Playwright browser assertions](https://playwright.dev/docs/test-assertions), [Claude `/clear` behavior](https://support.claude.com/en/articles/14553413-claude-code-cheatsheet), and [Maven 3.9.11 release](https://release-catalog.apache.org/maven/3.9.11/index.html). Versions are pinned for a reproducible class, rather than silently upgraded to the latest release.

New PBKDF2-HMAC-SHA256 hashes use 600,000 iterations, following the [OWASP guidance](https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html). The verifier also accepts retained 210,000-iteration hashes for the migration compatibility fixture without rewriting them. Source hashes remain unchanged. This is an explicit exercise contract, not a cryptography lesson.

## Keep the classroom CLI version stable

Record `claude --version` before preflight and each rehearsal. The actual reference run began on 2.1.286; an interactive session's built-in updater installed 2.1.296. For the teaching session, launch with `DISABLE_AUTOUPDATER=1 claude` to stop background updates without changing global settings. This uses the [official auto-update control](https://code.claude.com/docs/en/setup#disable-auto-updates). Choose and preflight the organization's approved version beforehand; never silently describe a mixed-version run as a pinned run.
