const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const root = path.resolve(__dirname, '..');
const courses = ['01-new-system', '02-brownfield', '03-migration'];
const [action, course, value] = process.argv.slice(2);
if (!courses.includes(course) || !['copy', 'test', 'start'].includes(action)) {
  console.error('Usage: node tooling/lab.cjs copy <course> <new-folder> | test|start <course> initial|complete');
  process.exit(1);
}
function source(state) { return path.join(root, course, 'examples', state); }
if (action === 'copy') {
  if (!value) throw Error('Specify a new destination folder');
  const destination = path.resolve(value);
  if (fs.existsSync(destination)) throw Error('Destination exists; choose a new folder. No files overwritten.');
  fs.cpSync(source('initial'), destination, { recursive: true, filter: file => !path.relative(source('initial'),file).split(path.sep).some(p => ['target','node_modules','dist','.git','data','static','.DS_Store'].includes(p)) && !/\.(db|db-shm|db-wal|owner)$/.test(file) });
  console.log(`Copied independent initial project: ${destination}\nRun git init there, then node workshop.cjs test.`);
} else {
  if (!['initial', 'complete'].includes(value)) throw Error('Choose initial or complete');
  const r = spawnSync(process.execPath, ['workshop.cjs', action], { cwd: source(value), stdio: 'inherit', env: process.env });
  process.exitCode = r.status ?? 1;
}
