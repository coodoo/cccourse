const fs = require('node:fs');
const path = require('node:path');
const [action, target] = process.argv.slice(2);
if(!['apply','restore'].includes(action)||!target) throw Error('Usage: node tooling/bugkit.cjs apply|restore <student-course2-project>');
const root=fs.realpathSync(path.resolve(target));
const packageRoot=fs.realpathSync(path.resolve(__dirname,'..'));
if(root===packageRoot||root.startsWith(packageRoot+path.sep))throw Error('Use an independent student copy, not a reference snapshot.');
const file=path.join(root,'src/main/java/workshop/members/Validation.java');
const backup=path.join(root,'BUGKIT-original-Validation.txt');
if(action==='apply'){
 const code=fs.readFileSync(file,'utf8');
 if(fs.existsSync(backup))throw Error('A bugkit backup already exists; restore or inspect first.');
 const changed=code.replace('value.trim().toLowerCase(Locale.ROOT)','value.trim()');
 if(changed===code)throw Error('Normalization seam changed; inspect source rather than applying a guessed patch.');
 fs.writeFileSync(backup,code,{flag:'wx'});fs.writeFileSync(file,changed);
 console.log('Injected case-normalization bug. Add a failing uppercase-login regression BEFORE fixing. Restore: bugkit.cjs restore <project>.');
}else{
 const original=fs.readFileSync(backup,'utf8');fs.writeFileSync(file,original);
 console.log('Restored original Validation.java. Backup retained for comparison; rerun affected regressions.');
}
