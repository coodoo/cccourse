const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.resolve(__dirname, '..');
const excluded = new Set(['target','node_modules','dist','data','static','.DS_Store','.DS_Store','.git']);
function files(directory, relative = '') {
  return fs.readdirSync(directory,{withFileTypes:true}).flatMap(entry => {
    if(excluded.has(entry.name)||/\.(db|db-shm|db-wal|owner|zip)$/.test(entry.name)||entry.name.startsWith('.env')) return [];
    const rel=path.join(relative,entry.name),absolute=path.join(directory,entry.name);
    assert.ok(!entry.isSymbolicLink(),`Package symlink: ${rel}`);
    return entry.isDirectory()?files(absolute,rel):[rel];
  }).sort();
}
function audit() {
 const inventory=files(root);
 for(const relative of inventory){
  const file=path.join(root,relative), text=fs.readFileSync(file,'utf8');
  assert.ok(!/\/Users\/|C:\\Users\\|\/(?:private\/)?var\/folders\/|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----|sk-ant-[A-Za-z0-9_-]{20,}/.test(text),`Private path/secret candidate: ${relative}`);
  if(!relative.endsWith('.md'))continue;
  let fence=null;
  const prose=text.split('\n').filter(line=>{
   const marker=line.match(/^\s{0,3}(`{3,}|~{3,})(.*)$/);
   if(marker){
    if(!fence)fence={character:marker[1][0],length:marker[1].length};
    else if(marker[1][0]===fence.character&&marker[1].length>=fence.length&&!marker[2].trim())fence=null;
    return false;
   }
   return !fence;
  }).join('\n');
  for(const match of prose.matchAll(/\[[^\]\n]+\]\(([^)]+)\)/g)){
   let href=match[1].trim().replace(/^<|>$/g,'');
   if(/^(?:https?:|mailto:|#|app:)/.test(href))continue;
   href=href.split('#')[0].replace(/:\d+$/,'');
   // Bundled guides contain illustrative Markdown links inside code examples.
   if(relative.startsWith('vendor/'))continue;
   if(href)assert.ok(fs.existsSync(path.resolve(path.dirname(file),decodeURIComponent(href))),`Broken link ${relative}: ${href}`);
  }
  if(!relative.startsWith('vendor/')) assert.ok(!/^\s*\|.*\|\s*$/m.test(prose),`Markdown table: ${relative}`);
 }
 for(const course of ['01-new-system','02-brownfield','03-migration']){
  const text=fs.readFileSync(path.join(root,course,'workbook.md'),'utf8');
  for(const half of ['Morning','Afternoon']){
   const section=text.split(`## ${half} — 180 minutes`)[1]?.split('\n## ')[0];
   assert.ok(section,`${course} missing ${half}`);
   const total=[...section.matchAll(/\((\d+) min/g)].reduce((sum,m)=>sum+Number(m[1]),0);
   assert.equal(total,180,`${course} ${half} total`);
  }
  for(const state of ['initial','complete']){
   const sample=path.join(root,course,'examples',state);
   for(const required of ['README.md','workshop.cjs','ag.json','AGENTS.md','CLAUDE.md','.workshop/maven.cjs']) assert.ok(fs.existsSync(path.join(sample,required)),`${sample} missing ${required}`);
   const config=JSON.parse(fs.readFileSync(path.join(sample,'ag.json')));
   assert.equal(config.switches['auto-push'],'off');assert.equal(config.switches['notebook-name'],'lab.devlog.md');
  }
 }
 for(const [from,to] of [['01-new-system/examples/complete','02-brownfield/examples/initial'],['02-brownfield/examples/complete','03-migration/examples/initial']]){
  const src=path.join(root,from,'src');
  for(const relative of files(src))assert.equal(fs.readFileSync(path.join(src,relative),'utf8'),fs.readFileSync(path.join(root,to,'src',relative),'utf8'),`Inheritance drift ${from}->${to}: ${relative}`);
  assert.equal(fs.readFileSync(path.join(root,from,'pom.xml'),'utf8'),fs.readFileSync(path.join(root,to,'pom.xml'),'utf8'),`Inherited pom drift: ${to}`);
 }
 console.log(`PASS package audit: ${inventory.length} source files; six snapshots; six 180-minute agendas; links and inherited source match.`);
 return inventory;
}
if(require.main===module)audit();
module.exports={audit,root};
