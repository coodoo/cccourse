const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const [course, checkpoint, target] = process.argv.slice(2);
const maps = {
 '01-new-system': { membership: ['src/main/java/workshop/members/MembershipController.java','src/test/java/workshop/members/MembershipTest.java','src/main/resources/templates/home.html'] },
 '02-brownfield': { edit: ['src/main/java/workshop/members/MembershipController.java','src/main/java/workshop/members/MemberRepository.java','src/main/resources/templates/profile.html','src/main/resources/templates/edit.html','src/test/java/workshop/members/MembershipTest.java'] },
 '03-migration': { api: ['backend/src'], migration: ['backend/src','frontend/src','scripts'] }
};
if (!maps[course]?.[checkpoint] || !target) throw Error('Usage: node tooling/rescue.cjs <course> membership|edit|api|migration <student-project>');
const destination = fs.realpathSync(path.resolve(target));
const packageRoot = fs.realpathSync(path.resolve(__dirname,'..'));
if (destination === packageRoot || destination.startsWith(packageRoot+path.sep)) throw Error('Rescue only an independent student copy outside the supplied package.');
const mapped = maps[course][checkpoint].map(p => course==='03-migration'?'next/'+p:p);
const status = spawnSync('git',['status','--porcelain','--',...mapped],{cwd:destination,encoding:'utf8'});
if (status.status !== 0 || status.stdout.trim()) throw Error('Save your attempt using named-path git commits first; rescue requires clean replacement paths (other notebook/docs files are preserved).');
if (fs.existsSync(path.join(destination,'.agentflow','.lab.devlog.md.owner'))) throw Error('A live agent owns the notebook. Finish/stop that session and release its claim before rescue.');
const source = path.join(packageRoot,course,'examples','complete');
const nextRoot = course==='03-migration' ? path.join(destination,'next') : destination;
for(const relative of maps[course][checkpoint]) {
 const from=path.join(source,relative),to=path.join(nextRoot,relative);
 fs.mkdirSync(path.dirname(to),{recursive:true});
 fs.cpSync(from,to,{recursive:true,filter:file=>!path.relative(from,file).split(path.sep).includes('static')});
}
const notice = `RESCUED ${course} ${checkpoint} ${new Date().toISOString()}\nReference files restored; this is not student implementation evidence.${course==='03-migration'?' API reference includes bio; bio implementation is also rescued.':''}\n`;
fs.appendFileSync(path.join(destination,'RESCUE-RECORD.txt'),notice);
console.log(notice+'Commit the restored named paths. Rerun checks; label this checkpoint RESCUED in your next devlog input.');
