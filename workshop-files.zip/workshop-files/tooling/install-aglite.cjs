const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { createHash } = require('node:crypto');
const source = path.resolve(__dirname, '../vendor/aglite');
const destination = path.join(os.homedir(), '.claude', 'skills', 'aglite');
if (fs.existsSync(destination)) {
  const digest = directory => createHash('sha256').update(fs.readFileSync(path.join(directory, 'SKILL.md'))).digest('hex');
  const matches = fs.existsSync(path.join(destination, 'SKILL.md')) && digest(destination) === digest(source);
  console.log(`Existing aglite preserved: ${destination}. Bundled SKILL.md matches: ${matches}.`);
  if (!matches) console.error('BLOCKED preflight: inspect the installed and bundled skills; choose the matching workshop version before class. Nothing overwritten.');
  process.exit(matches ? 0 : 1);
}
fs.mkdirSync(path.dirname(destination), {recursive:true});
fs.cpSync(source, destination, {recursive:true,errorOnExist:true,force:false});
console.log(`Installed bundled aglite 0.3.0 for Claude Code: ${destination}`);
