'use strict';
const assert = require('node:assert/strict');
const { DatabaseSync } = require('node:sqlite');
// In-memory synthetic fixture: no customer database is opened or modified.
const db = new DatabaseSync(':memory:');
try {
  db.exec('CREATE TABLE members (id INTEGER PRIMARY KEY, email TEXT NOT NULL); CREATE UNIQUE INDEX members_email ON members(email)');
  const insert = db.prepare('INSERT INTO members(email) VALUES (?)');
  db.exec('BEGIN');
  for (let i = 0; i < 10000; i++) insert.run(`member-${i}@example.invalid`);
  db.exec('COMMIT');
  const target = 'member-8123@example.invalid';
  const slow = 'SELECT id,email FROM members WHERE lower(email)=?';
  const indexed = 'SELECT id,email FROM members WHERE email=?';
  assert.deepEqual(db.prepare(slow).all(target), db.prepare(indexed).all(target));
  const plan = sql => db.prepare(`EXPLAIN QUERY PLAN ${sql}`).all(target).map(row => row.detail).join('\n');
  const scan = plan(slow), search = plan(indexed);
  assert.match(scan, /SCAN members/i);
  assert.match(search, /SEARCH members.*(?:INDEX|COVERING INDEX).*email/i);
  console.log(`Equivalent results for normalized synthetic data.\nFunction lookup: ${scan}\nIndexed lookup: ${search}\nPlans prove scan versus index search; no latency claim.`);
} finally { db.close(); }
