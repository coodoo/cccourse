# Shared membership golden checks

Recommend Node 24.21.0; minimum Node 22.13 (the SQL fixture uses built-in `node:sqlite`). Requires pnpm, a running sample, and Chromium. Run from the copied `workshops` directory. Preparation checks used Node 26.11.1 only; the recommended and minimum versions were not exercised here.

```sh
pnpm --dir tooling install --frozen-lockfile
pnpm --dir tooling exec playwright install chromium
node tooling/golden.cjs http://127.0.0.1:8080 baseline
node tooling/golden.cjs http://127.0.0.1:8080 edit
node tooling/golden.cjs http://127.0.0.1:8080 edit --api
node tooling/golden.cjs http://127.0.0.1:8080 migration
node tooling/sql-performance.cjs
```

Use `baseline` for course 1 complete or course 2 initial, `edit` for course 2 complete or course 3 initial, and `migration` for course 3 complete. Start the migration Boot app with its built Vue assets; it serves one origin. Vite with `/api` proxy is an optional development route. `edit --api` runs inherited parity without bio; `migration` adds separate delta checks. Each command uses the supplied origin; run one mode against the matching snapshot. Course 1 initial intentionally cannot pass membership checks.

The shared browser journeys check successful normalized registration, duplicate rejection, generic login failures, session rotation, account identity, safe stored markup rendering, persistence, logout and private access. A small HTTP adapter handles form `_csrf` versus API `X-CSRF-Token`, validates invalid registration and rejects missing, wrong and valid other-session CSRF tokens on every mutating endpoint. Edit modes prove spoofed IDs update the session owner's display name while leaving the other account unchanged. The migration mode adds an independent bio persistence and length-limit check.

Goldens register fresh accounts. Logging in with an old password from a copied migration fixture and verifying its preserved ID is a separate migration tool/manual check; a golden pass does not prove copied-data compatibility.

API modes also switch accounts through the visible Login navigation in the same browser session. They wait for the second account's rendered email, assert its profile and edit inputs, then log back into the first account before later checks. This catches stale profile state after successful reauthentication.

Each run creates synthetic random `example.invalid` accounts in the running demo database. Use a disposable classroom database; the suite does not erase accounts. It owns and closes its Chromium process. Unexpected JavaScript exceptions and console errors fail the run; only known resource-status messages from intentional HTTP rejection are excluded.

The SQL fixture creates an in-memory database with 10,000 synthetic normalized emails. It asserts equivalent lookup results and `SCAN` versus indexed `SEARCH` plans. It measures no latency and opens no application database.

Observed tooling versions during preparation: Node 26.11.1, pnpm 12.11.2, Playwright 1.64.0 (official npm registry query). Dependency versions are pinned in `package.json` and `pnpm-lock.yaml`. Syntax and SQL fixture checks passed during preparation; browser runs require the running samples and are reported separately by the instructor or package validation.
