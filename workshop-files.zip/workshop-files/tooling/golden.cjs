'use strict';
const assert = require('node:assert/strict');
const { randomUUID } = require('node:crypto');
const { chromium } = require('playwright');
const [base, mode, adapter] = process.argv.slice(2);
if (!base || !['baseline', 'edit', 'migration'].includes(mode)) {
  console.error('Usage: node tooling/golden.cjs <base-url> <baseline|edit|migration> [--api]');
  process.exit(2);
}
const origin = new URL(base).origin;
const api = mode === 'migration' || adapter === '--api';
const editable = mode !== 'baseline';
const password = 'Synthetic-only-42!';
const email = `golden-${randomUUID()}@example.invalid`;
const otherEmail = `golden-${randomUUID()}@example.invalid`;
const xss = '<img src=x onerror="window.goldenXss=true">';
let browser;
const errors = [];
const check = (name, fn) => fn().then(() => console.log(`PASS ${name}`));
(async () => {
  browser = await chromium.launch();
  const context = await browser.newContext({ baseURL: origin });
  const page = await context.newPage();
  page.on('pageerror', error => errors.push(error.message));
  page.on('console', message => {
    // HTTP rejection tests intentionally produce browser resource-status messages.
    if (message.type() === 'error' && !/^Failed to load resource: the server responded with a status of (400|401|403|409|422)\b/.test(message.text())) errors.push(message.text());
  });
  const field = name => page.getByTestId(name);
  const token = async request => {
    const response = await request.get(api ? '/api/csrf' : '/login');
    assert.equal(response.status(), 200);
    if (api) return (await response.json()).token;
    const match = (await response.text()).match(/name="_csrf"[^>]*value="([^"]+)"|value="([^"]+)"[^>]*name="_csrf"/);
    assert.ok(match, 'server form exposes CSRF token');
    return match[1] || match[2];
  };
  const post = (request, route, data, csrf) => request.post(api ? `/api${route === '/profile/edit' ? '/profile' : route}` : route, {
    maxRedirects: 0,
    ...(api ? { data, headers: csrf ? { 'X-CSRF-Token': csrf } : {} } : { form: { ...data, ...(csrf ? { _csrf: csrf } : {}) } })
  });
  await check('CSRF rejects every mutation before authorization', async () => {
    const request = context.request;
    const otherSession = await browser.newContext({ baseURL: origin });
    try {
      const foreignToken = await token(otherSession.request);
      const ownToken = await token(request);
      assert.ok(foreignToken && ownToken && foreignToken !== ownToken, 'independent sessions have distinct CSRF tokens');
      for (const route of ['/register', '/login', ...(editable ? ['/profile/edit'] : []), '/logout']) {
        const data = { email, password, displayName: 'Synthetic Name' };
        for (const csrf of [undefined, 'deliberately-wrong', foreignToken]) {
          assert.equal((await post(request, route, data, csrf)).status(), 403, `${route}: missing, invalid or other-session CSRF`);
        }
      }
    } finally { await otherSession.close(); }
  });
  await check('invalid registration and successful registration', async () => {
    const csrf = await token(context.request);
    const invalid = await post(context.request, '/register', { email: 'invalid', password: 'short', displayName: '' }, csrf);
    assert.ok(invalid.status() >= 400 && invalid.status() < 500);
    await page.goto('/register');
    await field('email').fill(`  ${email.toUpperCase()}  `);
    await field('password').fill(password);
    await field('display-name').fill('Synthetic Name');
    await field('register-submit').click();
    await page.waitForURL('**/login');
  });
  await check('duplicate registration rejected', async () => {
    await page.goto('/register');
    await field('email').fill(email);
    await field('password').fill(password);
    await field('display-name').fill('Duplicate');
    await field('register-submit').click();
    await field('error').waitFor();
    assert.ok((await field('error').innerText()).trim());
  });
  await check('bad password and absent account have identical failure', async () => {
    const attempt = async address => {
      await page.goto('/login');
      await field('email').fill(address);
      await field('password').fill('Incorrect-password!');
      await field('login-submit').click();
      await field('error').waitFor();
      return (await field('error').innerText()).trim();
    };
    const badPassword = await attempt(email);
    assert.ok(badPassword, 'failure message is visible and nonempty');
    assert.equal(badPassword, await attempt(`absent-${randomUUID()}@example.invalid`));
  });
  let id;
  await check('login rotates session and profile belongs to account', async () => {
    await page.goto('/login');
    const before = (await context.cookies()).filter(c => /session/i.test(c.name));
    assert.ok(before.length, 'pre-login session cookie exists');
    await field('email').fill(email);
    await field('password').fill(password);
    await field('login-submit').click();
    await page.waitForURL('**/profile');
    await field('profile-email').waitFor();
    assert.equal((await field('profile-email').innerText()).trim(), email);
    assert.equal((await field('profile-name').innerText()).trim(), 'Synthetic Name');
    id = (await field('profile-id').innerText()).trim();
    assert.match(id, /^\d+$/);
    const after = await context.cookies();
    assert.ok(before.some(old => after.some(now => now.name === old.name && now.value !== old.value)), 'successful login rotates cookie');
  });
  await check('matrix-parameter routes cannot bypass session CSRF', async () => {
    const foreign = await browser.newContext({ baseURL: origin });
    try {
      const foreignToken = await token(foreign.request);
      const mutations = ['/register', '/login', ...(editable ? ['/profile/edit'] : []), '/logout'];
      for (const route of mutations) {
        const endpoint = api && route === '/profile/edit' ? '/profile' : route;
        const paths = api ? [`/api${endpoint};probe=1`, `/api;probe=1${endpoint}`] : [`${endpoint};probe=1`, ...(endpoint === '/profile/edit' ? ['/profile;probe=1/edit'] : [])];
        for (const path of paths) {
          const probeEmail = `matrix-${randomUUID()}@example.invalid`;
          for (const csrf of [undefined, 'deliberately-wrong', foreignToken]) {
            const data = { email: route === '/login' ? email : probeEmail, password, displayName: 'Matrix Mutation' };
            const response = await context.request.post(path, { maxRedirects: 0,
              ...(api ? { data, headers: csrf ? { 'X-CSRF-Token': csrf } : {} } : { form: { ...data, ...(csrf ? { _csrf: csrf } : {}) } })
            });
            assert.ok([400, 403, 404].includes(response.status()), `${path}: unexpected ${response.status()} for rejected matrix route`);
          }
          // A rejected registration must not have created the probe account.
          if (route === '/register') {
            const login = await post(foreign.request, '/login', { email: probeEmail, password }, await token(foreign.request));
            if (api) assert.equal(login.status(), 401);
            else { assert.ok([200, 401].includes(login.status()), 'legacy missing-account login is a rejected generic response'); assert.match(await login.text(), /Invalid email or password/); }
          }
          await page.goto('/profile');
          await field('profile-email').waitFor();
          assert.equal((await field('profile-email').innerText()).trim(), email);
          assert.equal((await field('profile-name').innerText()).trim(), 'Synthetic Name');
          assert.equal((await field('profile-id').innerText()).trim(), id);
        }
      }
    } finally { await foreign.close(); }
  });
  if (editable) {
    await check('edit persists and stored markup renders safely', async () => {
      await field('edit-link').click();
      await field('display-name').fill(xss);
      await field('save-profile').click();
      await page.waitForURL('**/profile');
      await page.reload();
      assert.equal((await field('profile-name').innerText()).trim(), xss);
      assert.equal(await field('profile-name').locator('img').count(), 0);
      assert.equal(await page.evaluate(() => window.goldenXss), undefined);
      assert.equal((await field('profile-id').innerText()).trim(), id);
      assert.equal((await field('profile-email').innerText()).trim(), email);
    });
    await check('caller-supplied identity cannot edit a second account', async () => {
      const other = await browser.newContext({ baseURL: origin });
      try {
        await post(other.request, '/register', { email: otherEmail, password, displayName: 'Second Account' }, await token(other.request));
        await post(other.request, '/login', { email: otherEmail, password }, await token(other.request));
        let otherId;
        if (api) otherId = String((await (await other.request.get('/api/profile')).json()).id);
        else {
          const otherPage = await other.newPage();
          await otherPage.goto('/profile');
          otherId = (await otherPage.getByTestId('profile-id').innerText()).trim();
        }
        const response = await post(context.request, '/profile/edit', { id: otherId, email: otherEmail, displayName: 'Session Owned' }, await token(context.request));
        assert.ok(response.status() < 500);
        if (api) assert.equal((await (await other.request.get('/api/profile')).json()).displayName, 'Second Account');
        else {
          const otherPage = await other.newPage();
          await otherPage.goto('/profile');
          assert.equal((await otherPage.getByTestId('profile-name').innerText()).trim(), 'Second Account');
        }
        await page.goto('/profile');
        assert.equal((await field('profile-name').innerText()).trim(), 'Session Owned');
        assert.equal((await field('profile-id').innerText()).trim(), id);
        assert.equal((await field('profile-email').innerText()).trim(), email);
      } finally { await other.close(); }
    });
  }
  if (api) await check('same-browser account switch reloads profile and edit fields', async () => {
    if (!editable) {
      const other = await browser.newContext({ baseURL: origin });
      try {
        const registered = await post(other.request, '/register', { email: otherEmail, password, displayName: 'Second Account' }, await token(other.request));
        assert.ok(registered.status() >= 200 && registered.status() < 400);
      } finally { await other.close(); }
    }
    const loginViaVisibleNavigation = async address => {
      if (await field('login-link').count()) await field('login-link').click();
      else await page.evaluate(() => {
        // Preserve SPA memory while exercising the agreed /login route.
        history.pushState({}, '', '/login');
        window.dispatchEvent(new PopStateEvent('popstate'));
      });
      await field('login-submit').waitFor({ state: 'visible' });
      await field('email').fill(address);
      await field('password').fill(password);
      await field('login-submit').click();
      await page.waitForURL('**/profile');
      await page.waitForFunction(expected => document.querySelector('[data-testid="profile-email"]')?.textContent.trim() === expected, address, { timeout: 10000 });
    };
    await loginViaVisibleNavigation(otherEmail);
    assert.equal((await field('profile-name').innerText()).trim(), 'Second Account');
    assert.notEqual((await field('profile-id').innerText()).trim(), id);
    if (editable) {
      await field('edit-link').click();
      assert.equal(await field('display-name').inputValue(), 'Second Account');
    }
    await loginViaVisibleNavigation(email);
    assert.equal((await field('profile-id').innerText()).trim(), id);
    assert.equal((await field('profile-name').innerText()).trim(), editable ? 'Session Owned' : 'Synthetic Name');
  });
  if (mode === 'migration') await check('bio delta: escaped persistence and 160-character limit', async () => {
    await field('edit-link').click();
    await field('bio-input').fill(xss);
    await field('save-profile').click();
    await page.waitForURL('**/profile');
    await page.reload();
    assert.equal((await field('profile-bio').innerText()).trim(), xss);
    assert.equal(await field('profile-bio').locator('img').count(), 0);
    const response = await post(context.request, '/profile/edit', { displayName: 'Session Owned', bio: 'x'.repeat(161) }, await token(context.request));
    assert.ok(response.status() >= 400 && response.status() < 500);
    assert.equal((await (await context.request.get('/api/profile')).json()).bio, xss);
  });
  if (api) await check('API logout/private guard (overlap capability reported separately)', async () => {
    await page.goto('/profile');
    await field('logout').waitFor();
    let held, rejectHeld, release, completed, handlerError, originalError, handlerStarted = false, overlapExercised = false;
    const intercepted = new Promise((resolve, reject) => { held = resolve; rejectHeld = reject; });
    const gate = new Promise(resolve => { release = resolve; });
    const completion = new Promise(resolve => { completed = resolve; });
    const bounded = (promise, milliseconds, message) => {
      let timer;
      return Promise.race([promise, new Promise((_, reject) => { timer = setTimeout(() => reject(Error(message)), milliseconds); })]).finally(() => clearTimeout(timer));
    };
    const handler = async route => {
      handlerStarted = true;
      try {
        const response = await route.fetch({ timeout: 10000 });
        assert.equal(response.status(), 200, 'held response was actually authorized');
        held();
        await gate;
        await route.fulfill({ response });
      } catch (error) { handlerError = error; rejectHeld(error); }
      finally { completed(); }
    };
    await page.route('**/api/profile', handler, { times: 1 });
    try {
      // Optional adapter capability: same-route popstate may refetch private data.
      // Its absence is not an application defect or evidence of exercised overlap.
      await page.evaluate(() => window.dispatchEvent(new PopStateEvent('popstate')));
      let capabilityTimer;
      const refetch = await Promise.race([intercepted.then(() => true), new Promise(resolve => { capabilityTimer = setTimeout(() => resolve(false), 2000); })]).finally(() => clearTimeout(capabilityTimer));
      if (!refetch) {
        if (handlerStarted) throw Error('Profile refetch started but did not return within the capability probe timeout');
        await page.unroute('**/api/profile', handler);
        console.log('UNEXERCISED profile read/logout overlap: same-route popstate does not refetch; normal logout/private guard still checked');
        await field('logout').click();
        await page.waitForURL('**/login');
        assert.equal((await context.request.get('/api/profile')).status(), 401);
      } else {
      await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
      const logoutVisible = await field('logout').isVisible();
      if (logoutVisible) {
        await field('logout').click();
        await page.waitForURL('**/login');
        assert.equal((await context.request.get('/api/profile')).status(), 401);
      } else {
        assert.equal(await field('profile-email').isVisible(), false, 'loading UI hides private profile as well as logout');
        console.log('INFO read/logout overlap prevented by loading UI; held response released before logout');
      }
      const responseReceived = page.waitForResponse(response => response.url().endsWith('/api/profile') && response.status() === 200, { timeout: 10000 });
      release();
      await bounded(completion, 15000, 'Held profile handler did not complete');
      if (handlerError) throw handlerError;
      await responseReceived;
      // Allow the fulfilled fetch and Vue render to settle without reloading SPA state.
      await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
      if (!logoutVisible) {
        await field('logout').waitFor({ state: 'visible' });
        await field('logout').click();
        await page.waitForURL('**/login');
        assert.equal((await context.request.get('/api/profile')).status(), 401);
      }
      overlapExercised = logoutVisible;
      }
      if (await field('profile-link').count()) await field('profile-link').click();
      else await page.evaluate(() => {
        history.pushState({}, '', '/profile');
        window.dispatchEvent(new PopStateEvent('popstate'));
      });
      try { await page.waitForURL('**/login', { timeout: 10000 }); }
      catch (error) {
        console.error(`Late-response probe: URL=${page.url()}, visible profile=${await field('profile-email').allTextContents()}, API status=${(await context.request.get('/api/profile')).status()}`);
        throw error;
      }
      assert.equal(await field('profile-email').count(), 0);
      assert.equal((await context.request.get('/api/profile')).status(), 401);
      if (overlapExercised) console.log('PASS exercised authorized profile response held across logout');
    } catch (error) { originalError = error; throw error; }
    finally {
      release();
      try {
        if (handlerStarted) await bounded(completion, 15000, 'Profile handler cleanup timed out');
        await page.unroute('**/api/profile', handler);
      }
      catch (cleanupError) { if (!originalError) throw cleanupError; }
    }
    await field('email').fill(email);
    await field('password').fill(password);
    await field('login-submit').click();
    await page.waitForURL('**/profile');
    await page.waitForFunction(expected => document.querySelector('[data-testid="profile-email"]')?.textContent.trim() === expected, email, { timeout: 10000 });
  });
  await check('logout clears access and private route is guarded', async () => {
    await page.goto('/profile');
    await field('logout').click();
    await page.waitForURL('**/login');
    await page.goto('/profile');
    await page.waitForURL('**/login');
    assert.equal(await field('profile-email').count(), 0);
    if (api) assert.equal((await context.request.get('/api/profile')).status(), 401);
    else {
      const response = await context.request.get('/profile', { maxRedirects: 0 });
      assert.ok([302, 303].includes(response.status()));
    }
  });
  assert.deepEqual(errors, [], 'unexpected browser JavaScript/console errors');
  console.log(`PASS ${mode} golden suite (${origin}); synthetic account ${email}`);
})().catch(error => { console.error(error); process.exitCode = 1; }).finally(async () => { if (browser) await browser.close(); });
