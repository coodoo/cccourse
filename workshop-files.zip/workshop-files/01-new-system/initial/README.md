# Runnable server example

Initial skeleton: membership routes intentionally absent.

Requires Java 17 and Node.js. Run commands from this directory. The bundled helper downloads pinned Maven locally; no global Maven installation is required.

```sh
node workshop.cjs test
node workshop.cjs start
```

Open http://127.0.0.1:8080. Stop with Ctrl+C.

```sh
WORKSHOP_PORT=8081 WORKSHOP_DB=data/rehearsal.db node workshop.cjs start
```

The server binds to loopback. SQLite creates the configured file and parent directory; never use real customer data. Keep each rehearsal database separate.

Spring MVC 6.2.11 runs inside embedded Jetty 11 with Thymeleaf pages; this project does not use Spring Boot. `App.java` wires infrastructure, `MembershipController.java` initially serves only the home page, `MemberRepository.java` owns prepared SQL, `Validation.java` owns input rules and `Passwords.java` owns password hashing.

The sole entity is `members(id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, display_name TEXT NOT NULL)`. Email is trimmed/lowercase. Names are trimmed and contain 1–80 Unicode code points; passwords contain 10–72 code points. Stored hashes use `pbkdf2-sha256$600000$BASE64_SALT$BASE64_HASH`: PBKDF2WithHmacSHA256, 600,000 iterations, 16 random salt bytes, 256-bit result. IDs and hashes are portable to the later API.

The initial contract is deliberately limited: the build passes, GET `/` renders the skeleton page, SQLite initializes, and GET `/register`, `/login`, `/profile` and POST `/logout` return 404. These 404 results identify missing student functions, rather than failed initial acceptance.

Prepared repository, validation, password helpers and unconnected templates reduce class boilerplate. The student task implements the HTTP membership routes, server-side session authorization, CSRF, session rotation and logout, then adds acceptance tests. Display-name editing is deferred to course 2.

The initial test proves only database creation, home rendering and the expected missing login route. It does not prove membership or security behavior. After the membership rescue, the recovery script replaces the home template together with the controller, so the page reports the implemented behavior.

For the separate SQL plan exercise, use a disposable synthetic fixture, not this application database: compare `EXPLAIN QUERY PLAN SELECT * FROM members WHERE lower(email)=?` with `EXPLAIN QUERY PLAN SELECT * FROM members WHERE email=?`. The unique email index supports the latter. A query plan proves lookup strategy, not a timing claim.
