package workshop.members;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public final class MembershipController {
  @GetMapping("/")
  public String home() {
    return "home";
  }
}
