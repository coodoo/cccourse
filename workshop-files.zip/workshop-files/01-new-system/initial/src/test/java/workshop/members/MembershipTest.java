package workshop.members;

import static org.junit.jupiter.api.Assertions.*;

import java.net.*;
import java.net.http.*;
import java.nio.file.*;
import org.eclipse.jetty.server.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class MembershipTest {
  @TempDir Path dir;

  @Test
  void runnableSkeletonAndExplicitGap() throws Exception {
    Path db = dir.resolve("skeleton.db");
    Server server = App.start(0, db);
    try {
      assertTrue(Files.exists(db));
      String base =
          "http://127.0.0.1:" + ((ServerConnector) server.getConnectors()[0]).getLocalPort();
      HttpClient c = HttpClient.newHttpClient();
      assertTrue(
          c.send(
                  HttpRequest.newBuilder(URI.create(base + "/")).build(),
                  HttpResponse.BodyHandlers.ofString())
              .body()
              .contains("intentionally absent"));
      assertEquals(
          404,
          c.send(
                  HttpRequest.newBuilder(URI.create(base + "/login")).build(),
                  HttpResponse.BodyHandlers.ofString())
              .statusCode());
    } finally {
      server.stop();
    }
  }
}
