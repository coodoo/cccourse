Read `.agentflow/rules.md` before project work or review.

Use synthetic data, local commits and the agreed course scope. No remote publishing or production deployment is requested.
