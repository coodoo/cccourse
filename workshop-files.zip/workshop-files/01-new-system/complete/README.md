# Runnable server example

Membership registration, login, private profile and logout; display-name editing is absent.

Requires Java 17 and Node.js. Run commands from this directory. The bundled helper downloads pinned Maven locally; no global Maven installation is required.

```sh
node workshop.cjs test
node workshop.cjs start
```

Open http://127.0.0.1:8080. Stop with Ctrl+C.

```sh
WORKSHOP_PORT=8081 WORKSHOP_DB=data/rehearsal.db node workshop.cjs start
```

The server binds to loopback. SQLite creates the configured file and parent directory; never use real customer data. Keep each rehearsal database separate.

Spring MVC 6.2.11 runs inside embedded Jetty 11 with Thymeleaf pages; this project does not use Spring Boot. `App.java` wires infrastructure, `MembershipController.java` handles HTTP/session/CSRF, `MemberRepository.java` owns prepared SQL, `Validation.java` owns input rules and `Passwords.java` owns password hashing.

The sole entity is `members(id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, display_name TEXT NOT NULL)`. Email is trimmed/lowercase. Names are trimmed and contain 1–80 Unicode code points; passwords contain 10–72 code points. Stored hashes use `pbkdf2-sha256$600000$BASE64_SALT$BASE64_HASH`: PBKDF2WithHmacSHA256, 600,000 iterations, 16 random salt bytes, 256-bit result. IDs and hashes are portable to the later API.

Sessions expire after 30 minutes of inactivity. CSRF comparison uses constant-time byte comparison. Every POST requires `_csrf` from its rendered form; login rotates the session ID and CSRF token. Logout invalidates the session. HTML renders member values with escaped Thymeleaf `th:text`/`th:value`. Login uses the same public error for unknown email and incorrect password, including a dummy hash verification.

Tests exercise persisted identities, normalized uniqueness, invalid inputs, salted password verification, SQL injection resistance and HTTP security/session behavior (the skeleton tests only its actual initial contract).

For the separate SQL plan exercise, use a disposable synthetic fixture, not this application database: compare `EXPLAIN QUERY PLAN SELECT * FROM members WHERE lower(email)=?` with `EXPLAIN QUERY PLAN SELECT * FROM members WHERE email=?`. The unique email index supports the latter. A query plan proves lookup strategy, not a timing claim.
