Follow `AGENTS.md`.

Use the installed aglite 0.3.0 skill when asked to `godev`. Read `ag.json`; the lab notebook is `.agentflow/lab.devlog.md`. Do not infer completed work from the answer snapshot.
