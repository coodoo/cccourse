package workshop.members;

import static org.junit.jupiter.api.Assertions.*;

import java.net.*;
import java.net.http.*;
import java.nio.file.Path;
import java.util.*;
import org.eclipse.jetty.server.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;

class MembershipTest {
  @TempDir Path dir;

  @Test
  void persistenceValidationAndPreparedSql() {
    MemberRepository repo = new MemberRepository(dir.resolve("test.db"));
    Member a = repo.register(" USER@Example.COM ", "long-password", " Alice ");
    assertEquals("user@example.com", a.email());
    assertEquals("Alice", a.displayName());
    assertEquals("😀".repeat(80), Validation.name("😀".repeat(80)));
    assertThrows(IllegalArgumentException.class, () -> Validation.name("😀".repeat(81)));
    Validation.password("😀".repeat(10));
    Validation.password("😀".repeat(72));
    assertThrows(IllegalArgumentException.class, () -> Validation.password("😀".repeat(73)));
    assertNotEquals("long-password", a.passwordHash());
    assertTrue(Passwords.verify("long-password", a.passwordHash()));
    assertFalse(Passwords.verify("wrong-password", a.passwordHash()));
    assertNotEquals(Passwords.hash("long-password"), Passwords.hash("long-password"));
    assertThrows(
        IllegalArgumentException.class,
        () -> repo.register("user@example.com", "long-password", "Other"));
    assertTrue(repo.byEmail("' OR 1=1 --").isEmpty());
    assertThrows(IllegalArgumentException.class, () -> repo.register("bad", "long-password", "A"));
    assertThrows(IllegalArgumentException.class, () -> repo.register("x@y.com", "short", "A"));
    assertThrows(
        IllegalArgumentException.class, () -> repo.register("x@y.com", "x".repeat(73), "A"));
    assertThrows(
        IllegalArgumentException.class, () -> repo.register("x@y.com", "long-password", " "));
    assertEquals(
        a.id(), new MemberRepository(dir.resolve("test.db")).byEmail(a.email()).orElseThrow().id());
  }

  @Test
  void existingSymlinkParentCanHostDatabase() throws Exception {
    Path realParent = dir.resolve("real-parent");
    java.nio.file.Files.createDirectories(realParent);
    Path linkedParent = dir.resolve("linked-parent");
    try {
      java.nio.file.Files.createSymbolicLink(linkedParent, realParent);
    } catch (UnsupportedOperationException | java.io.IOException e) {
      org.junit.jupiter.api.Assumptions.assumeTrue(false, "Symlinks unavailable: " + e);
    }
    MemberRepository repo = new MemberRepository(linkedParent.resolve("members.db"));
    Member member = repo.register("link@example.com", "long-password", "Linked");
    assertEquals(member.id(), repo.byEmail("link@example.com").orElseThrow().id());
    assertTrue(java.nio.file.Files.exists(realParent.resolve("members.db")));
  }

  private URI base;
  private HttpClient client;

  private HttpResponse<String> get(String path) throws Exception {
    return client.send(
        HttpRequest.newBuilder(base.resolve(path)).GET().build(),
        HttpResponse.BodyHandlers.ofString());
  }

  private HttpResponse<String> post(String path, String body) throws Exception {
    return client.send(
        HttpRequest.newBuilder(base.resolve(path))
            .header("Content-Type", "application/x-www-form-urlencoded")
            .POST(HttpRequest.BodyPublishers.ofString(body))
            .build(),
        HttpResponse.BodyHandlers.ofString());
  }

  private String token(String html) {
    var m = java.util.regex.Pattern.compile("name=\"_csrf\" value=\"([^\"]+)\"").matcher(html);
    assertTrue(m.find(), html);
    return m.group(1);
  }

  @Test
  void httpSecurityAndSessionLifecycle() throws Exception {
    Server server = App.start(0, dir.resolve("http.db"));
    try {
      base =
          URI.create(
              "http://127.0.0.1:" + ((ServerConnector) server.getConnectors()[0]).getLocalPort());
      CookieManager cookies = new CookieManager(null, CookiePolicy.ACCEPT_ALL);
      client = HttpClient.newBuilder().cookieHandler(cookies).build();
      assertEquals(
          "/login",
          URI.create(get("/profile").headers().firstValue("location").orElseThrow()).getPath());
      String csrf = token(get("/register").body());
      assertEquals(
          403,
          post("/register", "email=a%40b.com&password=long-password&displayName=A").statusCode());
      assertEquals(
          302,
          post(
                  "/register",
                  "_csrf="
                      + csrf
                      + "&email=a%40b.com&password=long-password&displayName=%3Cscript%3Ex%3C%2Fscript%3E")
              .statusCode());
      assertEquals(
          409,
          post(
                  "/register",
                  "_csrf=" + csrf + "&email=A%40B.COM&password=long-password&displayName=A")
              .statusCode());
      String old = cookies.getCookieStore().getCookies().get(0).getValue();
      assertTrue(
          post("/login", "_csrf=" + csrf + "&email=a%40b.com&password=wrong-password")
              .body()
              .contains("Invalid email or password."));
      assertTrue(
          post("/login", "_csrf=" + csrf + "&email=unknown%40b.com&password=wrong-password")
              .body()
              .contains("Invalid email or password."));
      assertEquals(
          302,
          post("/login", "_csrf=" + csrf + "&email=a%40b.com&password=long-password").statusCode());
      assertNotEquals(old, cookies.getCookieStore().getCookies().get(0).getValue());
      String profile = get("/profile").body();
      assertTrue(profile.contains("&lt;script&gt;"));
      assertFalse(profile.contains("<script>"));
      assertEquals(403, post("/logout", "_csrf=" + csrf).statusCode());
      assertEquals(302, post("/logout", "_csrf=" + token(profile)).statusCode());
      assertEquals(
          "/login",
          URI.create(get("/profile").headers().firstValue("location").orElseThrow()).getPath());
    } finally {
      server.stop();
    }
  }
}
