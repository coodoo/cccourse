package workshop.members;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class PasswordsCompatibilityTest {
  @Test void verifiesRetainedLegacyHashAndUsesCurrentWorkFactorForNewPasswords() {
    String legacy = "pbkdf2-sha256$210000$BwcHBwcHBwcHBwcHBwcHBw==$97KcwAJxSwC4Xbe9ZkIZFlRDAW7fQpwhpH7uhPFuQx0=";
    assertTrue(Passwords.verify("legacy-password", legacy));
    assertFalse(Passwords.verify("incorrect-password", legacy));
    String current = Passwords.hash("legacy-password");
    assertTrue(current.startsWith("pbkdf2-sha256$600000$"));
    assertTrue(Passwords.verify("legacy-password", current));
    assertFalse(Passwords.verify("legacy-password", legacy.replace("$210000$", "$999999999$")));
  }
}
