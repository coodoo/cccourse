package workshop.members;

import static org.junit.jupiter.api.Assertions.*;

import java.net.*;
import java.net.http.*;
import java.nio.file.Path;
import java.sql.*;
import java.util.regex.Pattern;
import org.eclipse.jetty.server.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class ErrorResponseTest {
  @TempDir Path dir;

  @Test
  void exclusiveDatabaseLockReturnsGenericHttpError() throws Exception {
    Path database = dir.resolve("locked.db");
    Server server = App.start(0, database);
    try {
      URI base = URI.create("http://127.0.0.1:" + ((ServerConnector) server.getConnectors()[0]).getLocalPort());
      HttpClient client = HttpClient.newBuilder().cookieHandler(new CookieManager(null, CookiePolicy.ACCEPT_ALL)).build();
      String form = client.send(HttpRequest.newBuilder(base.resolve("/register")).GET().build(), HttpResponse.BodyHandlers.ofString()).body();
      var token = Pattern.compile("name=\"_csrf\" value=\"([^\"]+)\"").matcher(form);
      assertTrue(token.find());
      try (Connection lock = DriverManager.getConnection("jdbc:sqlite:" + database); Statement statement = lock.createStatement()) {
        statement.execute("BEGIN EXCLUSIVE");
        try {
          HttpResponse<String> response = client.send(HttpRequest.newBuilder(base.resolve("/register"))
              .header("Content-Type", "application/x-www-form-urlencoded")
              .POST(HttpRequest.BodyPublishers.ofString("_csrf=" + token.group(1) + "&email=locked%40example.invalid&password=Synthetic-password-42&displayName=Locked"))
              .build(), HttpResponse.BodyHandlers.ofString());
          assertEquals(500, response.statusCode());
          assertEquals("Request failed.", response.body());
          assertTrue(response.headers().firstValue("content-type").orElse("").startsWith("text/plain"));
          for (String internal : new String[] {"SQLITE", "Exception", "workshop.members", "Synthetic-password-42", "locked.db"}) assertFalse(response.body().contains(internal));
        } finally { statement.execute("ROLLBACK"); }
      }
    } finally { server.stop(); }
  }
}
