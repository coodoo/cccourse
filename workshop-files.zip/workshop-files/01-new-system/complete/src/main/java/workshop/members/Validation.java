package workshop.members;

import java.util.Locale;

public final class Validation {
  private Validation() {}

  public static String email(String value) {
    String s = value.trim().toLowerCase(Locale.ROOT);
    if (s.length() > 254 || !s.matches("[^\\s@]+@[^\\s@]+\\.[^\\s@]+"))
      throw new IllegalArgumentException("Enter a valid email.");
    return s;
  }

  public static String name(String value) {
    String s = value.trim();
    if (s.isEmpty() || s.codePointCount(0, s.length()) > 80)
      throw new IllegalArgumentException("Display name must be 1–80 characters.");
    return s;
  }

  public static void password(String value) {
    if (value.codePointCount(0, value.length()) < 10
        || value.codePointCount(0, value.length()) > 72)
      throw new IllegalArgumentException("Password must be 10–72 characters.");
  }
}
