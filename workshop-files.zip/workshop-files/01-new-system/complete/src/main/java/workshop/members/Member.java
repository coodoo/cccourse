package workshop.members;

public record Member(long id, String email, String passwordHash, String displayName) {}
