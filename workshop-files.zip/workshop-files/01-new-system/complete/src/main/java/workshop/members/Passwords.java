package workshop.members;

import java.security.*;
import java.util.*;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public final class Passwords {
  private Passwords() {}

  public static String hash(String password) {
    Validation.password(password);
    byte[] salt = new byte[16];
    new SecureRandom().nextBytes(salt);
    return "pbkdf2-sha256$600000$"
        + Base64.getEncoder().encodeToString(salt)
        + "$"
        + Base64.getEncoder().encodeToString(derive(password, salt, 600000));
  }

  private static byte[] derive(String password, byte[] salt, int iterations) {
    PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, iterations, 256);
    try {
      return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
    } catch (GeneralSecurityException e) {
      throw new IllegalStateException(e);
    } finally {
      spec.clearPassword();
    }
  }

  public static boolean verify(String password, String stored) {
    try {
      String[] s = stored.split("\\$");
      if (s.length != 4 || !s[0].equals("pbkdf2-sha256") || !(s[1].equals("210000") || s[1].equals("600000"))) return false;
      byte[] salt = Base64.getDecoder().decode(s[2]), hash = Base64.getDecoder().decode(s[3]);
      return salt.length == 16
          && hash.length == 32
          && MessageDigest.isEqual(hash, derive(password, salt, Integer.parseInt(s[1])));
    } catch (IllegalArgumentException e) {
      return false;
    }
  }
}
