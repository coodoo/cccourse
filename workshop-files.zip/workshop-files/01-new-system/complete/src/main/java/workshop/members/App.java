package workshop.members;

import java.nio.file.Path;
import org.eclipse.jetty.server.*;
import org.eclipse.jetty.servlet.*;
import org.springframework.context.annotation.*;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.*;
import org.springframework.web.servlet.config.annotation.*;
import org.thymeleaf.spring6.*;
import org.thymeleaf.spring6.view.*;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;

public final class App {
  public static void main(String[] args) throws Exception {
    int port = Integer.parseInt(System.getenv().getOrDefault("WORKSHOP_PORT", "8080"));
    Server server =
        start(port, Path.of(System.getenv().getOrDefault("WORKSHOP_DB", "data/members.db")));
    server.join();
  }

  public static Server start(int port, Path db) throws Exception {
    Server server = new Server();
    ServerConnector connector = new ServerConnector(server);
    connector.setHost("127.0.0.1");
    connector.setPort(port);
    server.addConnector(connector);
    ServletContextHandler handler = new ServletContextHandler(ServletContextHandler.SESSIONS);
    handler.setContextPath("/");
    handler.setErrorHandler(new org.eclipse.jetty.server.handler.ErrorHandler() {
      @Override
      protected void generateAcceptableResponse(
          Request baseRequest, jakarta.servlet.http.HttpServletRequest request,
          jakarta.servlet.http.HttpServletResponse response, int code, String message)
          throws java.io.IOException {
        response.setStatus(code);
        response.setContentType("text/plain;charset=UTF-8");
        response.getWriter().write("Request failed.");
        baseRequest.setHandled(true);
      }
    });
    handler.getSessionHandler().setMaxInactiveInterval(30 * 60);
    handler.getSessionHandler().getSessionCookieConfig().setHttpOnly(true);
    handler.getSessionHandler().setSameSite(org.eclipse.jetty.http.HttpCookie.SameSite.LAX);
    server.setHandler(handler);
    AnnotationConfigWebApplicationContext context = new AnnotationConfigWebApplicationContext();
    context.register(WebConfig.class);
    context.addBeanFactoryPostProcessor(
        factory -> factory.registerSingleton("memberRepository", new MemberRepository(db)));
    handler.addServlet(new ServletHolder(new DispatcherServlet(context)), "/");
    server.start();
    return server;
  }

  @Configuration
  @EnableWebMvc
  @ComponentScan("workshop.members")
  public static class WebConfig implements WebMvcConfigurer {
    @Bean
    public ThymeleafViewResolver views() {
      ClassLoaderTemplateResolver resolver = new ClassLoaderTemplateResolver();
      resolver.setPrefix("templates/");
      resolver.setSuffix(".html");
      resolver.setTemplateMode("HTML");
      resolver.setCharacterEncoding("UTF-8");
      SpringTemplateEngine engine = new SpringTemplateEngine();
      engine.setTemplateResolver(resolver);
      ThymeleafViewResolver views = new ThymeleafViewResolver();
      views.setTemplateEngine(engine);
      views.setCharacterEncoding("UTF-8");
      return views;
    }
  }
}
