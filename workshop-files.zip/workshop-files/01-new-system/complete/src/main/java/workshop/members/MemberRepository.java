package workshop.members;

import java.nio.file.*;
import java.sql.*;
import java.util.Optional;

public final class MemberRepository {
  private final String url;

  public MemberRepository(Path path) {
    try {
      Path parent = path.toAbsolutePath().getParent();
      if (!Files.isDirectory(parent)) {
        Files.createDirectories(parent);
      }
      url = "jdbc:sqlite:" + path.toAbsolutePath();
      try (Connection c = open();
          Statement s = c.createStatement()) {
        s.executeUpdate(
            "CREATE TABLE IF NOT EXISTS members(id INTEGER PRIMARY KEY AUTOINCREMENT,email TEXT"
                + " UNIQUE NOT NULL,password_hash TEXT NOT NULL,display_name TEXT NOT NULL)");
      }
    } catch (Exception e) {
      throw new IllegalStateException(e);
    }
  }

  private Connection open() throws SQLException {
    Connection c = DriverManager.getConnection(url);
    try (Statement s = c.createStatement()) {
      s.execute("PRAGMA busy_timeout=5000");
    }
    return c;
  }

  public Member register(String email, String password, String name) {
    email = Validation.email(email);
    name = Validation.name(name);
    String hash = Passwords.hash(password);
    try (Connection c = open();
        PreparedStatement s =
            c.prepareStatement(
                "INSERT INTO members(email,password_hash,display_name) VALUES(?,?,?)")) {
      s.setString(1, email);
      s.setString(2, hash);
      s.setString(3, name);
      s.executeUpdate();
      return byEmail(email).orElseThrow();
    } catch (SQLException e) {
      if (e.getErrorCode() == 19)
        throw new IllegalArgumentException("Email is already registered.");
      throw new IllegalStateException(e);
    }
  }

  public Optional<Member> byEmail(String email) {
    return find("SELECT id,email,password_hash,display_name FROM members WHERE email=?", email);
  }

  public Optional<Member> byId(long id) {
    return find("SELECT id,email,password_hash,display_name FROM members WHERE id=?", id);
  }

  private Optional<Member> find(String sql, Object value) {
    try (Connection c = open();
        PreparedStatement s = c.prepareStatement(sql)) {
      s.setObject(1, value);
      try (ResultSet r = s.executeQuery()) {
        return r.next()
            ? Optional.of(new Member(r.getLong(1), r.getString(2), r.getString(3), r.getString(4)))
            : Optional.empty();
      }
    } catch (SQLException e) {
      throw new IllegalStateException(e);
    }
  }
}
