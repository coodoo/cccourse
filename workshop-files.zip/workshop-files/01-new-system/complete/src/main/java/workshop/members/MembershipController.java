package workshop.members;

import jakarta.servlet.http.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public final class MembershipController {
  private final MemberRepository members;
  private final String dummy = Passwords.hash("dummy-password-for-timing");

  public MembershipController(MemberRepository members) {
    this.members = members;
  }

  private String csrf(HttpSession session) {
    String token = (String) session.getAttribute("csrf");
    if (token == null) {
      token = UUID.randomUUID().toString();
      session.setAttribute("csrf", token);
    }
    return token;
  }

  private boolean valid(HttpServletRequest req, String token) {
    HttpSession s = req.getSession(false);
    Object expected = s == null ? null : s.getAttribute("csrf");
    return token != null
        && expected instanceof String
        && MessageDigest.isEqual(
            ((String) expected).getBytes(StandardCharsets.UTF_8),
            token.getBytes(StandardCharsets.UTF_8));
  }

  private String reject(HttpServletResponse response) {
    response.setStatus(403);
    return "forbidden";
  }

  private Member current(HttpServletRequest req) {
    HttpSession s = req.getSession(false);
    Object id = s == null ? null : s.getAttribute("memberId");
    return id instanceof Long ? members.byId((Long) id).orElse(null) : null;
  }

  private String page(String view, HttpServletRequest req, Model model) {
    model.addAttribute("csrf", csrf(req.getSession()));
    return view;
  }

  @GetMapping("/")
  public String home() {
    return "home";
  }

  @GetMapping("/register")
  public String registerPage(HttpServletRequest req, Model model) {
    return page("register", req, model);
  }

  @PostMapping("/register")
  public String register(
      @RequestParam(defaultValue = "") String email,
      @RequestParam(defaultValue = "") String password,
      @RequestParam(defaultValue = "") String displayName,
      @RequestParam(name = "_csrf", required = false) String token,
      HttpServletRequest req,
      HttpServletResponse res,
      Model model) {
    if (!valid(req, token)) return reject(res);
    try {
      members.register(email, password, displayName);
      return "redirect:/login";
    } catch (IllegalArgumentException e) {
      res.setStatus(e.getMessage().contains("already registered") ? 409 : 400);
      model.addAttribute("error", e.getMessage());
      return page("register", req, model);
    }
  }

  @GetMapping("/login")
  public String loginPage(HttpServletRequest req, Model model) {
    return page("login", req, model);
  }

  @PostMapping("/login")
  public String login(
      @RequestParam(defaultValue = "") String email,
      @RequestParam(defaultValue = "") String password,
      @RequestParam(name = "_csrf", required = false) String token,
      HttpServletRequest req,
      HttpServletResponse res,
      Model model) {
    if (!valid(req, token)) return reject(res);
    Member member = null;
    try {
      member = members.byEmail(Validation.email(email)).orElse(null);
    } catch (IllegalArgumentException ignored) {
    }
    boolean match = Passwords.verify(password, member == null ? dummy : member.passwordHash());
    if (member == null || !match) {
      model.addAttribute("error", "Invalid email or password.");
      return page("login", req, model);
    }
    req.changeSessionId();
    req.getSession().setAttribute("memberId", member.id());
    req.getSession().removeAttribute("csrf");
    return "redirect:/profile";
  }

  @GetMapping("/profile")
  public String profile(HttpServletRequest req, Model model) {
    Member member = current(req);
    if (member == null) return "redirect:/login";
    model.addAttribute("member", member);
    return page("profile", req, model);
  }

  @PostMapping("/logout")
  public String logout(
      @RequestParam(name = "_csrf", required = false) String token,
      HttpServletRequest req,
      HttpServletResponse res) {
    if (!valid(req, token)) return reject(res);
    req.getSession().invalidate();
    return "redirect:/login";
  }
}
