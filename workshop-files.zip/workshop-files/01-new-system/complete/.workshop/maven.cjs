const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');
const version = '3.9.11';
const checksum = 'bcfe4fe305c962ace56ac7b5fc7a08b87d5abd8b7e89027ab251069faebee516b0ded8961445d6d91ec1985dfe30f8153268843c89aa392733d1a3ec956c9978';
const cache = path.join(os.homedir(), '.cache', 'aglite-workshops', `apache-maven-${version}`);
const executable = path.join(cache, 'bin', process.platform === 'win32' ? 'mvn.cmd' : 'mvn');
async function maven() {
  if (process.env.WORKSHOP_MAVEN) {
    if (!fs.existsSync(process.env.WORKSHOP_MAVEN)) throw Error('WORKSHOP_MAVEN does not exist');
    return process.env.WORKSHOP_MAVEN;
  }
  if (fs.existsSync(executable)) return executable;
  if (process.platform === 'win32') throw Error('On Windows set WORKSHOP_MAVEN to Maven 3.9.11 mvn.cmd, or use preflighted WSL2. Automatic archive extraction supports macOS/Linux.');
  const root = path.dirname(cache);
  fs.mkdirSync(root, { recursive: true });
  const response = await fetch(`https://repo.maven.apache.org/maven2/org/apache/maven/apache-maven/${version}/apache-maven-${version}-bin.tar.gz`);
  if (!response.ok) throw Error(`Maven download HTTP ${response.status}; use preflight cache or WORKSHOP_MAVEN`);
  const buffer = Buffer.from(await response.arrayBuffer());
  if (crypto.createHash('sha512').update(buffer).digest('hex') !== checksum) throw Error('Maven SHA512 mismatch');
  const archive = path.join(root, `maven-${version}-${process.pid}.tar.gz`);
  fs.writeFileSync(archive, buffer, { flag: 'wx' });
  const result = spawnSync('tar', ['-xzf', archive, '-C', root], { stdio: 'inherit' });
  if (result.status !== 0 || !fs.existsSync(executable)) throw Error('Maven extraction failed');
  console.log(`Verified Maven ${version} installed in the workshop cache.`);
  return executable;
}
module.exports = { maven, version };
