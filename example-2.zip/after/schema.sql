CREATE TABLE customers(id INTEGER PRIMARY KEY, tier TEXT NOT NULL);
CREATE TABLE products(id INTEGER PRIMARY KEY, price INTEGER NOT NULL, discounted INTEGER NOT NULL DEFAULT 0);
CREATE TABLE orders(id INTEGER PRIMARY KEY, customer_id INTEGER NOT NULL, subtotal INTEGER NOT NULL DEFAULT 0, discount INTEGER NOT NULL DEFAULT 0, shipping INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'draft');
CREATE TABLE order_items(order_id INTEGER NOT NULL, product_id INTEGER NOT NULL, qty INTEGER NOT NULL);
CREATE TABLE audit(event TEXT NOT NULL, order_id INTEGER NOT NULL);
INSERT INTO customers VALUES (1,'VIP'),(2,'REGULAR');
INSERT INTO products VALUES (1,1000,1),(2,300,0),(3,200,1);
-- Hidden database-side behavior, intentionally discoverable during bizlogic
CREATE TRIGGER order_submitted AFTER UPDATE OF status ON orders
WHEN NEW.status='submitted'
BEGIN
 INSERT INTO audit(event,order_id) VALUES('submitted',NEW.id);
END;
