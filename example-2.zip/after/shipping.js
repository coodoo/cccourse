const calculate_shipping = (subtotal, tier) => tier === 'VIP' || subtotal >= 1500 ? 0 : 120
module.exports = {calculate_shipping}
