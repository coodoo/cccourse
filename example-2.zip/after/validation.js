const validate_order = (items, discounted_qty) => {
  if (!items?.length) throw Error('empty order')
  if (discounted_qty > 5) throw Error('discounted item limit exceeded: 5')
}
module.exports = {validate_order}
