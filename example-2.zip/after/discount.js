const calculate_discount = (subtotal, tier) =>
  (tier === 'VIP' ? Math.floor(subtotal * 0.10) : 0) + (subtotal >= 2000 ? 100 : 0)
module.exports = {calculate_discount}
