const fs = require('node:fs')
const path = require('node:path')
const { DatabaseSync } = require('node:sqlite')
const {calculate_discount} = require('./discount')
const {calculate_shipping} = require('./shipping')
const {validate_order} = require('./validation')
const setup = () => {
  const db = new DatabaseSync(':memory:')
  db.exec(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'))
  return db
}
const run = (input) => {
  const db = setup()
  const customer = db.prepare('SELECT tier FROM customers WHERE id=?').get(input.customer_id)
  if (!customer) throw Error('unknown customer')
  if (!input.items?.length) throw Error('empty order')
  let subtotal = 0
  let discounted_qty = 0
  for (const item of input.items) {
    const product = db.prepare('SELECT * FROM products WHERE id=?').get(item.product_id)
    if (!product || !Number.isInteger(item.qty) || item.qty < 1) throw Error('invalid item')
    subtotal += product.price * item.qty
    if (product.discounted) discounted_qty += item.qty
  }
  validate_order(input.items, discounted_qty)
  const discount = calculate_discount(subtotal, customer.tier)
  const shipping = calculate_shipping(subtotal, customer.tier)
  db.prepare('INSERT INTO orders(id,customer_id,subtotal,discount,shipping) VALUES(1,?,?,?,?)').run(input.customer_id,subtotal,discount,shipping)
  for (const item of input.items) db.prepare('INSERT INTO order_items VALUES(1,?,?)').run(item.product_id,item.qty)
  db.prepare("UPDATE orders SET status='submitted' WHERE id=1").run()
  const order = db.prepare('SELECT * FROM orders WHERE id=1').get()
  const audit = db.prepare('SELECT event FROM audit WHERE order_id=1').all().map(x=>x.event)
  return {subtotal,discount,shipping,total:subtotal-discount+shipping,discounted_qty,status:order.status,audit}
}
module.exports = {run}
