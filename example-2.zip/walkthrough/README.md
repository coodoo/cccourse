# Reference migration artifacts
Each exercise has a separate `.migration/` snapshot representing a plausible completed migration workflow. **Synthetic instructor examples, not actual Codex transcripts.** Use as teaching illustrations or a fallback when live agents take too long.
