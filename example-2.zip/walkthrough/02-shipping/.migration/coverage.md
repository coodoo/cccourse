# Coverage
- discount: mapped
- shipping: mapped
- order validation: mapped
- shipping: deeply analyzed
