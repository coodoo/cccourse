# Strategy
Incremental extraction of shipping to dedicated CommonJS module. Keep legacy implementation as oracle; use test harness as cutover simulation. Roll back by routing to legacy.run. No production deployment in this lab.
