# Expert questions
- Q-2: Should the shipping behavior described in BR-2 be preserved?
- Hypothesis: yes. Evidence: legacy implementation and fixtures. Impact if wrong: business behavior changes.
