# Decisions
- Scope: shipping
- Preserve parity except: none
