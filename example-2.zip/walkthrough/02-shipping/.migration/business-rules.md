# Business rules
- BR-2: VIP or pre-discount subtotal >=1500 gives free shipping, otherwise 120
- Observed in before/legacy.js and/or SQL; confirm business intent separately.
