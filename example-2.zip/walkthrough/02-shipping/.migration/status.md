# Status
stage: verify
state: green
current_scope: shipping
next_action: select next slice or review rollout
