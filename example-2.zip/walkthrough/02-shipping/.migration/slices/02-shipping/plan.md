# Slice plan
Scope: shipping only.
Entry: legacy.run; target: after/shipping.js.
Invariant: parity except approved delta.
Steps: extract rule, preserve call signature, run comparison tests.
Stop if unrelated behavior changes. Rollback: use legacy.run.
