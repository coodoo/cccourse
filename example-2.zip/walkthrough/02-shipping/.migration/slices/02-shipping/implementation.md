# Implementation
Reference solution: after/shipping.js and after/modern.js.
Run `node --test tests/*.test.js`.
