# System map
CLI -> legacy.run -> SQLite customer/product lookup -> shipping rules -> orders/order_items -> status update -> audit trigger.
Major workflows: discount, shipping, order validation.
