# Status
stage: verify
state: green
current_scope: discount
next_action: select next slice or review rollout
