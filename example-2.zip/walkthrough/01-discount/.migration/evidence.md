# Evidence
- before/legacy.js: subtotal, discount, shipping, validation
- before/schema.sql: order_submitted trigger
- fixtures/samples.json: executable scenarios
