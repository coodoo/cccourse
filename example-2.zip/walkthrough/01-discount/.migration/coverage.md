# Coverage
- discount: mapped
- shipping: mapped
- order validation: mapped
- discount: deeply analyzed
