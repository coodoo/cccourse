# Inventory
Node CommonJS CLI, SQLite in-memory schema, order/customer/product/audit tables, trigger, SQL CASE. No external packages.
