# Safety net
- Use `node --test tests/*.test.js` from repository root.
- Legacy and modern outputs are compared for all non-delta fixtures.
- For exercise 3, `limit_six` is intentional divergence; old accepts, new rejects.
- Coverage gaps: concurrency, persistence across processes, security, production DB behavior.
