# Expert questions
- Q-1: Should the discount behavior described in BR-1 be preserved?
- Hypothesis: yes. Evidence: legacy implementation and fixtures. Impact if wrong: business behavior changes.
