# Devlog
1. Mapped system.
2. Recovered discount rule.
3. Recorded synthetic validation.
4. Built comparison tests.
5. Planned extraction.
6. Implemented and verified reference solution.
