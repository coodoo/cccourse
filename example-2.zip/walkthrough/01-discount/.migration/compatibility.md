# Compatibility
Both implementations use Node.js and SQLite. JS extraction replaces SQL CASE for shipping; SQLite audit trigger remains in place. Outputs retain shape.
