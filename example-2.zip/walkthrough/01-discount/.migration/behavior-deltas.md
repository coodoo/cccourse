# Intentional deltas
- none
- Approval: classroom requirement. Verify with explicit tests; do not classify as regression.
