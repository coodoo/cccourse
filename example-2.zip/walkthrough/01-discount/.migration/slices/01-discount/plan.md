# Slice plan
Scope: discount only.
Entry: legacy.run; target: after/discount.js.
Invariant: parity except approved delta.
Steps: extract rule, preserve call signature, run comparison tests.
Stop if unrelated behavior changes. Rollback: use legacy.run.
