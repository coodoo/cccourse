# Verification
Expected: parity on normal fixtures, explicit delta on `limit_six` for exercise 3. See actual test output by running `node --test tests/*.test.js`.
Residual gaps: concurrency and production rollout not exercised.
