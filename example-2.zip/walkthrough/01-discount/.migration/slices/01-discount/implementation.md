# Implementation
Reference solution: after/discount.js and after/modern.js.
Run `node --test tests/*.test.js`.
