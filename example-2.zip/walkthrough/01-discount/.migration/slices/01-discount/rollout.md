# Rollout
Lab-only: compare CLI results before cutover. For real systems use feature flag, monitoring, canary and rollback. Trigger rollback on unexplained behavior delta.
