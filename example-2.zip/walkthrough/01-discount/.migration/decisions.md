# Decisions
- Scope: discount
- Preserve parity except: none
