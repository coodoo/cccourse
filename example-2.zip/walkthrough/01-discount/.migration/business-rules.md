# Business rules
- BR-1: VIP 10% floor and bulk subtotal >=2000 minus 100; discounts stack
- Observed in before/legacy.js and/or SQL; confirm business intent separately.
