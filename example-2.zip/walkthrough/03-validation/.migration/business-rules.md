# Business rules
- BR-3: items must be nonempty and quantities positive; new cap discounted_qty <=5
- Observed in before/legacy.js and/or SQL; confirm business intent separately.
