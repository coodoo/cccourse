# Implementation
Reference solution: after/validation.js and after/modern.js.
Run `node --test tests/*.test.js`.
