# Charter
Scope: order validation migration; preserve behavior except explicitly approved changes. No production DB; in-memory SQLite.
