# Status
stage: verify
state: green
current_scope: order validation
next_action: select next slice or review rollout
