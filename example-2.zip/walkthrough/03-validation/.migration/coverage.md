# Coverage
- discount: mapped
- shipping: mapped
- order validation: mapped
- order validation: deeply analyzed
