# Intentional deltas
- discounted_qty >5 now rejected
- Approval: classroom requirement. Verify with explicit tests; do not classify as regression.
