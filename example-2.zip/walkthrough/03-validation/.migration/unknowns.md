# Unknowns
- Is order validation current behavior intentional? Requires owner confirmation in real migration.
