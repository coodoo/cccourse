# Expert questions
- Q-3: Should the order validation behavior described in BR-3 be preserved?
- Hypothesis: yes. Evidence: legacy implementation and fixtures. Impact if wrong: business behavior changes.
