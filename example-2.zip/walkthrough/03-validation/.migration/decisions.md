# Decisions
- Scope: order validation
- Preserve parity except: discounted_qty >5 now rejected
