const {run} = require('./legacy')
const samples = require('../fixtures/samples.json')
const key = process.argv[2] || 'all'
const names = key === 'all' ? Object.keys(samples) : [key]
for (const name of names) console.log(JSON.stringify({case:name,result:run(samples[name])}))
