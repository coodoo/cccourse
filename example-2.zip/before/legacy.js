const fs = require('node:fs')
const path = require('node:path')
const { DatabaseSync } = require('node:sqlite')
const setup = () => {
  const db = new DatabaseSync(':memory:')
  db.exec(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'))
  return db
}
const run = (input) => {
  const db = setup()
  const customer = db.prepare('SELECT tier FROM customers WHERE id=?').get(input.customer_id)
  if (!customer) throw Error('unknown customer')
  if (!input.items?.length) throw Error('empty order')
  let subtotal = 0
  let discounted_qty = 0
  for (const item of input.items) {
    const product = db.prepare('SELECT * FROM products WHERE id=?').get(item.product_id)
    if (!product || !Number.isInteger(item.qty) || item.qty < 1) throw Error('invalid item')
    subtotal += product.price * item.qty
    if (product.discounted) discounted_qty += item.qty
  }
  // Legacy rules intentionally split between JS and SQL.
  const vip_discount = customer.tier === 'VIP' ? Math.floor(subtotal * 0.10) : 0
  const bulk_discount = subtotal >= 2000 ? 100 : 0
  const discount = vip_discount + bulk_discount
  const shipping = db.prepare("SELECT CASE WHEN ?='VIP' OR ?>=1500 THEN 0 ELSE 120 END AS fee").get(customer.tier, subtotal).fee
  db.prepare('INSERT INTO orders(id,customer_id,subtotal,discount,shipping) VALUES(1,?,?,?,?)').run(input.customer_id,subtotal,discount,shipping)
  for (const item of input.items) db.prepare('INSERT INTO order_items VALUES(1,?,?)').run(item.product_id,item.qty)
  db.prepare("UPDATE orders SET status='submitted' WHERE id=1").run()
  const order = db.prepare('SELECT * FROM orders WHERE id=1').get()
  const audit = db.prepare('SELECT event FROM audit WHERE order_id=1').all().map(x=>x.event)
  return {subtotal,discount,shipping,total:subtotal-discount+shipping,discounted_qty,status:order.status,audit}
}
module.exports = {run}
