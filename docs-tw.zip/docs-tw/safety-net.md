# 先保住舊行為，再動手改

在新程式原始碼還沒出現前，就已經保存[舊程式基準與實際命令](../project/.migration/evidence/initial/baseline.json)。取基準時，工具只編譯凍結的舊 Java 程式；標準答案來自實際輸出，不是讓新程式自己算給自己驗。

S-01 保護四種報價情況：`1.005` 的半分邊界、多數量相乘後的捨入、明確的 VIP 原因，以及不合法數量。四行輸出都要比較。

唯一可忽略的差別是選填原因的 null 和空字串；金額沒有誤差容許範圍。

S-02 的下單基準也提早保存，但要等 S-01 完成後，再判斷下單切片是否準備好、是否需要擴充副作用保護。完整快照包含庫存、信用額度、識別碼／金額、稽核和事件，也包含錯誤與重試。

固定要求：編譯前清單指紋必須一致；比對新程式時一定讀取已保存的初始基準。這次沒有批准修正舊模型已知缺陷。

Oracle、回呼、批次輸出、真實資料庫狀態、訊息、並行和持久保存，目前都沒有測試保護。

原始命令從 `project/` 執行，這裡只是翻譯歷史記錄，不要求覆寫已有證據：

```sh
python3 runner.py baseline --output .migration/evidence/initial
python3 runner.py verify --slice S-01 --variant bad --output .migration/evidence/s01-initial
```

工具預設拒絕覆寫已存在的證據；只有明確指定 `--force` 才允許，而且仍限制在證據目錄內。

S-02 準備時再檢查：在寫 `Target.order` 前，確認八行舊結果和所有完整狀態欄位。保護成功、重複／衝突、庫存／額度／輸入錯誤、注入失敗復原和重試。本機可繼續，真實資料庫仍 HOLD。

S-02 失敗後再檢查：漏掉信用額度和稽核，讓八行完整狀態都不一樣，也改變額度不足的判斷。基準和比對器保持不動，不把副作用「正規化掉」。

確認完整狀態、復原和重複請求保護仍有效後，在原本替換點裡修正 `Target.order`，然後重跑。[失敗證據](../project/.migration/evidence/s02-initial/verify-S-02-bad.json)保留。

英文原文：[safety-net.md](../project/.migration/safety-net.md)。
