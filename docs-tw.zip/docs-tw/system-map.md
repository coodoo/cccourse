# 這個範例怎麼串起來

實際能跑的 Java 模型有兩條路：

```text
Scenario.quote → LegacyQuote
Scenario.order → LegacyOrders → State
                                ├── stock：庫存
                                ├── credit：可用信用額度
                                ├── orders：訂單
                                ├── audit：稽核紀錄
                                └── events：事件
```

`State` 的複製／還原，是單一執行緒、記憶體內的失敗復原。它不是實際資料庫交易。

只做原始碼閱讀的 SQL 關係如下：

```text
quote_price → ROUND
submit_order → stock / orders / outbox
新增 orders → order_credit_audit → customer_credit / order_audit
夜間排程 → nightly_reconcile → callback_config → 動態回呼（內容未知）
```

這個練習的資料都由模型 `State` 管理。真實資料庫由誰控制交易、回呼做什麼、登入驗證、訊息消費端和部署方式，都還不知道。

可考慮的替換點是：先換只讀取、不改資料的報價，再換包含全部副作用的下單。批次與回呼已標出位置，但這次不替換。

不要在還沒決定真實交易邊界時，就把信用額度另外拆成一個服務，否則原本一起成功或失敗的操作可能被拆散。

英文原文：[system-map.md](../project/.migration/system-map.md)。
