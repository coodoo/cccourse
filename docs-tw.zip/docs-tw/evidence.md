# 每個說法的證據在哪裡

實際閱讀的 Java 原始碼：[報價](../project/legacy/LegacyQuote.java#3)、[下單交易](../project/legacy/LegacyOrders.java#2)、[快照](../project/legacy/State.java#6)、[情境](../project/legacy/Scenario.java#2)。

只有閱讀、沒有實際跑 Oracle 的 SQL：[定價](../project/legacy/oracle.sql#8)、[額度／稽核觸發器](../project/legacy/oracle.sql#11)、[庫存／訂單／待送事件](../project/legacy/oracle.sql#17)、[動態回呼與排程](../project/legacy/oracle.sql#24)。

來源身分記錄：[skill 指紋](../project/.migration/evidence/skill-hashes.json)、[凍結舊程式指紋](../project/.migration/evidence/legacy-hashes.json)。Recon 當時還沒執行擷取；後來取得的執行觀察列在下面。看過原始碼與實際跑過，仍要分開。

實際執行結果：[初始基準](../project/.migration/evidence/initial/baseline.json)、[報價失敗](../project/.migration/evidence/s01-initial/verify-S-01-bad.json)、[報價修正](../project/.migration/evidence/s01-final/verify-S-01-correct.json)、[下單失敗](../project/.migration/evidence/s02-initial/verify-S-02-bad.json)、[下單修正](../project/.migration/evidence/s02-final/verify-S-02-correct.json)、[路由演練](../project/.migration/evidence/routing/routing-S-02-correct.json)。

新程式來源：[報價](../project/target/Target.java#3)、[下單](../project/target/Target.java#8)；測試工具：[基準與比較](../project/runner.py#36)。標準答案獨立於新程式邏輯保存。

譯註：JSON 是原始執行證據，欄位名稱、命令、數字與輸出保留原樣。中文報告解釋它們，不把改寫過的 JSON 冒充原始紀錄。

英文原文：[evidence.md](../project/.migration/evidence.md)。
