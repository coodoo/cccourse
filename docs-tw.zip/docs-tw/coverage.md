# 哪些地方看過了，看到多深

這份紀錄使用 recon 的固定狀態值。`uninspected` 是還沒看，`sampled` 是只抽看一部分，`mapped` 是已知道位置與關係，`deep-reviewed` 是已深入檢查，`excluded` 是明確排除，`unresolved` 是還有問題沒查清楚。

- `legacy/State.java`：deep-reviewed。完整檢查庫存、信用額度、訂單識別碼、稽核與事件的快照、複製和還原。

- `legacy/LegacyQuote.java`：deep-reviewed。檢查報價、錯誤和原因欄位的分支。

- `legacy/LegacyOrders.java`：deep-reviewed。檢查重複請求、識別碼衝突、輸入、庫存、信用額度、資料異動、失敗與事件分支。

- `legacy/Scenario.java`：deep-reviewed。檢查全部命令列與情境入口。

- `legacy/Bridge.java`：mapped。確認它是靠反射呼叫新程式的切換點，只在走新程式時使用。

- `legacy/oracle.sql`：`quote_price`、`submit_order`、`order_credit_audit` 和六張資料表已做靜態 deep-reviewed。`nightly_reconcile` 和排程工作是 mapped。設定指定的回呼是 unresolved，因為沒有設定值和實作內容。

- `target/Target.java`：最初是 uninspected，等到執行切片才檢查；完成後的狀態見下方。

- `runner.py`：最初是 uninspected，等到建立測試保護才檢查；完成後的狀態見下方。

- 真正的 Oracle、Spring、PostgreSQL 和訊息服務：excluded，不在可執行範圍。正式上線前仍然必須驗證。

提供的主要可執行部分都已列入。光看 SQL 原始碼，不能證明 Oracle 工作或回呼在實際環境會不會被呼叫。

最後更新：`target/Target.java` 的報價與下單分支已 deep-reviewed；`runner.py` 也已 deep-reviewed，包含只編譯舊程式來取基準、雜湊檢查、逐行完整比對、輸出位置限制與禁止覆寫。兩者都已在本機執行。

舊程式和 SQL 的涵蓋狀態不變，動態回呼仍未解決。

英文原文：[coverage.md](../project/.migration/coverage.md)。
