# 各階段怎麼用、依據哪個版本

開始工作前，已完整讀取原始 `ai-migration-skill/SKILL.md` 和十個 `skills/*/SKILL.md`。精確路徑與 SHA-256 指紋保存在 [skill-hashes.json](../project/.migration/evidence/skill-hashes.json)。

這次只把來源檔當成這個有限練習的工作指示，沒有全域安裝，也沒有正式環境安裝。

實作者實際順序是：協調代理初始檢查 → intake → recon → bizlogic → validate（無專家）→ safety-net（只跑舊程式取基準）→ design → slice（S-01 計畫）→ execute（錯誤／正確模式）→ verify（實作者自查）→ 協調代理更新狀態。

接著是：slice（S-02 計畫）→ 有條件補查 safety-net → execute（錯誤版）→ verify（發現失敗）→ 回到 bizlogic → 回到 validate → 回到 safety-net → execute（修正）→ verify（自查／路由演練）→ monitor 清單自查與交接 → 協調代理更新狀態。

各階段轉換時都有保存產出，計畫也先於新程式。[實際進度](progress.md)保留檢查點。

S-01 的錯誤與正確分支是一起寫的，供重複比較；S-02 則確實在失敗和回頭檢查後才改程式。沒有假裝是在不知情的情況下，才發現示範者刻意放入的錯誤。

十套階段指示都已讀取，並用於適用的工作。獨立 verify 和 monitor 原本交給新的審查者，現在已在本機模型範圍完成；實作者自查沒有代替它們。

沒有編造專家／人類批准，也沒有假造介面操作逐字紀錄。

每一個本機 GO，都是代理對下一個可回復模型動作的判斷。正式上線全程 HOLD。

`.migration` 報告是撰寫的分析；JSON 命令區塊是子程序實際觀察；最上層命令狀態索引則記下工具真正的結果。這三種資料不能混成同一種證據。

最後的獨立階段：審查者完整讀取 verify／monitor 指示，先驗 S-01 再驗 S-02，將發現回報給主代理，由主代理整合共用紀錄。見[進度](progress.md)與[獨立命令](../project/.migration/evidence/independent-review/reviewer-commands.json)。

最後交付原始碼的指紋在[清單](../project/.migration/evidence/final-source-hashes.json)。以下連結保留原報告記錄的來源檔與行號，對應目前檔案；歷史定位不代表重新校驗過原執行版本：

- [協調路由：SKILL.md，第 168 行](../../ai-migration-skill/SKILL.md#168)。

- [盤點涵蓋狀態：migration-recon/SKILL.md，第 38 行](../../ai-migration-skill/skills/migration-recon/SKILL.md#38)。

- [執行迴圈：migration-execute/SKILL.md，第 26 行](../../ai-migration-skill/skills/migration-execute/SKILL.md#26)。

- [驗證獨立性：migration-verify/SKILL.md，第 19 行](../../ai-migration-skill/skills/migration-verify/SKILL.md#19)。

- [監控獨立角色：migration-monitor/SKILL.md，第 17 行](../../ai-migration-skill/skills/migration-monitor/SKILL.md#17)。

記錄的 skill 指紋，是遷移歷史檔改名為 `progress.md` 前所用指示的歷史觀察，因此保留不動。現在提示與連結使用新名稱，歷史內容沒有改。

英文原文：[stage-manifest.md](../project/.migration/stage-manifest.md)。
