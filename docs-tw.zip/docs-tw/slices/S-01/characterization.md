# S-01：先把舊程式怎麼做記下來

四筆舊程式輸出和編譯命令，已存在[基準檔](../../../project/.migration/evidence/initial/baseline.json)。擷取時新程式原始碼還沒寫。

這些輸入涵蓋剛好半分、相乘、明確填寫／空白原因，以及不合法數量。報價路徑不改任何狀態。

null 和空字串原因視為一樣，已經明確記錄。這個例外只適用於原因文字，不是允許金額有誤差。

英文原文：[slices/S-01/characterization.md](../../../project/.migration/slices/S-01/characterization.md)。
