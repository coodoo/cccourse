# S-01：實際做了什麼

新增 `Target.quote`，保留故意錯用 `HALF_EVEN` 的模式，也提供正確的 `HALF_UP` 模式。兩者都自己做十進位運算，沒有直接呼叫 `LegacyQuote` 假裝完成改寫。

新程式把沒填的原因轉成空字串。

實際檢查結果：錯誤模式結束碼 1，抓到兩筆計算錯誤；正確模式結束碼 0。可看[失敗結果](../../../project/.migration/evidence/s01-initial/verify-S-01-bad.json)和[修正結果](../../../project/.migration/evidence/s01-final/verify-S-01-correct.json)。

沒有擴大範圍。兩個分支是一起寫好的，目的是保留可以反覆重播的錯誤示範；修正的呈現方式是選用正確模式。

不要把這段教學說成「原先不知道程式有錯，後來才意外發現」。這次沒有新業務規則，也沒有尚未解釋的模型差異。

英文原文：[slices/S-01/implementation.md](../../../project/.migration/slices/S-01/implementation.md)。
