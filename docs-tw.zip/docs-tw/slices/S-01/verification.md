# S-01：怎麼知道報價改對了

四筆輸出都與另外保存的初始舊程式基準比較。

錯誤模式結束碼是 1。邊界案例得到 `1.00`，舊程式是 `1.01`；多數量案例得到 `7.00`，舊程式是 `7.01`。兩筆都是新程式造成的錯誤。

正確模式結束碼是 0，除了事先允許的原因欄位處理，沒有其他差異。

實際的 `javac`／`java` 執行與比對見[錯誤版](../../../project/.migration/evidence/s01-initial/verify-S-01-bad.json)和[正確版](../../../project/.migration/evidence/s01-final/verify-S-01-correct.json)。原因的 null／空字串屬於可接受差別，不是業務行為變更。

資料核對方面，這條路只有讀取、沒有異動。沒有執行真正的外部整合、效能、資安或 Oracle 比較，因此不能聲稱那些已經準備好。

當時的建議是：本機模型比對可以繼續（GO），等待主代理安排獨立驗證；正式上線 HOLD。實作者自查不能代替獨立角色。下面是之後補上的結果。

## 後來的獨立驗證

新的審查者自己重建只含舊程式的基準，再驗證 S-01。錯誤版結束碼 1；正確版結束碼 0，沒有無法解釋的模型差異。

可查[獨立執行命令](../../../project/.migration/evidence/independent-review/reviewer-commands.json)和[修正版結果](../../../project/.migration/evidence/independent-review/verify-S-01-correct.json)。

本機的獨立驗證已完成（COMPLETE）；這個教學流程的監控為 GREEN。較早的 `READY_FOR_REVIEW` 是實作者交接當時的狀態，不是目前還沒完成。

正式上線仍是 HOLD，因為前面列的真實系統檢查都沒執行。這份報告沒有提供人類批准。

英文原文：[slices/S-01/verification.md](../../../project/.migration/slices/S-01/verification.md)。
