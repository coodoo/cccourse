# 從程式追出來的業務規則

R-01：模型的 `quote(price, quantity, reason)` 不接受小於等於零的數量。它用十進位數相乘，再以 `HALF_UP` 捨入到小數點後兩位；這條路不改任何狀態。可對照 [Java](../project/legacy/LegacyQuote.java#3) 和 [SQL ROUND](../project/legacy/oracle.sql#8)。

這項規則對 Java 模型的可信度高；SQL 遇到負數、剛好一半或 null 時，仍需實際執行確認。最初下一步是擷取模型行為；後來保存的基準和 S-01 修正版比對，確認了四個 Java 案例。這條規則當時記錄的獨立審查仍待進行，最後結果見[驗證報告](slices/S-01/verification.md)。

R-02：模型下單時先檢查輸入、庫存和可用信用額度。成功後扣庫存與額度，記錄識別碼和金額，再加入稽核紀錄與事件。同一識別碼、同一金額重送，回傳 `DUPLICATE`，而且不再改資料；金額不同則回傳 `KEY_CONFLICT`。

依據是 [Java](../project/legacy/LegacyOrders.java#2)、[觸發器](../project/legacy/oracle.sql#11) 和[程序](../project/legacy/oracle.sql#17)。對這個人造模型的判斷可信度高，但沒有業務人員批准。

R-03：如果在改動資料後故意觸發失敗，庫存、額度、訂單、稽核與事件都要還原；失敗後重試可以成功。依據是 [restore](../project/legacy/LegacyOrders.java#13)。SQL 的原子性，也就是是否整批一起成功或失敗，以及呼叫端怎麼處理交易，仍不清楚。

R-04：從 SQL 靜態閱讀可見，停用的夜間工作會依設定名稱呼叫回呼，並以 `DBMS_ASSERT` 檢查名稱。它不是寫死的直接呼叫；設定資料與回呼內容沒有提供。依據是 [SQL](../project/legacy/oracle.sql#24)。執行時的影響未知，這次不替換。

教學假設 H-01：只要下單的接受結果、庫存與事件一樣，也許就夠了。這是刻意放進來、而且不完整的推論。完整原始碼本來就看得到信用額度和稽核；不能把這個疏漏說成原先無法發現的問題。

H-01 必須用完整狀態比對來挑戰，不能拿它降低基準要求。上面各規則已分別列出流程／輸入、判斷／輸出、狀態／副作用與錯誤；模型驗證和專家確認仍是兩回事。

S-02 失敗後回頭檢查：H-01 已被推翻（Contradicted）。只看接受結果、庫存和事件，會漏掉沒有扣額度、沒有寫稽核的錯誤。額度一直沒扣，連後面原本應拒絕的請求也被接受了。

因此保留 R-02 的完整副作用要求。證據是[失敗比對](../project/.migration/evidence/s02-initial/verify-S-02-bad.json)。這是修正刻意安排的理解／實作疏漏，不是發現原本看不到的程式。

英文原文：[business-rules.md](../project/.migration/business-rules.md)。
