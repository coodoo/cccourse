# S-01 報價遷移：繁體中文課堂報告

這裡把原本完成版 `project/.migration/` 的共用報告，以及 `slices/S-01/` 的五份報告，全部整理成比較口語的繁體中文。可以逐份開啟，對學生解釋每一段在回答什麼。

S-01 的目標很單純：把「計算一筆訂單報價」換成新程式，同時保留原本的計算和錯誤行為。例如 `1.005 × 1` 要得到 `1.01`；示範中的錯誤版本會得到 `1.00`，測試必須抓到。

這是原本完成範例的中文對照，不是學生 `legacy/S-01/` 裡的待完成作業，也不是這次翻譯重新執行的結果。

## 先講這五份，就能看懂 S-01

1. [plan.md](slices/S-01/plan.md)：先說這次只換報價，保留什麼、不碰什麼，以及怎樣算過關。

2. [characterization.md](slices/S-01/characterization.md)：說明先從舊程式擷取四筆實際結果，作為之後不能任意更動的基準。

3. [implementation.md](slices/S-01/implementation.md)：說明錯誤／正確模式怎麼做，以及為什麼保留錯誤版供重播。

4. [verification.md](slices/S-01/verification.md)：看兩筆金額差異、修正版通過，以及之後獨立審查的結果。

5. [rollout.md](slices/S-01/rollout.md)：說明本機如何切換和切回，並解釋它為什麼不是正式部署或資料庫回復。

## 再按階段看共用產出

- **Intake，先對齊工作**：[charter.md](charter.md) 講目標、邊界和成功條件；[decisions.md](decisions.md) 記下採用的做法。

- **Recon，先廣泛盤點**：[inventory.md](inventory.md) 列出提供的東西；[coverage.md](coverage.md) 說明看到多深；[system-map.md](system-map.md) 畫出呼叫和資料關係；[evidence.md](evidence.md) 指向證據；[unknowns.md](unknowns.md) 保留未知事項。

- **Bizlogic，追出實際規則**：[business-rules.md](business-rules.md) 說明報價、下單、副作用和刻意不完整的假設。

- **Validate，查證理解**：[expert-questions.md](expert-questions.md) 列出該問專家的問題；[validation.md](validation.md) 說明沒有專家時，哪些能確認、哪些仍不能下結論。

- **Safety-net，先建立保護**：[safety-net.md](safety-net.md) 說明基準如何擷取、比較什麼；[behavior-deltas.md](behavior-deltas.md) 區分可接受差別和錯誤。

- **Design，決定怎麼小步替換**：[compatibility.md](compatibility.md) 對照技術行為；[strategy.md](strategy.md) 說明共存、切換和資料邊界。

- **Slice／execute／verify**：使用上面五份 S-01 報告。

- **Monitor，檢查整個流程**：[monitor.md](monitor.md) 說明獨立監控結果與仍未證明的事。

- **共用狀態與歷史**：[status.md](status.md) 是最後狀態；[progress.md](progress.md) 是實際順序；[stage-manifest.md](stage-manifest.md) 說明來源版本與階段應用。

## 上課時先說清楚的幾件事

共用報告是原本整個示範的紀錄，本來就同時包含 S-01 報價和後續 S-02 下單。翻譯保留 S-02 段落，避免把原本證據刪掉，或把下單的狀態異動說成報價造成的。本目錄不收 S-02 的五份專屬切片報告。

`GO` 是可以進行下一個有限步驟；`HOLD` 是先暫停。`GREEN` 是流程健康，`YELLOW` 是仍有事項待處理；這些都不是人類批准正式上線。

「本機模型通過」只表示選定 Java 情境的新舊結果一致。Oracle 只看過原始碼，沒有真正執行；正式部署、真實交易、效能與資安也沒有因此通過。

較早段落的「等待獨立審查」是當時狀態，後面的獨立驗證才是最後結果。不要把歷史進度當成目前仍卡住。

這次沒有把 JSON、命令、原始碼或雜湊值翻成中文。它們是執行證據，原樣保存在[原始證據目錄](../project/.migration/evidence/)；報告連結會直接帶過去。[evidence.md](evidence.md) 提供入口。

每份翻譯底部都有英文原文連結，方便逐段核對。這個 `tw/` 目錄需要連同原本 `worked-example/` 使用，才能開啟原始證據與來源連結。
